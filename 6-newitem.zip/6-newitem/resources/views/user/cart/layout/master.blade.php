@php
    $global = getSetting();
    //  dd($global);
@endphp

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    {{-- <link rel="shortcut icon" href="{{ asset('public/user/images/favicon.png') }}"> --}}
    <link rel="shortcut icon" href="{{ asset('public/' . $global->faceicon) }}">
    <title>{{ $global->site_title }}</title>
    <link href="{{ asset('public/user/css/bootstrap.css') }}" rel="stylesheet">
    <link href="{{ asset('public/user/css/aos.css') }}" rel="stylesheet">
    <link href="{{ asset('public/user/css/swiper-bundle.min.css') }}" rel="stylesheet">
    <link href="{{ asset('public/user/css/cssmenu-styles.css') }}" rel="stylesheet">
    <link href="{{ asset('public/user/css/fontawesome.css') }}" rel="stylesheet">
    <link href="{{ asset('public/user/css/style.css') }}" rel="stylesheet">
    <link href="{{ asset('public/user/css/responsive.css') }}" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
      <![endif]-->
</head>

<body>
    <div class="menu-overlay"></div>

    <!-- <header class="hedcontainer">
         <div class="hedbluebg">
            <div class="container">
               <div class="topsocialcont d-flex align-items-center  justify-content-between flex-wrap py-2">
                  <div class="top-social">
                     <ul>
                        <li><a href=""><i class="fa fa-facebook"></i></a></li>
                        <li><a href=""><i class="fa fa-linkedin"></i></a></li>
                        <li><a href=""><i class="fa fa-instagram"></i></a></li>
                     </ul>
                  </div>
                  <div class="currency-language d-flex align-items-center justify-content-center flex-wrap">
                     <ul class="flex-center top-currency">
                        <li><a href=""><img src="{{ asset('public/user/images/currency-usd.png') }}" alt=""></a></li>
                        <li><a href=""><img src="{{ asset('public/user/images/currency-euro.png') }}" alt=""></a></li>
                        <li><a href=""><img src="{{ asset('public/user/images/currency-aud.png') }}" alt=""></a></li>
                        <li><a href=""><img src="{{ asset('public/user/images/currency-nzd.png') }}" alt=""></a></li>
                     </ul>
                     <div class="languagesec">
                        <div class="tpusrinfo usertrgr">
                           English
                        </div>
                        <div class="userdropdown">
                           <ul>
                              <li><a href="">English</a></li>
                              <li><a href="">Français</a></li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="head-sec navesticky sticky">
            <div class="container">
               <div class="headerdflex d-flex align-items-center justify-content-between py-2">
                  <div class="hedlogo"><a href="index.html"><img src="{{ asset('public/user/images/logo.png') }}" alt="" ></a> </div>
                  <div class="hedright">
                     <div id="cssmenu">
                        <ul>
                           <li><a href="esim.html">eSIM</a></li>
                           <li><a href="check-usage.html">Check Usage</a></li>
                           <li><a href="blog.html">Blog</a></li>
                           <li><a href="faq.html">Help & FAQs</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </header> -->

    @include('user.layout.header')

    @yield('content')





    <footer class="footersection">
        <div class="container">
            <div class="ftnavsubsec">
                <div class="row">
                    <div class="col-sm-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="100">
                        <div class="ftaboutsec">
                            {{-- <a class="ftabimg" href="index.html"><img src="{{ asset('public/user/images/footer-logo.png') }}" alt="" /></a> --}}
                            <a class="ftabimg" href="{{route('user.home')}}"><img
                                    src="{{ asset('public/' . $global->footer_logo) }}" height="100" width="100"
                                    alt="" /></a>
                            <p>{{ $global->about_us }}</p>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="200">
                        <div class="quicklink ft-com-list">
                            <h4>Quick Links</h4>
                            <ul>
                                <li><a href="#">New eSIM</a></li>
                                <li><a href="#">Topup</a></li>
                                <li><a href="#">Check Usage</a></li>
                                <li><a href="#">Blog</a></li>
                                <li><a href="#">Help & FAQs</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="300">
                        <div class="ft-getintouch ft-com-list">
                            <h4>Get </h4>
                            <ul>
                                <li>
                                    <i class="fa fa-map-marker"></i> {{ $global->address }}
                                </li>
                                <li>
                                    <a href="tel:1234562505"><i class="fa fa-phone"></i>{{ $global->phone }}</a>
                                </li>
                                <li>
                                    <a href="mailto:info@linkesim.com"><i
                                            class="fa fa-envelope"></i>{{ $global->email }}</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="400">
                        <div class="keepintouch">
                            <h4>Keep In Touch</h4>
                            <ul>
                                <li><a href="https://www.facebook.com/login/device-based/regular/login/?_rdc=1&_rdr"><i
                                            class="fa fa-facebook"></i></a></li>
                                <li><a
                                        href="https://in.linkedin.com/?src=go-pa&trk=sem-ga_campid.14650114788_asid.151761418307_crid.657403558718_kw.linkedin%20website_d.c_tid.kwd-10521864532_n.g_mt.e_geo.1007759&mcid=6844056167778418689&cid=&gclid=Cj0KCQjwpPKiBhDvARIsACn-gzButJnqZiJvYMkx1YJ6wqkhJhINVbU33sANNuWkcvHsOJXgzyxs7r0aAuCdEALw_wcB&gclsrc=aw.ds"><i
                                            class="fa fa-linkedin"></i></a></li>
                                <li><a href="https://www.instagram.com/accounts/login/"><i
                                            class="fa fa-instagram"></i></a></li>
                            </ul>
                            {{-- <div class="stripe-logo"><img src="{{ asset('public/user/images/stripe-logo.png') }}" alt=""></div> --}}
                            <div class="stripe-logo"><img src="{{ asset('public/' . $global->payment_logo) }}"
                                    alt=""></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyrightsec">
                &copy;{{ $global->copyright_msg }} | <a href="#">Privacy legacy</a>
            </div>
        </div>
    </footer>
    <script src="{{ asset('public/user/js/jquery-3.6.1.js') }}"></script>
    <script src="{{ asset('public/user/js/bootstrap.j') }}s"></script>
    <script src="{{ asset('public/user/js/popper.min.j') }}s"></script>
    <script src="{{ asset('public/user/js/cssmenu-script.j') }}s"></script>
    <script src="{{ asset('public/user/js/swiper-bundle.min.j') }}s"></script>
    <script src="{{ asset('public/user/js/sticky-header.js') }}"></script>
    <script src="{{ asset('public/user/js/aos.j') }}s"></script>
    <script src="{{ asset('public/user/js/main.j') }}s"></script>
    <script>
        var swiper = new Swiper(".homemainslider", {
            slidesPerView: 9,
            spaceBetween: 14,

            breakpoints: {
                320: {
                    slidesPerView: 2,
                    navigation: {
                        nextEl: ".swiper-button-next",
                        prevEl: ".swiper-button-prev",
                    },
                },
                480: {
                    slidesPerView: 3,
                    navigation: {
                        nextEl: ".swiper-button-next",
                        prevEl: ".swiper-button-prev",
                    },
                },

                768: {
                    slidesPerView: 4,
                    navigation: {
                        nextEl: ".swiper-button-next",
                        prevEl: ".swiper-button-prev",
                    },
                },
                992: {
                    slidesPerView: 6,
                    navigation: {
                        nextEl: ".swiper-button-next",
                        prevEl: ".swiper-button-prev",
                    },
                },

                1200: {
                    slidesPerView: 9,
                    pagination: {
                        el: ".swiper-pagination",
                        clickable: true,
                    },
                },
            },
        });
    </script>
    <script>
        var tab_android_slider = new Swiper('.tab-android-slider', {
            centeredSlides: true,
            loop: true,
            speed: 500,
            slidesPerView: 5,
            spaceBetween: 45,
            autoplay: {
                delay: 3000,
            },
            pagination: {
                el: ".swiper-pagination1",
                clickable: true,
            },
            breakpoints: {
                320: {
                    slidesPerView: 1,
                    spaceBetween: 20,
                },
                480: {
                    slidesPerView: 3,
                    spaceBetween: 20,
                },
                1280: {
                    slidesPerView: 5,
                },
            },
        });
    </script>
    <script>
        var tab_apple_slider = new Swiper('.tab-apple-slider', {
            centeredSlides: true,
            loop: true,
            speed: 500,
            slidesPerView: 5,
            spaceBetween: 45,
            autoplay: {
                delay: 3000,
            },
            pagination: {
                el: ".swiper-pagination2",
                clickable: true,
            },
            breakpoints: {
                320: {
                    slidesPerView: 1,
                    spaceBetween: 20,
                },
                480: {
                    slidesPerView: 3,
                    spaceBetween: 20,
                },
                1200: {
                    slidesPerView: 5,

                },
            },
        });
    </script>
    <script>
        $(document).on('show.bs.tab', 'button[data-bs-toggle="pill"]', function() {

            //tab_apple_slider.initialSlide(1);
            //tab_android_slider.initialSlide(1);
        });
    </script>
</body>

</html>
