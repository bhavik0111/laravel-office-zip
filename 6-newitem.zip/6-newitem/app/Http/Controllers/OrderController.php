<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Order;
use App\Models\Category;
use Illuminate\Http\Request;
use App\Models\OrderProducts;

class OrderController extends Controller
{
    public function index()
    {
        //order LISTING...
        $orders = Order::where('user_id',auth()->user()->id)->get()->all();

        return view('user.order.index', compact('orders'));
    }

    public function adminindex()    // admin side allorder
    {
        //order LISTING...
        $orders = Order::get()->all();

        return view('admin.allorder.index', compact('orders'));
    }

    public function adminview($id)
    {
        // dd($id);

        $order = Order::where('order_id',$id)->get()->first();

        return view('admin.allorder.view',compact('order'));
    }


    public function create()
    {
        $carts = Cart::where('user_id',auth()->user()->id)->get()->all();
        if(!$carts){
            return redirect()->back()->with('msg', 'Please add atleast one product');
        }
         return view('user.order.create',compact('carts'));
    }


    public function store(Request $req)
    {
        $Order = new Order();
        $Order->user_id= auth()->user()->id;
        $Order->first_name = $req->first_name;
        $Order->last_name = $req->last_name;
        $Order->phone = $req->phone;
        $Order->email = $req->email;
        $Order->shipping_address = $req->shipping_address;
        $Order->total = $req->total;
        $Order->order_date = $req->order_date;
        $Order->order_status = $req->order_status;
        $Order->total = $req->total;
        $Order->save();

        $carts = Cart::where('user_id',auth()->user()->id)->get()->all();
        foreach ($carts as $key => $value) {
            $Order_product = new OrderProducts();
            $Order_product->user_id = auth()->user()->id;
            $Order_product->order_id = $Order->id;
            $Order_product->product_id = $value->product_id;
            $Order_product->price = $value->product->price;
            $Order_product->qty = $value->qty;
            $Order_product->save();
        }
        Cart::where('user_id',auth()->user()->id)->delete();

        return redirect()->route('user.home')->with('msg', 'your order are complite in process thank you');
    }

    public function view($id)
    {
        // dd($id);

        $order = Order::where('order_id',$id)->get()->first();

        return view('user.order.view',compact('order'));
    }


    public function edit($id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }
}
