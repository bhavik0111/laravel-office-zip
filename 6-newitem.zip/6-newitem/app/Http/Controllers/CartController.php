<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cart;

class CartController extends Controller
{
    public function index()
    {
        $carts = Cart::with(['product'])->where('user_id', auth()->user()->id)->get()->all();
        return view('user.cart.cart', compact('carts'));
    }


    public function create($id)
    {
        // dd($id);
        $carts = Cart::where('user_id', auth()->user()->id)->where('product_id', $id)->get()->all();
        if ($carts) {
            return redirect()->back()->with('msg', 'Product Already Exist in Cart');
        }
        $cart = new Cart();
        $cart->user_id = auth()->user()->id;
        $cart->product_id = $id;
        $cart->qty = 1;
        $cart->price = 0;
        $cart->save();
        return redirect()->route('user.home')->with('msg', 'Product Added in Cart');
    }

    public function update(Request $request)
    {
        $cart = Cart::where('user_id', auth()->user()->id)->where('product_id', $request->product_id)->get()->first();
        $cart->qty = $request->qty;
        $cart->save();
        return true;
    }
}
