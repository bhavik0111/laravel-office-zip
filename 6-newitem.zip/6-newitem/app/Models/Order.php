<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;
    protected $table = 'order_master';
    protected $fillable = [
        'first_name',
        'last_name',
        'phone',
        'email',
        'shipping_address',
        'total',
        'order_date',
        'order_status',
    ];

    public function productview()  // relation for orderview and all product display 
    {
       return $this->hasMany(OrderProducts::class,'order_id','order_id'); //return multiple (hasMany)
    }
}
