<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FaqsCategory extends Model
{
    use HasFactory;
    protected $table = 'faqs_category';
    protected $fillable = [

        'name',
        'description',
        'status',
    ];
}
