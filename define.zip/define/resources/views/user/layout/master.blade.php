@php
    $global = getSetting('logo');
    // dd($global);
@endphp

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    {{-- <link rel="shortcut icon" href="{{ asset('public/admin/assets/images/favicon.png') }}"> --}}
    <link rel="shortcut icon" href="{{ asset('public/' . $global->faceicon) }}">
    <title>{{ $global->site_title }}</title>

    {{-- <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet"> FOR LANGUAGE CHANGE LINK --}}

    {{-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"> --}}
    <!-- href="{{ asset('public/admin/assets/images/favicon.png') }}" -->
    <link href="{{ asset('public/user/css/bootstrap.css') }}" rel="stylesheet">
    <link href="{{ asset('public/user/css/aos.css') }}" rel="stylesheet">
    <link href="{{ asset('public/user/css/swiper-bundle.min.css') }}" rel="stylesheet">

    <link href="{{ asset('public/user/css/cssmenu-styles.css') }}" rel="stylesheet">
    <link href="{{ asset('public/user/css/fontawesome.css') }}" rel="stylesheet">
    <link href="{{ asset('public/user/css/style.css') }}" rel="stylesheet">
    <link href="{{ asset('public/user/css/responsive.css') }}" rel="stylesheet">

</head>

<body>
    <div class="menu-overlay"></div>

    @include('user.layout.header')

    {{-- @include('user.layout.menubar') --}}

    @yield('content')


    <div class="howitwork-sec comm-PTB-half">
        <div class="container">
            <h2 data-aos="fade-up" data-aos-delay="100">{{ __('messages.master.head') }}</h2>
            <p data-aos="fade-up" data-aos-delay="200">
                {{ __('messages.master.heada') }}
                <a href="">{{ __('messages.master.headb') }}</a>
                {{ __('messages.master.headc') }}
            </p>
            <div class="row">
                <div class="col-md-12 col-lg-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="howitwork-box">
                        <div class="howitwork-img">
                            <img src="{{ asset('public/user/images/how-it-work-img-1.png') }}" alt="">
                        </div>
                        <div class="howitwork-cont">
                            <h5>{{ __('messages.master.headd') }}</h5>
                            <p>{{ __('messages.master.heade') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-lg-4" data-aos="fade-up" data-aos-delay="300">
                    <div class="howitwork-box">
                        <div class="howitwork-img">
                            <img src="{{ asset('public/user/images/how-it-work-img-2.png') }}" alt="">
                        </div>
                        <div class="howitwork-cont">
                            <h5>{{ __('messages.master.headf') }}</h5>
                            <p>{{ __('messages.master.headg') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-lg-4" data-aos="fade-up" data-aos-delay="400">
                    <div class="howitwork-box">
                        <div class="howitwork-img">
                            <img src="{{ asset('public/user/images/how-it-work-img-3.png') }}" alt="">
                        </div>
                        <div class="howitwork-cont">
                            <h5>{{ __('messages.master.headh') }}</h5>
                            <p>{{ __('messages.master.headi') }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="esim-process-sec comm-PTB text-center">
        <div class="container">
            <h2 data-aos="fade-up" data-aos-delay="100">{{ __('messages.master.headj') }}</h2>
            <p data-aos="fade-up" data-aos-delay="200">{{ __('messages.master.headk') }}</p>
            <div class="tab-slider-sec" data-aos="fade-up" data-aos-delay="300">
                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home"
                            aria-selected="true">{{ __('messages.master.headl') }}</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile"
                            aria-selected="false">{{ __('messages.master.headm') }}</button>
                    </li>
                </ul>
                <div class="tab-content" id="pills-tabContent" data-aos="fade-up" data-aos-delay="400">
                    <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                        aria-labelledby="pills-home-tab">
                        <div class="app-mobile-process">
                            <div class="tab-android-slider">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-1.png') }}"
                                                alt=""></div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-2.png') }}"
                                                alt=""></div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-3.png') }}"
                                                alt=""></div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-4.png') }}"
                                                alt=""></div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-5.png') }}"
                                                alt=""></div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-1.png') }}"
                                                alt=""></div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-2.png') }}"
                                                alt=""></div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-3.png') }}"
                                                alt=""></div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-4.png') }}"
                                                alt=""></div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-5.png') }}"
                                                alt=""></div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-pagination1"></div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-profile" role="tabpanel"
                        aria-labelledby="pills-profile-tab">
                        <div class="app-mobile-process">
                            <div class="tab-apple-slider d-none">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-1.png') }}"
                                                alt=""></div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-2.png') }}"
                                                alt=""></div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-3.png') }}"
                                                alt=""></div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-4.png') }}"
                                                alt=""></div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-5.png') }}"
                                                alt=""></div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-1.png') }}"
                                                alt=""></div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-2.png') }}"
                                                alt=""></div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-3.png') }}"
                                                alt=""></div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-4.png') }}"
                                                alt=""></div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="pro-img-padd"><img
                                                src="{{ asset('public/user/images/android-act-pro-img-5.png') }}"
                                                alt=""></div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-pagination2"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('user.layout.footer')

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> {{-- FOR LANGUAGE CHANGE LINK --}}

    <script src="{{ asset('public/user/js/jquery-3.6.1.js') }}"></script>
    <script src="{{ asset('public/user/js/bootstrap.js') }}"></script>
    <script src="{{ asset('public/user/js/popper.min.js') }}"></script>
    <script src="{{ asset('public/user/js/cssmenu-script.js') }}"></script>
    <script src="{{ asset('public/user/js/swiper-bundle.min.js') }}"></script>
    <script src="{{ asset('public/user/js/sticky-header.js') }}"></script>
    <script src="{{ asset('public/user/js/aos.js') }}"></script>
    <script src="{{ asset('public/user/js/main.js') }}"></script>


    <script>
        var swiper = new Swiper(".homemainslider", {
            slidesPerView: 9,
            slidesPerGroup: 9,
            spaceBetween: 14,

            breakpoints: {
                320: {
                    slidesPerView: 3,
                    slidesPerGroup: 3,
                    navigation: {
                        nextEl: ".swiper-button-next",
                        prevEl: ".swiper-button-prev",
                    },
                },
                480: {
                    slidesPerView: 4,
                    slidesPerGroup: 4,
                    navigation: {
                        nextEl: ".swiper-button-next",
                        prevEl: ".swiper-button-prev",
                    },
                },

                768: {
                    slidesPerView: 4,
                    slidesPerGroup: 4,
                    navigation: {
                        nextEl: ".swiper-button-next",
                        prevEl: ".swiper-button-prev",
                    },
                },
                992: {
                    slidesPerView: 6,
                    slidesPerGroup: 6,
                    navigation: {
                        nextEl: ".swiper-button-next",
                        prevEl: ".swiper-button-prev",
                    },
                },

                1200: {
                    slidesPerView: 9,
                    slidesPerGroup: 9,
                    pagination: {
                        el: ".swiper-pagination",
                        clickable: true,
                    },
                },
            },
        });
    </script>
    <script>
        var tab_android_slider = new Swiper('.tab-android-slider', {
            centeredSlides: true,
            loop: true,
            speed: 500,
            slidesPerView: 5,
            spaceBetween: 45,
            observer: true,
            observeParents: true,
            autoplay: {
                delay: 3000,
            },
            pagination: {
                el: ".swiper-pagination1",
                clickable: true,
            },
            breakpoints: {
                320: {
                    slidesPerView: 1,
                    spaceBetween: 20,
                },
                480: {
                    slidesPerView: 3,
                    spaceBetween: 20,
                },
                1280: {
                    slidesPerView: 5,
                },
            },
        });
    </script>
    <script></script>
    <script>
        $(document).on('shown.bs.tab', 'button[data-bs-toggle="pill"]', function() {
            // Initialize Apple Slider after first time tab content shown due to display issue of slider in tab.
            setTimeout(function() {
                if (!$('.tab-apple-slider').hasClass('swiper-initialized')) {
                    var tab_apple_slider = new Swiper('.tab-apple-slider', {
                        centeredSlides: true,
                        loop: true,
                        speed: 500,
                        slidesPerView: 5,
                        spaceBetween: 45,
                        observer: true,
                        observeParents: true,
                        autoplay: {
                            delay: 3000,
                        },
                        pagination: {
                            el: ".swiper-pagination2",
                            clickable: true,
                        },
                        breakpoints: {
                            320: {
                                slidesPerView: 1,
                                spaceBetween: 20,
                            },
                            480: {
                                slidesPerView: 3,
                                spaceBetween: 20,
                            },
                            1200: {
                                slidesPerView: 5,

                            },
                        },
                    });
                    setTimeout(function() {
                        $(".tab-apple-slider").removeClass('d-none');
                    }, 300)
                }
            }, 20)

        });
    </script>
    <script>
        //  $(document).ready(function(){
        //     $(".more-det-btn").click(function(){
        //        $(".sim-show-detail").slideToggle(400);
        //     });
        //  });
    </script>

    {{-- CHANGE LANGUAGE SCRIPT --}}
    <script type="text/javascript">
        var url = "{{ route('changeLang') }}";

        $(".changeLang").change(function() {
            window.location.href = url + "?language=" + $(this).val();
        });
    </script>
</body>

</html>
