@extends('admin.layout.master')

@section('content')
    <main class="form-signin">

        <div class="card">
            <form method="POST" action="{{ route('admin.category.store') }}" enctype="multipart/form-data">
                @csrf

                <div class="form-group column" style="float:right">
                    <a href="{{ route('admin.category',['language' => 'sp']) }}" class="btn btn-primary" name="language" value="sp"><b>Spanish</b></a>
                </div>

                <div class="form-group column" style="float:right">
                    <a href="{{ route('admin.category',['language' => 'fr']) }}" class="btn btn-primary" name="language" value="fr"><b>French</b></a>
                </div>

                <div class="form-group column" style="float:right">
                    <a href="{{ route('admin.category',['language' => 'en']) }}" class="btn btn-primary" name="language" value="en"><b>English</b></a>
                </div>

                <div class="card-body">
                    <h4 class="card-title">{{ __('messages.category.add_category', [], 'sp') }}</h4>

                    <div class="form-group column" style="float:right">
                        <a href="{{ route('admin.category.index') }}" class="btn btn-dark"><b>Back</b></a>
                    </div>

                    <div class="form-group row">
                        <label for="name_sp"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.category.name', [], 'sp') }}</b></label>
                        <div class="col-sm-9">
                            <input id="name_sp" type="text" class="form-control @error('name_sp') is-invalid @enderror"
                                name="name_sp" value="{{ old('name_sp') }}" required autocomplete="name_sp" autofocus>
                                <input type="hidden" name="language" value="{{$language}}">
                            @error('name_sp')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="cat_image"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.category.image', [], 'sp') }}</b></label>

                        <div class="col-sm-9">
                            <input id="cat_image" type="file"
                                class="form-control @error('cat_image') is-invalid @enderror" name="cat_image"
                                autocomplete="cat_image" autofocus>
                            @error('cat_image')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="description_sp"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.category.description', [], 'sp') }}</b></label>

                        <div class="col-sm-9">
                            <input id="description_sp" type="text"
                                class="form-control @error('description_sp') is-invalid @enderror" name="description_sp"
                                value="{{ old('description_sp') }}" >

                                @error('description_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                        </div>
                    </div>

                    <div class="border-top">
                        <div class="card-body" style="float:center">
                            <button type="submit" class="btn btn-primary">
                                {{ __('submit') }}
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </main>
@endsection
