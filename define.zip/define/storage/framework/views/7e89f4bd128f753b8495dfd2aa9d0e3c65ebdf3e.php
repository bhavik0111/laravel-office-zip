<?php $__env->startSection('content'); ?>
    <main class="form-signin">

        <div class="card">
            <form method="POST" action="<?php echo e(route('admin.category.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="form-group column" style="float:right">
                    <a href="<?php echo e(route('admin.category', ['language' => 'sp'])); ?>" class="btn btn-primary" name="language" value="sp"><b>Spanish</b></a>
                </div>
                <div class="form-group column" style="float:right">
                    <a href="<?php echo e(route('admin.category', ['language' => 'fr'])); ?>" class="btn btn-primary" name="language" value="fr"><b>French</b></a>
                </div>
                <div class="form-group column" style="float:right">
                    <a href="<?php echo e(route('admin.category', ['language' => 'en'])); ?>" class="btn btn-primary" name="language" value="en"><b>English</b></a>
                </div>

                <div class="card-body">
                    <h4 class="card-title"><?php echo e(__('messages.category.add_category',[],'fr')); ?></h4>

                    <div class="form-group column" style="float:right">
                        <a href="<?php echo e(route('admin.category.index')); ?>" class="btn btn-dark"><b>Back</b></a>
                    </div>

                    <div class="form-group row">
                        <label for="name_fr"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('messages.category.name',[],'fr')); ?></b></label>
                        <div class="col-sm-9">
                            <input id="name_fr" type="text" class="form-control <?php $__errorArgs = ['name_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="name_fr" value="<?php echo e(old('name_fr')); ?>" required autocomplete="name_fr" autofocus>

                                <input type="hidden" name="language" value="<?php echo e($language); ?>">
                            <?php $__errorArgs = ['name_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="cat_image"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('messages.category.image',[],'fr')); ?></b></label>

                        <div class="col-sm-9">
                            <input id="cat_image" type="file"
                                class="form-control <?php $__errorArgs = ['cat_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cat_image"
                                autocomplete="cat_image">
                            <?php $__errorArgs = ['cat_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="description_fr"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('messages.category.description',[],'fr')); ?></b></label>

                        <div class="col-sm-9">
                            <input id="description_fr" type="text"
                                class="form-control <?php $__errorArgs = ['description_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description_fr"
                                value="<?php echo e(old('description_fr')); ?>">

                                <?php $__errorArgs = ['description_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="border-top">
                        <div class="card-body" style="float:center">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('submit')); ?>

                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/admin/category/createfrench.blade.php ENDPATH**/ ?>