<link rel="stylesheet" type="text/css"
href="<?php echo e(asset('public/admin/assets/extra-libs/multicheck/multicheck.css')); ?>"/>

<link rel="stylesheet"
href="<?php echo e(asset('public/admin/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css')); ?>"
/>
<?php $__env->startSection('content'); ?>

<!-- (FOR MSG) -->
    <?php if(session()->has('msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('msg')); ?>

        </div>
    <?php endif; ?>
    <?php if(session()->has('error_msg')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('error_msg')); ?>

        </div>
    <?php endif; ?>
<!-- (END MSG) -->
<div class="card mb-3">
    <div class="card-body">
        <div class="card-header row">
            <h4 class="card-title mb-3"><b>All Currency</b></h4>
            <div class="text-end">
              <a href="<?php echo e(route('admin.currency.create')); ?>" class="btn btn-dark"><b>Add+</b></a>
            </div>
        </div>
        <div class="table-responsive">
            <table id="zero_config" class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th><b>ID</b></th>
                    <th><b>Currency Name</b></th>
                    <th><b>Code</b></th>
                    <th><b>Symbole</b></th>
                    <th><b>Status</b></th>
                    <th><b>Action</b></th>
                  </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><strong><?php echo e($currency->id); ?></strong></td>

                    <td><?php echo e($currency->name); ?></td>

                    <td><?php echo e($currency->code); ?></td>
                    <td><?php echo e($currency->symbole); ?></td>
                    <td>
                        <?php if($currency->status==1): ?><?php echo e('Active'); ?> <?php endif; ?>
                        <?php if($currency->status==0): ?><?php echo e('Deactive'); ?> <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.currency.edit', $currency->id)); ?>" class="btn btn-info"><b>Edit</b></a>

                        <form action="<?php echo e(route('admin.currency.destroy', $currency->id)); ?>" method="POST" onsubmit="return confirm('Are you sure Delete currency?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger text-white"><b>Delete</b></button>
                        </form>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>  <!-- for all pagination,asc-desc,search,shorting  -->
<script src="<?php echo e(asset('public/admin/assets/extra-libs/multicheck/datatable-checkbox-init.js')); ?>"></script>
<script src="<?php echo e(asset('public/admin/assets/extra-libs/multicheck/jquery.multicheck.js')); ?>"></script>
<script src="<?php echo e(asset('public/admin/assets/extra-libs/DataTables/datatables.min.js')); ?>"></script>
<script>
  /****************************************
   *       Basic Table                   *
   ****************************************/
  $("#zero_config").DataTable();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/admin/currency/index.blade.php ENDPATH**/ ?>