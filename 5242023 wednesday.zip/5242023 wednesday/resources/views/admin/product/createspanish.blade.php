@extends('admin.layout.master')

@section('content')
    <main class="form-signin">
        <div class="card">
            <form method="POST" action="{{ route('admin.product.store') }}" enctype="multipart/form-data">
                @csrf

                <div class="form-group column" style="float:right">
                    <a href="{{ route('admin.product', ['language' => 'sp']) }}" class="btn {{ $language == 'sp' ? 'btn-primary' : 'btn-dark' }}" name="language"
                        value="sp"><b>Spanish</b></a>
                </div>
                <div class="form-group column" style="float:right">
                    <a href="{{ route('admin.product', ['language' => 'fr']) }}" class="btn {{ $language == 'fr' ? 'btn-primary' : 'btn-dark' }}" name="language"
                        value="fr"><b>French</b></a>
                </div>
                <div class="form-group column" style="float:right">
                    <a href="{{ route('admin.product', ['language' => 'en']) }}" class="btn {{ $language == 'en' ? 'btn-primary' : 'btn-dark' }}" name="language"
                        value="en"><b>English</b></a>
                </div>

                <div class="card-body">
                    <h4 class="card-title">{{ __('messages.product.add_product', [], 'sp') }}</h4>

                    <div class="form-group column" style="float:right">
                        <a href="{{ route('admin.product.index') }}" class="btn btn-dark"><b>Back</b></a>
                    </div>

                    <div class="form-group row">
                        <label for="name_sp"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.product.category', [], 'sp') }}</b></label>
                        <div class="col-sm-9">
                            <select name="category_id" class="form-control">
                                <option value="" selected>Select Category</option>
                                @foreach ($categories as $category)
                                    <option value="{{ $category->id }}">{{ $category->name_sp }}</option>
                                @endforeach
                            </select>

                            @error('category_id')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="name_sp"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.product.name', [], 'sp') }}</b></label>
                        <div class="col-sm-9">
                            <input id="name_sp" type="text" class="form-control @error('name_sp') is-invalid @enderror"
                                name="name_sp" value="{{ old('name_sp') }}" >

                                <input type="hidden" name="language" value="{{ $language }}">

                                @error('name_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="cat_image"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Image') }}</b></label>

                        <div class="col-sm-9">
                            <input id="prod_image" type="file"
                                class="form-control @error('prod_image') is-invalid @enderror" name="prod_image">
                            @error('prod_image')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="price_sp"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.product.price', [], 'sp') }}</b></label>

                        <div class="col-sm-9">
                            <input id="price_sp" type="number" class="form-control @error('price_sp') is-invalid @enderror"
                                name="price_sp" value="{{ old('price_sp') }}">

                                @error('price_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="colour_sp"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.product.colour', [], 'sp') }}</b></label>

                        <div class="col-sm-9">
                            <input type="color" id="colour_sp" class="form-control @error('colour_sp') is-invalid @enderror"
                                name="colour_sp" value="{{ old('colour_sp') }}" >

                                @error('colour_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="data_sp"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.product.data', [], 'sp') }}</b></label>

                        <div class="col-sm-9">
                            <input id="data_sp" type="text" class="form-control @error('data_sp') is-invalid @enderror"
                                name="data_sp" value="{{ old('data_sp') }}">

                                @error('data_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="data_detail_sp"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.product.data_detail', [], 'sp') }}</b></label>

                        <div class="col-sm-9">
                            <textarea id="data_detail_sp" class="form-control @error('data_detail_sp') is-invalid @enderror summernote" name="data_detail"
                                value="{{ old('data_detail_sp') }}" ></textarea>

                                @error('data_detail_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="calls_sp"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.product.calls', [], 'sp') }}</b></label>

                        <div class="col-sm-9">
                            <input id="calls_sp" type="text"
                                class="form-control @error('calls_sp') is-invalid @enderror" name="calls_sp"
                                value="{{ old('calls_sp') }}" >

                                @error('calls_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="calls_detail_sp"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.product.calls_detail', [], 'sp') }}</b></label>

                        <div class="col-sm-9">
                            <textarea id="calls_detail_sp" class="form-control @error('calls_detail_sp') is-invalid @enderror summernote"
                                name="calls_detail_sp" value="{{ old('calls_detail_sp') }}" ></textarea>

                                @error('calls_detail_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="sms_sp"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.product.sms', [], 'sp') }}</b></label>

                        <div class="col-sm-9">
                            <input id="sms_sp" type="text" class="form-control @error('sms_sp') is-invalid @enderror"
                                name="sms_sp" value="{{ old('sms_sp') }}" >

                                @error('sms_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="sms_detail_sp"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.product.sms_detail', [], 'sp') }}</b></label>

                        <div class="col-sm-9">
                            <textarea id="sms_detail_sp" class="form-control @error('sms_detail_sp') is-invalid @enderror summernote" name="sms_detail"
                                value="{{ old('sms_detail_sp') }}" ></textarea>

                                @error('sms_detail_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="credit_validity_sp"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.product.credit_val', [], 'sp') }}</b></label>

                        <div class="col-sm-9">
                            <input id="credit_validity_sp" type="text"
                                class="form-control @error('credit_validity_sp') is-invalid @enderror"
                                name="credit_validity_sp" value="{{ old('credit_validity_sp') }}">

                                @error('credit_validity_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="credit_validity_detail_sp"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.product.credit_val_detail', [], 'sp') }}</b></label>

                        <div class="col-sm-9">
                            <textarea id="credit_validity_detail_sp"
                                class="form-control @error('credit_validity_detail_sp') is-invalid @enderror summernote"
                                name="credit_validity_detail_sp" value="{{ old('credit_validity_detail_sp') }}" >
                            </textarea>

                                @error('credit_validity_detail_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="description_sp"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.product.description', [], 'sp') }}</b></label>

                        <div class="col-sm-9">
                            <textarea id="description_sp" class="form-control @error('description_sp') is-invalid @enderror summernote"
                                name="description_sp" value="" ></textarea>

                                @error('description_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="addnewfeature"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.product.addnewfeature', [], 'sp') }}</b></label>

                        <div class="col-sm-9">
                            <button type="button" class="btn btn-primary" onclick="addrow()">
                                {{ __('AddNewFeature') }}
                            </button>
                        </div>
                    </div>

                    <div class="features">
                        <!-- (click AddNew all title and description field are placed heare....) -->
                    </div>

                    <div class="form-group row">
                        <label
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.product.status', [], 'sp') }}</b></label>
                        <div class="col-md-9">
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation1"
                                    name="status"value="1" required />

                                <label class="form-check-label mb-0"
                                    for="customControlValidation1">{{ __('messages.product.active', [], 'sp') }}</label>

                            </div>
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation2"
                                    name="status" value="0" required />
                                <label class="form-check-label mb-0"
                                    for="customControlValidation2">{{ __('messages.product.deactive', [], 'sp') }}</label>
                            </div>
                        </div>
                    </div>

                    <div class="border-top">
                        <div class="card-body" style="float:center">
                            <button type="submit" class="btn btn-primary">
                                {{ __('messages.product.submit', [], 'sp') }}
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </main>
@endsection
@push('scripts')
    <script>
        $(document).ready(function() {
            $('.summernote').summernote();
        });



        function addrow() {
            var html =
                '<div class="prod_feature">' +
                '<div class="form-group row">' +
                '<label for="title"  class="col-sm-3 text-end control-label col-form-label">{{ __('Title') }}' +
                '</label>' +

                '<div class="col-sm-8">' +
                '<input type="text" name="title[]" class="form-control title"  id="title" required>' +
                '</div>' +
                '<div class="col-sm-1">' +
                '<button type="button" class="btn btn-danger deleteRow">Delete</button>' +
                '</div>' +
                '</div>' +

                '<div class="form-group row">' +
                '<label for="add_description" class="col-sm-3 text-end control-label col-form-label">{{ __('Description') }}' +
                '</label>' +

                '<div class="col-sm-8">' +
                '<textarea class="form-control summernote" name="add_description[]" id="add_description">{{ old('add_description') }}</textarea>' +
                '</div>' +
                '</div>' +
                '</div>';

            $('.features').append(html);

            $('.summernote').summernote();
        }

        $(document).on('click', '.deleteRow', function(e) {
            e.preventDefault();
            $(this).closest('.prod_feature').remove();
        })
    </script>
@endpush
