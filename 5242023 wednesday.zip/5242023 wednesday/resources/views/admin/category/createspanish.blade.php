@extends('admin.layout.master')

@section('content')
    <main class="form-signin">

        <div class="card">
            <form method="POST" action="{{ route('admin.category.store') }}" enctype="multipart/form-data">
                @csrf

                <div class="form-group column" style="float:right">
                    <a href="{{ route('admin.category',['language' => 'sp']) }}" class="btn {{ $language == 'sp' ? 'btn-primary' : 'btn-dark' }}" name="language" value="sp"><b>Spanish</b></a>
                </div>

                <div class="form-group column" style="float:right">
                    <a href="{{ route('admin.category',['language' => 'fr']) }}" class="btn {{ $language == 'fr' ? 'btn-primary' : 'btn-dark' }}" name="language" value="fr"><b>French</b></a>
                </div>

                <div class="form-group column" style="float:right">
                    <a href="{{ route('admin.category',['language' => 'en']) }}" class="btn {{ $language == 'en' ? 'btn-primary' : 'btn-dark' }}" name="language" value="en"><b>English</b></a>
                </div>

                <div class="card-body">
                    <h4 class="card-title">{{ __('messages.category.add_category', [], 'sp') }}</h4>

                    <div class="form-group column" style="float:right">
                        <a href="{{ route('admin.category.index') }}" class="btn btn-dark"><b>Back</b></a>
                    </div>

                    <div class="form-group row">
                        <label for="name_sp"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.category.name', [], 'sp') }}</b></label>
                        <div class="col-sm-9">
                            <input id="name_sp" type="text" class="form-control @error('name_sp') is-invalid @enderror"
                                name="name_sp" value="{{ old('name_sp') }}" required autocomplete="name_sp" autofocus>
                                <input type="hidden" name="language" value="{{ $language }}">
                            @error('name_sp')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="cat_image"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.category.image', [], 'sp') }}</b></label>

                        <div class="col-sm-9">
                            <input id="cat_image" type="file"
                                class="form-control @error('cat_image') is-invalid @enderror" name="cat_image"
                                autocomplete="cat_image" autofocus>
                            @error('cat_image')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="description_sp"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('messages.category.description', [], 'sp') }}</b></label>

                        <div class="col-sm-9">
                            <input id="description_sp" type="text"
                                class="form-control @error('description_sp') is-invalid @enderror" name="description_sp"
                                value="{{ old('description_sp') }}" >

                                @error('description_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 text-end control-label col-form-label"><b>Status</b></label>
                        <div class="col-md-9">
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation1" name="status"
                                    value="1" selected>
                                <label class="form-check-label mb-0"
                                    for="customControlValidation1">{{ __('Active') }}</label>

                            </div>
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation2" name="status"
                                    value="0" required />
                                <label class="form-check-label mb-0"
                                    for="customControlValidation2">{{ __('Deactive') }}</label>
                            </div>
                        </div>
                    </div>


                    <div class="border-top">
                        <div class="card-body" style="float:center">
                            <button type="submit" class="btn btn-primary">
                                {{ __('submit') }}
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </main>
@endsection
