<?php $__env->startSection('content'); ?>
    <main class="form-signin">

        <div class="card">
            <form method="POST" action="<?php echo e(route('admin.language.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <h4 class="card-title"><?php echo e(__('Add Language')); ?></h4>

                    <div class="form-group column" style="float:right">
                        <a href="<?php echo e(route('admin.language.index')); ?>" class="btn btn-dark"><b>Back</b></a>
                    </div>

                    <div class="form-group row">
                        <label for="name"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Name')); ?></b></label>
                        <div class="col-sm-9">
                            <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                        </div>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <label for="code"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Code')); ?></b>
                        </label>

                        <div class="col-sm-9">
                            <input id="code" type="text" class="form-control <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="code" value="<?php echo e(old('code')); ?>" required autocomplete="code">
                        </div>
                        <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 text-end control-label col-form-label"><b>Status</b></label>
                        <div class="col-md-9">
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation1" name="status"
                                    value="1" required />
                                <label class="form-check-label mb-0"
                                    for="customControlValidation1"><?php echo e(__('Active')); ?></label>

                            </div>
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation2" name="status"
                                    value="0" required />
                                <label class="form-check-label mb-0"
                                    for="customControlValidation2"><?php echo e(__('Deactive')); ?></label>
                            </div>
                        </div>
                    </div>

                    <div class="border-top">
                        <div class="card-body" style="float:center">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('submit')); ?>

                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <!--  </div>
            </div>
        </div>
    </div> -->
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/admin/language/create.blade.php ENDPATH**/ ?>