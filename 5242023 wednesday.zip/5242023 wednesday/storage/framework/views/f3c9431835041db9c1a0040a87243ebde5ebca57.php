<?php $__env->startSection('content'); ?>
<main class="form-signin">

<div class="card">
  <form action="<?php echo e(route('user.update')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="card-body">
      <h4 class="card-title">Update User</h4>

        <div class="card-body">
            <div class="form-group column" style="float:right">
              <a href="<?php echo e(route('user.index')); ?>" class="btn btn-dark"><b>Back</b></a>
            </div>
        </div>

        <div class="form-group row">
            <label
              for="name"
              class="col-sm-3 text-end control-label col-form-label"
              ><b>First Name</b></label>
            <div class="col-sm-9">
              <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('name',$user->name)); ?>" id="name" name="name" placeholder="your name">
              
            </div>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group row">
            <label
              for="last_name"
              class="col-sm-3 text-end control-label col-form-label"
              ><b>Last Name</b></label>
            <div class="col-sm-9">
              <input type="text" class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     value="<?php echo e(old('last_name',$user->last_name)); ?>" id="last_name" name="last_name" placeholder="your last_name">
              
            </div>
            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group row">
            <label for="email" class="col-sm-3 text-end control-label col-form-label"
              ><b>Email</b></label>
            <div class="col-sm-9">
              <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                      value="<?php echo e(old('email',$user->email)); ?>" id="email" name="email" placeholder="name@example.com">

              <input type="hidden" name="id" value="<?php echo e($user->id); ?>">              
            </div>
             <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group row">
            <label
              for="password"
              class="col-sm-3 text-end control-label col-form-label"
              ><b>Password</b></label
            >
            <div class="col-sm-9">
               <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" id="password" placeholder="Password">
            </div>

            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group row">
            <label
              for="confirm-password"
              class="col-sm-3 text-end control-label col-form-label"
              ><b>Confirm Password</b></label
            >
            <div class="col-sm-9">
              <input type="password" class="form-control <?php $__errorArgs = ['confirm-password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="confirm-password" id="confirm-password" placeholder="confirm-password">
            </div>
            <?php $__errorArgs = ['confirm-password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group row">
            <label class="col-sm-3 text-end control-label col-form-label"><b>Account</b></label>
            <div class="col-md-9">
                <div class="form-check">

                  <input type="radio" class="form-check-input"
                    id="customControlValidation1"
                    name="verify_acc" value="1" <?php if($user->verify_acc == 1): ?><?php echo e('checked=checked'); ?> <?php endif; ?>
                    required/>
                  <label
                    class="form-check-label mb-0"
                    for="customControlValidation1"
                    >Verify</label>

                </div>
                <div class="form-check">

                  <input type="radio" class="form-check-input"
                    id="customControlValidation2"
                    name="verify_acc" value="0"
                    <?php if($user->verify_acc == 0): ?><?php echo e('checked=checked'); ?> <?php endif; ?>
                    required/>
                  <label
                    class="form-check-label mb-0"
                    for="customControlValidation2"
                    >Unverify</label>
                </div>
            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-3 text-end control-label col-form-label"><b>Is Admin</b></label>
            <div class="col-md-9">
                <div class="form-check">

                  <input type="radio" class="form-check-input"
                    id="customControlValidation1"
                    name="is_admin" value="1" <?php if($user->is_admin == 1): ?><?php echo e('checked=checked'); ?> <?php endif; ?>
                    required/>
                  <label
                    class="form-check-label mb-0"
                    for="customControlValidation1"
                    >Yes</label>

                </div>
                <div class="form-check">

                  <input type="radio" class="form-check-input"
                    id="customControlValidation2"
                    name="is_admin" value="2" <?php if($user->is_admin == 2): ?><?php echo e('checked=checked'); ?> <?php endif; ?>
                    required/>
                  <label
                    class="form-check-label mb-0"
                    for="customControlValidation2"
                    >No</label>
                </div>
            </div>
        </div>
      
      </div>
      <div class="border-top">
        <div class="card-body">
          <button type="submit" name="uedit" class="btn btn-primary">
            Edit
          </button>
        </div>
      </div>
  </form>
</div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/user/uedit.blade.php ENDPATH**/ ?>