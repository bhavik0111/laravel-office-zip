<?php $__env->startSection('content'); ?>
    <div class="innerpage-banner">
        <div class="container">
            <div class="innerpage-title flex-center" data-aos="fade-up" data-aos-delay="100">
                <h3>The Best eSIMs in 2023</h3>
            </div>
        </div>
    </div>
    <div class="blog-list comm-PTB">
        <div class="container">

            <div class="blog-detail-page" data-aos="fade-up" data-aos-delay="200">
                <?php if($blog->image): ?>
                    <div class="blog-det-img">
                        <a href="#"><img src="<?php echo e(asset('public/' . $blog->image)); ?>"
                                alt="">
                        </a>
                    </div>
                <?php endif; ?>
                <div class="blog-cont-box">
                    <div class="blog-det-cat mb-4">
                        <ul class="flex-center flex-wrap">
                            <li><span>Date:</span><?php echo e(date('F d, Y', strtotime($blog->date))); ?></li> 
                            <li><span>Category:</span> <?php echo e($blog->category->name); ?></li>
                        </ul>
                    </div>
                    <div class="blog-cont-det">

                        <h3><?php echo e($blog->title); ?></h3>
                        <p><?php echo e($blog->description); ?></p>
                        
                        
                        essentially unchanged. of type and scrambled it to make a type specimen book. It has survived
                        not only five centuries, but also the leap into electronic typesetting, remaining essentially
                        unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem
                        Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker
                        including versions of Lorem Ipsum.</p>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.cart.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/user/blog/blog_detail.blade.php ENDPATH**/ ?>