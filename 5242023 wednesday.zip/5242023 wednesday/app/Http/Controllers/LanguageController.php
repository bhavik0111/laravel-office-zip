<?php

namespace App\Http\Controllers;

use App\Models\Language;
use Illuminate\Http\Request;

class LanguageController extends Controller
{
    public function create(Request $req)   // Language form open
    {
        return view('admin.language.create');
    }

    public function index(Request $req)   //Language LISTING...
    {
        $languages = Language::get();
        return view('admin.language.index', compact('languages'));
    }

    public function store(Request $req)     //INSERT IN DB...
    {
        $req->validate([
            'name' => ['required'],
            'code' => ['required'],
            'status' => 'required'
        ]);

        $language = new Language();
        $language->name = $req->name;
        $language->code = $req->code;
        $language->status = $req->status;

        $language->save();

        return redirect()->route('admin.language.index')->with('msg', 'new Language added');
    }

    public function edit($id)     // Language EDIT form display...
    {
        $language = Language::where('id', $id)->first();

            if (empty($language)) {
                return redirect()->route('admin.language.index');
            }

        return view('admin.language.edit', compact('language'));
    }

    function update(Request $req)
    {
        //user UPDATE IN DB...
        $language = Language::where('id', $req->id)->first();

        $language->name = $req->name;
        $language->code = $req->code;
        $language->status = $req->status;

        $language->save();

        return redirect()->route('admin.language.index')->with('msg', 'Language Updated');
    }

    function destroy($id)    //FOR Language DELETE...
    {
        $language = Language::where('id', $id)->get()->first();

        $language->delete();
        return redirect()->route('admin.language.index')->with('msg', 'Record Deleted');
    }
}
