<?php
use App\Models\Currency;
use App\Models\Language;
use App\Models\GlobalSetting;

if(!function_exists('getSetting')){

    function getSetting()
    {
        $global = GlobalSetting::first();
        return ($global);
    }

    function changeCurrnecy($value){
        $global = GlobalSetting::get()->first();

        if($global->currency == 'USD'){
            echo money::USD($value);
        }

        if($global->currency == 'INR'){
            echo money::INR($value);
        }

        if($global->currency == 'EUR'){
            echo money::EUR($value);
        }

        if($global->currency == 'NZD'){
            echo money::NZD($value);
        }

    }

    function getcurrency()
    {
        $currency = Currency::where('status', 1)->get()->all();
        return ($currency);
    }

    function getLang()
    {
        $languages = Language::where('status', 1)->get()->all();
        return $languages;
    }



}



