<?php

namespace App\Http\Controllers;
use App\Models\Faqs;
use App\Models\FaqsCategory;
use Illuminate\Http\Request;

class FaqsController extends Controller
{

    public function index()    //<--(Faqs LISTING...)-->
    {
        $faqs = Faqs::with('category')->get()->all();
        return view('admin.faqs.index', compact('faqs'));
    }


    public function create(Request $request)  //<--(Faqs FORM CREATE)-->
    {
        $data['categories'] = FaqsCategory::where('status', 1)->get();  // for category dropdown list at relationshp
        return view('admin.faqs.create',$data);
    }



    public function store(Request $request)   //<--(INSERT IN DB...)-->
    {
        $request->validate([
            'category_id'  => ['required'],
            'title' => ['required'],
            'description' => ['required'],
            'status' => 'required'
        ]);


        $faqs = new Faqs();
        $faqs->category_id = $request->category_id;
        $faqs->title = $request->title;
        $faqs->description = $request->description;
        $faqs->status = $request->status;


        $faqs->save();

        return redirect()->route('admin.faqs.index')->with('msg', 'Record Successfully Inserted');
    }

    public function edit($id)    //<--(Faqs EDIT FORM DISPLAY...)-->
    {

        $faqs = Faqs::where('id', $id)->first();
        $categories = FaqsCategory::where('status', 1)->get();
        // if(empty($blog))
        // {
        //     return redirect()->route('admin.blogs.index');
        // }
        return view('admin.faqs.edit', compact('faqs','categories'));
    }

    function update(Request $req)
    {
        //user UPDATE IN DB...
        $faqs = Faqs::where('id', $req->id)->first();
        // dd($req);
        $faqs->category_id = $req->category_id;
        $faqs->title = $req->title;
        $faqs->description = $req->description;
        $faqs->status = $req->status;

        $faqs->save();

        return redirect()
            ->route('admin.faqs.index')
            ->with('msg', 'Record Updated');
    }

    function destroy($id)
    {
        //FOR Category DELETE...
        $faqs = Faqs::where('id', $id)
            ->get()
            ->first();
        $faqs->delete();

        return redirect()
            ->route('admin.faqs.index')
            ->with('msg', 'Record Deleted');
    }

        //user side view

        public function usercreate(Request $request)  //<--(user side faqs display)-->
        {
            $faqs = Faqs::get()->all();
            return view('user.faqs.faqs',compact('faqs'));
        }





}
