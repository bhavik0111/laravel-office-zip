<?php

namespace App\Models;
use App\Models\FaqsCategory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Faqs extends Model
{
    use HasFactory;
    protected $table = 'faqs';
    protected $fillable = [
        'category_id',
        'title',
        'description',
        'status',
    ];

    public function category()  //relation for category dropdown list
    {
       return $this->belongsTo(FaqsCategory::class);  //return single items
    }

}
