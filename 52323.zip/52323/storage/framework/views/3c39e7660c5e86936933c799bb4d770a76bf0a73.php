<?php $__env->startSection('content'); ?>
    <main class="form-signin">

        <div class="card">
            <form action="<?php echo e(route('admin.blogs.update', $blog->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <h4 class="card-title">Update Blog</h4>

                    <div class="card-body">
                        <div class="form-group column" style="float:right">
                            <a href="<?php echo e(route('admin.blogs.index')); ?>" class="btn btn-dark"><b>Back</b></a>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label for="category_id"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Name')); ?></b></label>
                        <div class="col-sm-9">

                            <select name="category_id" class="form-control  <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> ">
                                <option value="" selected>Select Category</option>

                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"
                                        <?php echo e($category->id == $blog->category_id ? 'selected' : ''); ?>><?php echo e($category->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="image"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Image')); ?></b></label>

                        <div class="col-sm-9">
                            <input id="image" type="file" class="form-control" name="image" autocomplete="image"
                                autofocus>

                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="title"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Title')); ?></b></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(old('title', $blog->title)); ?>" id="title" name="title" placeholder=" title">

                            <input type="hidden" name="id" value="<?php echo e($blog->id); ?>">

                        </div>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <label for="description"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Description')); ?></b></label>
                        <div class="col-sm-9">
                            <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="" id="description" name="description"
                                placeholder="name@example.com"><?php echo e(old('description', $blog->description)); ?>

                            </textarea>
                        </div>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <label for="date"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Date')); ?></b></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(old('date', $blog->date)); ?>" id="datepicker" name="date"
                                placeholder="name@example.com">
                        </div>
                        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 text-end control-label col-form-label"><b>Status</b></label>
                        <div class="col-md-9">
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation1" name="status"
                                    value="1" <?php if($blog->status == 1): ?> <?php echo e('checked=checked'); ?> <?php endif; ?>
                                    required />
                                <label class="form-check-label mb-0"
                                    for="customControlValidation1"><?php echo e(__('Active')); ?></label>

                            </div>
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation2" name="status"
                                    value="0" <?php if($blog->status == 0): ?> <?php echo e('checked=checked'); ?> <?php endif; ?>
                                    required />
                                <label class="form-check-label mb-0"
                                    for="customControlValidation2"><?php echo e(__('Deactive')); ?></label>
                            </div>
                        </div>
                    </div>



                </div>
                <div class="border-top">
                    <div class="card-body">
                        <button type="submit" name="uedit" class="btn btn-primary">
                            Edit
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>

<script>
$( function() {
  $( "#datepicker" ).datepicker();
} );
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/admin/blogs/edit.blade.php ENDPATH**/ ?>