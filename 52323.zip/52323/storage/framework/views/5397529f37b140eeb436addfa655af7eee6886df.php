<!-- Checkout page -->
<?php $__env->startSection('content'); ?>
    <div class="innerpage-banner">
        <div class="container">
            <div class="innerpage-title flex-center" data-aos="fade-up" data-aos-delay="100">
                <h3>Order Checkout</h3>
            </div>
        </div>
    </div>
    <div class="innerpage-common comm-PTB">
        <main class="form-signin">
            <div class="card">
                <form method="POST" action="<?php echo e(route('user.order.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <!-- <h4 class="card-title"><?php echo e(__('Order')); ?></h4> -->

                        <div class="form-group column" style="float:right">
                            <a href="<?php echo e(route('user.cart.index')); ?>" class="btn btn-dark"><b>Back</b></a>
                        </div>

                        <div class="form-group row">
                            <label for="first_name"
                                class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('First Name')); ?></b></label>
                            <div class="col-sm-9">
                                <input id="first_name" type="text"
                                    class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="first_name"
                                    value="<?php echo e(old('first_name')); ?>" required autocomplete="first_name" autofocus>
                            </div>
                            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group row">
                            <label for="last_name"
                                class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Last Name')); ?></b></label>
                            <div class="col-sm-9">
                                <input id="last_name" type="text"
                                    class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="last_name"
                                    value="<?php echo e(old('last_name')); ?>" required autocomplete="last_name" autofocus>
                            </div>
                            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-group row">
                            <label for="phone"
                                class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Phone')); ?></b></label>

                            <div class="col-sm-9">
                                <input id="phone" type="number"
                                    class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone"
                                    value="<?php echo e(old('phone')); ?>" required autocomplete="phone">

                            </div>
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-group row">
                            <label for="email"
                                class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Email')); ?></b></label>

                            <div class="col-sm-9">
                                <input type="email" id="email"
                                    class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                                    value="<?php echo e(auth()->user()->email); ?>" required autocomplete="email">

                            </div>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group row">
                            <label for="shipping_address"
                                class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Shipping Address')); ?></b></label>

                            <div class="col-sm-9">
                                <input id="shipping_address" type="text"
                                    class="form-control <?php $__errorArgs = ['shipping_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="shipping_address" value="<?php echo e(old('shipping_address')); ?>" required
                                    autocomplete="shipping_address">

                            </div>
                            <?php $__errorArgs = ['shipping_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group row">
                            <label for="order_date"
                                class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Products')); ?></b></label>

                            <div class="col-sm-9">
                                <?php $total = 0; ?>
                                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $total = $total+$cart->product->price; ?>
                                    <div class="col-sm-3"><?php echo e($cart->product->name); ?> * <?php echo e($cart->qty); ?> *
                                        <?php echo e($total); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" value="<?php echo e($total); ?>" name="total">
                            </div>
                            <?php $__errorArgs = ['order_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group row" hidden>
                            <label for="order_date"
                                class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Order Date')); ?></b></label>

                            <div class="col-sm-9">
                                <input type="date" id="order_date"
                                    class="form-control <?php $__errorArgs = ['order_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> summernote"
                                    name="order_date" value="<?php echo e(now()->format('Y-m-d')); ?>" required
                                    autocomplete="order_date">
                                
                            </div>
                            <?php $__errorArgs = ['order_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>



                        <div class="form-group row" hidden>
                            <label
                                class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Order Status')); ?></b></label>
                            <div class="col-md-9">
                                <div class="form-check">
                                    <input type="radio" class="form-check-input" id="customControlValidation1"
                                        name="order_status" value="2" checked required />

                                    <label class="form-check-label mb-0"
                                        for="customControlValidation1"><?php echo e(__('Progress')); ?></label>
                                </div>
                                
                            </div>
                        </div>

                        <div class="border-top">
                            <div class="card-body" style="float:center">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('submit')); ?>

                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </main>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('.summernote').summernote();
        });



        function addrow() {
            var html =
                '<div class="prod_feature">' +
                '<div class="form-group row">' +
                '<label for="title"  class="col-sm-3 text-end control-label col-form-label"><?php echo e(__('Title')); ?>' +
                '</label>' +

                '<div class="col-sm-8">' +
                '<input type="text" name="title[]" class="form-control title"  id="title" required>' +
                '</div>' +
                '<div class="col-sm-1">' +
                '<button type="button" class="btn btn-danger deleteRow">Delete</button>' +
                '</div>' +
                '</div>' +

                '<div class="form-group row">' +
                '<label for="add_description" class="col-sm-3 text-end control-label col-form-label"><?php echo e(__('Description')); ?>' +
                '</label>' +

                '<div class="col-sm-8">' +
                '<textarea class="form-control summernote" name="add_description[]" id="add_description"><?php echo e(old('add_description')); ?></textarea>' +
                '</div>' +
                '</div>' +
                '</div>';

            $('.features').append(html);

            $('.summernote').summernote();
        }

        $(document).on('click', '.deleteRow', function(e) {
            e.preventDefault();
            $(this).closest('.prod_feature').remove();
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.cart.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/user/order/create.blade.php ENDPATH**/ ?>