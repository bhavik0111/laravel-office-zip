<?php
    $global = getSetting();
    //  dd($global);
?>

<footer class="footersection">
    <div class="container">
        <div class="ftnavsubsec">
            <div class="row">
                <div class="col-sm-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="100">
                    <div class="ftaboutsec">
                        
                        <a class="ftabimg" href="index.html"><img src="<?php echo e(asset('public/' . $global->footer_logo)); ?>"
                                alt="" height="200" width="200" /></a>
                        <p><?php echo e($global->about_us); ?></p>
                    </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="200">
                    <div class="quicklink ft-com-list">
                        <h4><?php echo e(__('messages.footer.Quick')); ?></h4>
                        <ul>
                            <li><a href="esim.html"><?php echo e(__('messages.footer.Quicka')); ?></a></li>
                            <li><a href="topup.html"><?php echo e(__('messages.footer.Quickb')); ?></a></li>
                            <li><a href="check-usage.html"><?php echo e(__('messages.footer.Quickc')); ?></a></li>
                            <li><a href="blog.html"><?php echo e(__('messages.footer.Quickd')); ?></a></li>
                            <li><a href="faq.html"><?php echo e(__('messages.footer.Quicke')); ?></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="300">
                    <div class="ft-getintouch ft-com-list">
                        <h4><?php echo e(__('messages.footer.Quickf')); ?></h4>
                        <ul>
                            <li>
                                <i class="fa fa-map-marker"></i><?php echo e($global->address); ?>

                            </li>
                            <li>
                                <a href="tel:1234562505"><i class="fa fa-phone"></i><?php echo e($global->phone); ?></a>
                            </li>
                            <li>
                                <a href="mailto:info@linkesim.com"><i class="fa fa-envelope"></i><?php echo e($global->email); ?></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="400">
                    <div class="keepintouch">
                        <h4><?php echo e(__('messages.footer.Quickg')); ?></h4>
                        <ul>
                            <li><a href="https://www.facebook.com/login/device-based/regular/login/?_rdc=1&_rdr"><i
                                        class="fa fa-facebook"></i></a></li>
                            <li><a
                                    href="https://in.linkedin.com/?src=go-pa&trk=sem-ga_campid.14650114788_asid.151761418307_crid.657403558718_kw.linkedin%20website_d.c_tid.kwd-10521864532_n.g_mt.e_geo.1007759&mcid=6844056167778418689&cid=&gclid=Cj0KCQjwpPKiBhDvARIsACn-gzButJnqZiJvYMkx1YJ6wqkhJhINVbU33sANNuWkcvHsOJXgzyxs7r0aAuCdEALw_wcB&gclsrc=aw.ds"><i
                                        class="fa fa-linkedin"></i></a></li>
                            <li><a href="https://www.instagram.com/accounts/login/"><i class="fa fa-instagram"></i></a>
                            </li>
                        </ul>
                        
                        <div class="stripe-logo"><img src="<?php echo e(asset('public/' . $global->payment_logo)); ?>"
                                height="100" width="100" alt=""></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyrightsec">
            &copy;<?php echo e($global->copyright_msg); ?> | <a href="#"><?php echo e(__('messages.footer.Quickg')); ?></a>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/user/layout/footer.blade.php ENDPATH**/ ?>