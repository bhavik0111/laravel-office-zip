<?php $__env->startSection('content'); ?>

<?php
    $global = getSetting();
    //  dd($global);
?>

    <div class="homemanibanner">
        <div class="container">
            <div class="home-searchtitle">
                
                <h2 data-aos="fade-up" data-aos-delay="100"><?php echo e(__('messages.home_container')); ?></h2>

                
                <h6 data-aos="fade-up" data-aos-delay="200"><?php echo e(__('messages.home1')); ?></h6>

                <div class="homesearch" data-aos="fade-up" data-aos-delay="300">
                    
                    <input class="form-control" type="text" name="search" placeholder="<?php echo e(__('messages.home2')); ?>">
                    <input class="input-search-icon" type="submit" name="submit" value="">
                </div>
            </div>
            <div class="swiper mySwiper homemainslider" data-aos="fade-up" data-aos-delay="400">
                <div class="swiper-wrapper">

                        <?php $__currentLoopData = $allcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide">
                                <div class="flagbg">
                                    <a href="<?php echo e(route('user.category.show', ['id' => $category->id])); ?>">
                                        <img src="<?php echo e(asset('public/' . $category->image)); ?>" alt="">
                                        <h6><?php echo e($category->name); ?></h6>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </div>
    <div class="innerpage-banner">
        <div class="container">
            <div class="innerpage-title flex-center" data-aos="fade-up" data-aos-delay="100">
                
                <h3><?php echo e(__('messages.product.all_products')); ?></h3>
            </div>
        </div>
    </div>
    <div class="innerpage-common comm-PTB">
        <div class="best-offer-sec comm-PTB-half">
            <div class="container">

                <?php if(session()->has('msg')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('msg')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('error_msg')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session()->get('error_msg')); ?>

                    </div>
                <?php endif; ?>

                <div class="row best-offers">

                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainkey => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-12 col-lg-4" data-aos="fade-up" data-aos-delay="200">
                            <div class="best-offer-box skyblue-box">
                                <div class="offer-card-det" style="background-color:<?php echo e($product->colour); ?>">
                                    <div class="offer-card"><img src="<?php echo e(asset('public/' . $product->image)); ?>"
                                            alt="">
                                    </div>
                                    <div class="offer-card-name">
                                        <h6><?php echo e($product->name); ?></h6>
                                        <p><?php echo e($product->category->name); ?></p>
                                    </div>
                                </div>
                                <div class="price-rating flex-cn-sb">
                                    <div class="rating-star">
                                        <i class="fa fa-star yellow-star"></i>
                                        <i class="fa fa-star yellow-star"></i>
                                        <i class="fa fa-star yellow-star"></i>
                                        <i class="fa fa-star yellow-star"></i>
                                        <i class="fa fa-star lightblue-star"></i>
                                    </div>

                                    <div class="card-price">
                                        <span>
                                             <?php echo money($product->price,$global->currency); ?>
                                        </span>
                                    </div>

                                    
                                </div>
                                <div class="card-box-padd">
                                    <div class="card-list-sec">
                                        <div class="card-list flex-cn-sb">
                                            <div class="card-pro"><?php echo e(__('Data')); ?>

                                                <div class="info-tooltip"><i class="bi bi-question-circle"></i>
                                                    <div class="show-info-tooltip"><?php echo $product->data_detail; ?>

                                                        <i class="pointer"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-pro-res"><?php echo e($product->data); ?></div>
                                        </div>


                                        <div class="card-list flex-cn-sb">
                                            <div class="card-pro"><?php echo e(__('Calls')); ?>

                                                <div class="info-tooltip"><i class="bi bi-question-circle"></i>
                                                    <div class="show-info-tooltip"><?php echo $product->calls_detail; ?>

                                                        <i class="pointer"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-pro-res"><?php echo e($product->calls); ?></div>
                                        </div>

                                        <div class="card-list flex-cn-sb">
                                            <div class="card-pro"><?php echo e(__('SMS')); ?>

                                                <div class="info-tooltip"><i class="bi bi-question-circle"></i>
                                                    <div class="show-info-tooltip"><?php echo $product->sms_detail; ?>

                                                        <i class="pointer"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-pro-res">
                                                <?php echo e($product->sms); ?>

                                            </div>
                                        </div>

                                        <div class="card-list flex-cn-sb">
                                            <div class="card-pro">Credit validity
                                                <div class="info-tooltip"><i class="bi bi-question-circle"></i>
                                                    <div class="show-info-tooltip"><?php echo $product->credit_validity_detail; ?>

                                                        <i class="pointer"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-pro-res">
                                                <?php echo e($product->credit_validity); ?>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="sim-show-detail" id="sim-show-detail<?php echo e($mainkey); ?>">
                                        <div class="accordion" id="accordionExample">

                                            <?php $__currentLoopData = $product->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="accordion-item">
                                                    <h2 class="accordion-header" id="acc-1">
                                                        <button class="accordion-button collapsed" type="button"
                                                            data-bs-toggle="collapse"
                                                            data-bs-target="#col-<?php echo e($mainkey); ?>-<?php echo e($key); ?>"
                                                            aria-expanded="false" aria-controls="col-1">
                                                            <?php echo e($feature->title); ?></button>
                                                    </h2>
                                                    <div id="col-<?php echo e($mainkey); ?>-<?php echo e($key); ?>"
                                                        class="accordion-collapse collapse" aria-labelledby="acc-1"
                                                        data-bs-parent="#accordionExample">
                                                        <div class="accordion-body">
                                                            <div class="sim-acc-det">
                                                                <ul>
                                                                    <li><?php echo $feature->description; ?></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>
                                    </div>

                                    <div class="offer-list-btn flex-cn-sb">
                                        <a href="javascript:void(0);" class="btn btn-primary black-btn more-det-btn"
                                            onclick="$('#sim-show-detail<?php echo e($mainkey); ?>').slideToggle(400);">More
                                            details</a>
                                        <a href="<?php echo e(route('user.cart.cart', ['id' => $product->id])); ?>"
                                            class="btn btn-primary blue-btn">
                                            Buy now
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="d-flex justify-content-center">
                        <?php echo $products->links(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/home.blade.php ENDPATH**/ ?>