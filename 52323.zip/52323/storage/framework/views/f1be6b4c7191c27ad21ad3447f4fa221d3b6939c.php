<div class="bg-dark pt-5" style="min-height: calc(300vh - 50px);">
    <ul>
        <?php if(auth()->guard()->check()): ?>
            <!-- <li class="p-2 text-white"><a class="text-white" href="<?php echo e(route('user.home')); ?>">Home</a></li> -->
            <li class="p-2 text-white"><a class="text-white" href="<?php echo e(route('user.profile.eprofile')); ?>">Home</a></li>
            <li class="p-2 text-white"><a class="text-white" href="<?php echo e(route('user.profile.profile')); ?>">Edit Profile</a></li>
            <li class="p-2 text-white"><a class="text-white" href="<?php echo e(route('user.order.index')); ?>">All Order</a></li>
            <li class="p-2 text-white"><a class="text-white" href="<?php echo e(route('user.cart.index')); ?>">Cart</a></li>
        <?php endif; ?>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/user/layout/sidebar.blade.php ENDPATH**/ ?>