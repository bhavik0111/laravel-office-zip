<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    protected $dirPath = 'images/category_images/';

    public function index(Request $req)   //Category LISTING...
    {
        $category = Category::get();
        return view('admin.category.index', compact('category'));
    }

    public function create($language = 'en')
    {
        if ($language == 'fr') {
            return view('admin.category.createfrench', compact('language'));
        }

        if ($language == 'sp') {
            return view('admin.category.createspanish', compact('language'));
        }

        if ($language == 'en') {
            return view('admin.category.create', compact('language'));
        }
    }

    public function store(Request $req)     //INSERT IN DB...
    {
        $req->validate([
            'cat_image' => ['required'],
            'status' => 'required'
        ]);

        $category = new Category();

        // $category->language = $req->language;

        if ($req->language == 'en') {
            $category->name = $req->name;
            $category->description = $req->description;
            $category->status = $req->status;


            if ($req->has('cat_image')) {
                // folder name where you wan to upload
                $image = $req->file('cat_image'); // name of your input field

                $image_name = rand() . '.' . $image->getClientOriginalExtension();
                $image->move(public_path($this->dirPath), $image_name); // for store in folder

                $category->image = $this->dirPath . $image_name; // for store in database
            }
        }


        if ($req->language == 'fr') {

            $category->name_fr = $req->name_fr;
            $category->description_fr = $req->description_fr;

            $image = $req->file('cat_image'); // name of your input field
            $image_name = rand() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path($this->dirPath), $image_name); // for store in folder
            $category->image_fr = $this->dirPath . $image_name; // for store in database

            // $category->save();

        } else if ($req->language == 'sp') {
            $category->name_sp = $req->name_sp;
            $category->description_sp = $req->description_sp;

            $image = $req->file('cat_image'); // name of your input field
            $image_name = rand() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path($this->dirPath), $image_name); // for store in folder
            $category->image_sp = $this->dirPath . $image_name; // for store in database

            // $category->save();
        }

        $category->save();

        return redirect()->route('admin.category.index')->with('msg', 'Record Successfully Inserted');
    }

    public function edit($id)
    {
        // user EDIT form display...
        $category = Category::where('id', $id)->first();
        if (empty($category)) {
            return redirect()->route('admin.category.index');
        }
        return view('admin.category.edit', compact('category'));
    }

    function update(Request $req)
    {
        //user UPDATE IN DB...
        $category = Category::where('id', $req->id)->first();
        // dd($req);
        $category->name = $req->name;
        $category->description = $req->description;
        $category->status = $req->status;

        if ($req->has('cat_image')) {
            //=>this condition use if edit form and not upload
            //image then consider old image
            if (file_exists(public_path($category->image))) {
                @unlink(public_path($category->image));
            }
            $image = $req->file('cat_image'); // name of your input field

            $image_name = rand() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path($this->dirPath), $image_name); // for store in folder

            $category->image = $this->dirPath . $image_name; // for store in database
        }

        $category->save();

        return redirect()
            ->route('admin.category.index')
            ->with('msg', 'Record Updated');
    }

    function destroy($id)
    {
        //FOR Category DELETE...
        $category = Category::where('id', $id)
            ->get()
            ->first();
        if (file_exists(public_path($category->image))) {
            @unlink(public_path($category->image));
        }
        $category->delete();
        return redirect()
            ->route('admin.category.index')
            ->with('msg', 'Record Deleted');
    }
}
