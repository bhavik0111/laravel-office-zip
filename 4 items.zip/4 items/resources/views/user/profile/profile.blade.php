@extends('user.cart.layout.master')

@section('content')
<div class="innerpage-banner">
    <div class="container">
        <div class="innerpage-title flex-center" data-aos="fade-up" data-aos-delay="100">
            <h3>Edit Profile</h3>
        </div>
    </div>
</div>
<div class="faq-page content comm-PTB">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2 bg-dark">
                @include('user.profile.sidebar')
            </div>
            <div class="col-md-10">
                <div class="innerpage-common comm-PTB">
                    <main class="form-signin">
                        <div class="card">
                            <form action="{{ route('user.profile.update') }}" method="POST">
                                @csrf
                                <div class="card-body">
                                    <!-- <h4 class="card-title">Update Profile</h4> -->

                                    <!-- <div class="card-body">
                                        <div class="form-group column" style="float:right">
                                            <a href="{{ route('user.index') }}" class="btn btn-dark"><b>Back</b></a>
                                        </div>
                                    </div> -->

                                    <div class="form-group row">
                                        <label for="name"
                                            class="col-sm-3 text-end control-label col-form-label"><b>First
                                                Name</b></label>
                                        <div class="col-sm-9">
                                            <input type="text"
                                                class="form-control @error('name') is-invalid @enderror"
                                                value="{{ old('name', $user->name) }}" id="name" name="name"
                                                placeholder="your name">

                                        </div>
                                        @error('name')
                                            <div class="invalid-feedback">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>

                                    <div class="form-group row">
                                        <label for="last_name"
                                            class="col-sm-3 text-end control-label col-form-label"><b>Last
                                                Name</b></label>
                                        <div class="col-sm-9">
                                            <input type="text"
                                                class="form-control @error('last_name') is-invalid @enderror"
                                                value="{{ old('last_name', $user->last_name) }}" id="last_name"
                                                name="last_name" placeholder="your last_name">

                                        </div>
                                        @error('last_name')
                                            <div class="invalid-feedback">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>

                                    <div class="form-group row">
                                        <label for="email"
                                            class="col-sm-3 text-end control-label col-form-label"><b>Email</b></label>
                                        <div class="col-sm-9">
                                            <input type="email"
                                                class="form-control @error('email')is-invalid @enderror"
                                                value="{{ old('email', $user->email) }}" id="email" name="email"
                                                placeholder="name@example.com">

                                            <input type="hidden" name="id" value="{{ $user->id }}">
                                        </div>
                                        @error('email')
                                            <div class="invalid-feedback">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>

                                    <div class="form-group row">
                                        <label for="password"
                                            class="col-sm-3 text-end control-label col-form-label"><b>Password</b></label>
                                        <div class="col-sm-9">
                                            <input type="password"
                                                class="form-control @error('password') is-invalid @enderror"
                                                name="password" id="password" placeholder="Password">
                                        </div>

                                        @error('password')
                                            <div class="invalid-feedback">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>

                                    <div class="form-group row">
                                        <label for="confirm-password"
                                            class="col-sm-3 text-end control-label col-form-label"><b>Confirm
                                                Password</b></label>
                                        <div class="col-sm-9">
                                            <input type="password"
                                                class="form-control @error('confirm-password') is-invalid @enderror"
                                                name="confirm-password" id="confirm-password"
                                                placeholder="confirm-password">
                                        </div>
                                        @error('confirm-password')
                                            <div class="invalid-feedback">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>

                                </div>
                                <div class="border-top">
                                    <div class="card-body">
                                        <button type="submit" name="uedit" class="btn btn-primary">
                                            Edit
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </main>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
