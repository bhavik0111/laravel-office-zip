@extends('user.cart.layout.master')

@section('content')
    <div class="innerpage-banner">
        <div class="container">
            <div class="innerpage-title flex-center" data-aos="fade-up" data-aos-delay="100">
                <h3>The Best eSIMs in 2023</h3>
            </div>
        </div>
    </div>
    <div class="blog-list comm-PTB">
        <div class="container">

            <div class="blog-detail-page" data-aos="fade-up" data-aos-delay="200">
                <div class="blog-det-img"><a href="blog-detail.html"><img src="{{ asset('public/' . $blog->image) }}"
                            alt=""></a></div>
                <div class="blog-cont-box">
                    <div class="blog-det-cat mb-4">
                        <ul class="flex-center flex-wrap">
                            <li><span>Date:</span> February 22, 2023</li>
                            <li><span>Category:</span> {{ $blog->category->name }}</li>
                        </ul>
                    </div>
                    <div class="blog-cont-det">

                        <h3>{{ $blog->title }}</h3>
                        <p>{{ $blog->description }}</p>
                        <ul>
                            <li>Lorem Ipsum is simply dummy industry</li>
                            <li>Lorem Ipsum is simply dummy text typesetting industry</li>
                            <li>Lorem Ipsum is of the printing and typesetting industry</li>
                            <li>simply dummy printing and typesetting industry</li>
                            <li>printing and typesetting industry</li>
                        </ul>
                        {{-- <h3>What is Data Roaming?</h3>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
                            the industry's standard dummy text ever. when an unknown printer took a galley of type and
                            scrambled it to make a type specimen book. It has survived.</p>
                        <ol>
                            <li>It has survived not only five centuries, but also the leap into electronic typesetting,
                                remaining essentially unchanged. of type and scrambled it to make a type specimen book. It
                                has survived not only five centuries, but also the leap into electronic typesetting,
                                remaining essentially unchanged.</li>
                            <li>simply dummy printing and typesetting industry typesetting, remaining essentially unchanged.
                                of type and scrambled it to make a type specimen book. It has survived not only five
                                centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                                simply dummy printing and typesetting industry typesetting, remaining essentially unchanged.
                                of type and scrambled it to make a type specimen book. It has survived not only five
                                centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                            </li>
                            <li>electronic typesetting, remaining essentially unchanged. of type and scrambled it to make a
                                type specimen book. It has survived not only five centuries, but also the leap into
                                electronic typesetting, remaining essentially unchanged.</li>
                        </ol>
                        <h3>Advantages of Using eSIM for Roaming</h3>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been.
                            when an unknown printer took a galley</p>
                        <p>It has survived not only five centuries, but also the leap into electronic typesetting, remaining --}}
                        essentially unchanged. of type and scrambled it to make a type specimen book. It has survived
                        not only five centuries, but also the leap into electronic typesetting, remaining essentially
                        unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem
                        Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker
                        including versions of Lorem Ipsum.</p>
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection
