@extends('user.cart.layout.master')

@section('content')
    <div class="innerpage-banner">
        <div class="container">
            <div class="innerpage-title flex-center" data-aos="fade-up" data-aos-delay="100">
                <h3>Blog</h3>
            </div>
        </div>
    </div>

    <div class="blog-list comm-PTB-half">
        <div class="container">
            <div class="row">

                @foreach ($blogs as $blog)
                    <div class="col-sm-6 col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="100">
                        <div class="blog-box">

                            <div class="blog-img">
                                <a href="{{ route('user.blog.blog_detail') }}"><img
                                        src="{{ asset('public/' . $blog->image) }}" alt="">
                                </a>
                            </div>
                            <div class="blog-cont-box">
                                <div class="blog-date">February 22, 2023</div>
                                <h4><a href="blog-detail.html">{{ $blog->title }}</a></h4>
                                <div class="blog-cont-det">
                                    {{ $blog->description }}
                                </div>
                                <div class="readmorelink">

                                    <a href="{{ route('user.blog.blog_detail', ['id' => $blog->id]) }}"
                                        class="text-link">Read
                                        More</a>
                                </div>
                            </div>

                        </div>
                    </div>
                @endforeach
                {!! $blogs->links() !!}

            </div>

            <div class="daspagination">
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center">
                        <li class="page-item disabled"><a class="page-link" href="" tabindex="-1"><i
                                    class="fa fa-angle-left"></i></a></li>
                        <li class="page-item"><a class="page-link" href="">1</a></li>
                        <li class="page-item"><a class="page-link" href="">2</a></li>
                        <li class="page-item active"><a class="page-link" href="">3</a></li>
                        <li class="page-item"><a class="page-link" href="">4</a></li>
                        <li class="page-item"><a class="page-link" href="">5</a></li>
                        <li class="page-item"><a class="page-link" href=""><i class="fa fa-angle-right"></i></a></li>
                    </ul>
                </nav>
            </div>

        </div>
    </div>
@endsection
