<?php
use App\Models\GlobalSetting;

if(!function_exists('getSetting')){

    // function CheckRouteExist()
    //     {
    //         $global = GlobalSetting::first();
    //         return !empty($global);
    //     }

        // function getSetting($key)
        // {
        //     $global = GlobalSetting::select($key)->pluck($key)->first();
        //     return ($global);
        // }
        function getSetting()
        {
            $global = GlobalSetting::first();
            return ($global);
        }
}
