<?php

namespace App\Http\Controllers;
use App\Models\GlobalSetting;

use Illuminate\Http\Request;

class GlobalSettingController extends Controller
{
    protected $dirPath = 'images/global_images/';

    public function create(Request $request)  //<--(Globalsetting FORM)-->
    {
        $global = GlobalSetting::get()->first();
        return view('admin.globalsetting.create', compact('global'));
    }

    public function store(Request $request)   //<--(INSERT IN DB...)-->
    {
        $request->validate([
            'site_title' => ['required'],
            'address' => ['required'],
            'phone' => ['required'],
            'email' => ['required'],
            'facebook_url' => ['required'],
            'linkdin_url' => ['required'],
            'insta_url' => ['required'],
            'about_us' => ['required'],
            'copyright_msg' => ['required'],
        ]);

        // $global = new GlobalSetting();
        // $global = GlobalSetting::where('id', $request->id)->get()->first();

        $global = GlobalSetting::firstOrNew(['id' => 1]);

        $global->site_title = $request->site_title;
        $global->address = $request->address;
        $global->phone = $request->phone;
        $global->email = $request->email;
        $global->facebook_url = $request->facebook_url;
        $global->linkdin_url = $request->linkdin_url;
        $global->insta_url = $request->insta_url;
        $global->about_us = $request->about_us;
        $global->copyright_msg = $request->copyright_msg;

            if ($request->has('logo')) {
                    if (file_exists(public_path($global->logo))) {
                        @unlink(public_path($global->logo));
                    }
                $image = $request->file('logo'); // name of your input field
                $image_name = rand() . '.' . $image->getClientOriginalExtension();
                $image->move(public_path($this->dirPath), $image_name); // for store in folder
                $global->logo = $this->dirPath . $image_name; // for store in database
            }

            if ($request->has('faceicon')) {
                    if (file_exists(public_path( $global->faceicon))) {
                        @unlink(public_path( $global->faceicon));
                    }
                $image = $request->file('faceicon');
                $image_name = rand() . '.' . $image->getClientOriginalExtension();
                $image->move(public_path($this->dirPath), $image_name);
                $global->faceicon = $this->dirPath . $image_name;
            }

            if ($request->has('payment_logo')) {
                    if (file_exists(public_path($global->payment_logo))) {
                        @unlink(public_path($global->payment_logo));
                    }
                $image = $request->file('payment_logo');
                $image_name = rand() . '.' . $image->getClientOriginalExtension();
                $image->move(public_path($this->dirPath), $image_name);
                $global->payment_logo = $this->dirPath . $image_name;
            }

            if ($request->has('footer_logo')) {
                    if (file_exists(public_path($global->footer_logo))) {
                        @unlink(public_path($global->footer_logo));
                    }
                $image = $request->file('footer_logo');
                $image_name = rand() . '.' . $image->getClientOriginalExtension();
                $image->move(public_path($this->dirPath), $image_name);
                $global->footer_logo = $this->dirPath . $image_name;
            }

        $global->save();

        return redirect()->route('admin.globalsetting.create')->with('msg', 'Setting updated');
    }



}
