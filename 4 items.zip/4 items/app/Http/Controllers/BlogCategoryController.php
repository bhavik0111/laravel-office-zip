<?php

namespace App\Http\Controllers;
use App\Models\BlogCategory;
use Illuminate\Http\Request;

class BlogCategoryController extends Controller
{
    public function categorycreate(Request $request)  //<--(blogs category FORM CREATE)-->
    {
        return view('admin.blogs.category.create');
    }

    public function categorystore(Request $request)   //<--(INSERT IN DB...)-->
    {
        $request->validate([

            'name' => ['required'],
            'description' => ['required'],
            'status' => 'required'
        ]);


        $category = new BlogCategory();
        $category->name = $request->name;
        $category->description = $request->description;
        $category->status = $request->status;


        $category->save();

        return redirect()->route('admin.blogs.index')->with('msg', 'Category Successfully Inserted');
    }






}
