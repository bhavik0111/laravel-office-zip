<?php

namespace App\Http\Controllers;

use App;
use Illuminate\Http\Request;
use App\Models\GlobalSetting;

class LangController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
    */
    public function index()
    {
        return view('lang');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
    */
    public function change(Request $request)
    {
        App::setLocale($request->language);
        session()->put('locale', $request->language);

        $gb = GlobalSetting::get()->first();
        $gb->language= $request->language;
        // dd($gb);
        $gb->save();

        return redirect()->back();
    }
}
