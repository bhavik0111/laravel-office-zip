<?php $__env->startSection('content'); ?>

    <div class="innerpage-banner">
         <div class="container">
            <div class="innerpage-title flex-center" data-aos="fade-up" data-aos-delay="100">
               <h3>All orders</h3>
            </div>
         </div>
    </div>
    <div class="innerpage-common comm-PTB">
        <div class="row">
            <div class="col-md-2 bg-dark">
                <?php echo $__env->make('user.profile.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md-10">

                <!-- (FOR MSG) -->
                <?php if(session()->has('msg')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('msg')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('error_msg')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session()->get('error_msg')); ?>

                    </div>
                <?php endif; ?>
                <!-- (END MSG) -->
                <div class="card mb-3">
                    <div class="card-body">
                        <div class="card-header row">
                            <!-- <h4 class="card-title mb-3"><b>All orders</b></h4> -->
                            <!-- <div class="text-end">
                                <a href="<?php echo e(route('user.home')); ?>" class="btn btn-dark"><b> <?php echo e(__('Back')); ?></b></a>
                            </div> -->
                        </div>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th><b>ID</b></th>
                                        <th><b>Order Date</b></th>
                                        <th><b>First Name</b></th>
                                        <th><b>Last name</b></th>
                                        <th><b>Phone</b></th>
                                        <th><b>Total Amount</b></th>
                                        <th><b>Status</b></th>
                                        <th><b>Action</b></th>
                                    </tr>
                                </thead>

                                <?php
                                    $global = getSetting();
                                    //  dd($global);
                                ?>

                                <tbody>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            

                                            <td><?php echo e($order->order_id); ?></td>
                                            <td><?php echo e($order->order_date); ?></td>
                                            <td><?php echo e($order->first_name); ?></td>
                                            <td><?php echo e($order->last_name); ?></td>
                                            <td><?php echo e($order->phone); ?></td>

                                            <td> <?php echo money($order->total,$order->OrderCurrency->code); ?></td>

                                            
                                            <!-- <td><?php echo e($order->order_status); ?></td> -->

                                            <td>
                                                <?php if($order->order_status == 1): ?>
                                                    <?php echo e('complite'); ?>

                                                <?php endif; ?>
                                                <?php if($order->order_status == 2): ?>
                                                    <?php echo e('progress'); ?>

                                                <?php endif; ?>
                                                <?php if($order->order_status == 0): ?>
                                                    <?php echo e('cencel'); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('user.order.view', ['id' => $order->order_id])); ?>"
                                                    class="btn btn-info"><b><?php echo e(__('view')); ?></b>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('user.cart.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/user/order/index.blade.php ENDPATH**/ ?>