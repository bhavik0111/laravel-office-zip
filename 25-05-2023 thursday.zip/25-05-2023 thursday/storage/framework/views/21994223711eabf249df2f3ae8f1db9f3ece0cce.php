<div class="mt-5">
    <div>
        <ul>
            <?php if(auth()->guard()->check()): ?>
                <li class="p-2 text-white"><a class="text-white" href="<?php echo e(route('user.profile.profile')); ?>">Edit profile</a></li>
                <li class="p-2 text-white"><a class="text-white" href="<?php echo e(route('user.order.index')); ?>">All Order</a></li>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
                    <?php if(auth()->guard()->check()): ?>
                    <li class="p-2 text-white"><a class="text-white" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"><i
                                class="fa fa-power-off me-1 ms-1"></i> Logout</a>
                            </li>
                    <?php endif; ?>
            <?php endif; ?>
        </ul>
    </div>
</div><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/user/profile/sidebar.blade.php ENDPATH**/ ?>