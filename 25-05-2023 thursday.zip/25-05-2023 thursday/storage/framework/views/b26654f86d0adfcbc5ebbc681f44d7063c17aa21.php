<?php $__env->startSection('content'); ?>
    <main class="form-signin">
        <div class="card">
            <form method="POST" action="<?php echo e(route('admin.product.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="form-group column" style="float:right">
                    <a href="<?php echo e(route('admin.product', ['language' => 'sp'])); ?>"
                        class="btn <?php echo e($language == 'sp' ? 'btn-primary' : 'btn-dark'); ?>" name="language"
                        value="sp"><b>Spanish</b></a>
                </div>
                <div class="form-group column" style="float:right">
                    <a href="<?php echo e(route('admin.product', ['language' => 'fr'])); ?>"
                        class="btn <?php echo e($language == 'fr' ? 'btn-primary' : 'btn-dark'); ?>" name="language"
                        value="fr"><b>French</b></a>
                </div>
                <div class="form-group column" style="float:right">
                    <a href="<?php echo e(route('admin.product', ['language' => 'en'])); ?>"
                        class="btn <?php echo e($language == 'en' ? 'btn-primary' : 'btn-dark'); ?>" name="language"
                        value="en"><b>English</b></a>
                </div>

                <div class="card-body">
                    <h4 class="card-title"><?php echo e(__('messages.product.add_product', [], 'fr')); ?></h4>

                    <div class="form-group column" style="float:right">
                        <a href="<?php echo e(route('admin.product.index')); ?>" class="btn btn-dark"><b>Back</b></a>
                    </div>

                    <div class="form-group row">
                        <label for="name_fr"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('messages.product.category', [], 'fr')); ?></b></label>
                        <div class="col-sm-9">
                            <select name="category_id" class="form-control">
                                <option value="" selected>Select Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name_fr); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="name_fr"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('messages.product.name', [], 'fr')); ?></b></label>
                        <div class="col-sm-9">
                            <input id="name_fr" type="text" class="form-control <?php $__errorArgs = ['name_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="name_fr" value="<?php echo e(old('name_fr')); ?>" required autocomplete="name_fr" autofocus>

                                <input type="hidden" name="language" value="<?php echo e($language); ?>">

                            <?php $__errorArgs = ['name_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="cat_image"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Image')); ?></b></label>

                        <div class="col-sm-9">
                            <input id="prod_image" type="file"
                                class="form-control <?php $__errorArgs = ['prod_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="prod_image">
                            <?php $__errorArgs = ['prod_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="price_fr"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('messages.product.price', [], 'fr')); ?></b></label>

                        <div class="col-sm-9">
                            <input id="price_fr" type="number"
                                class="form-control <?php $__errorArgs = ['price_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="price_fr"
                                value="<?php echo e(old('price_fr')); ?>">

                            <?php $__errorArgs = ['price_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="colour_fr"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('messages.product.colour', [], 'fr')); ?></b></label>

                        <div class="col-sm-9">
                            <input type="color" id="colour_fr"
                                class="form-control <?php $__errorArgs = ['colour_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="colour_fr"
                                value="<?php echo e(old('colour_fr')); ?>">

                            <?php $__errorArgs = ['colour_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="data_fr"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('messages.product.data', [], 'fr')); ?></b></label>

                        <div class="col-sm-9">
                            <input id="data_fr" type="text" class="form-control <?php $__errorArgs = ['data_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="data_fr" value="<?php echo e(old('data_fr')); ?>" required autocomplete="data_fr">

                        </div>
                        <?php $__errorArgs = ['data_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <label for="data_detail_fr"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('messages.product.data_detail', [], 'fr')); ?></b></label>

                        <div class="col-sm-9">
                            <textarea id="data_detail_fr" class="form-control <?php $__errorArgs = ['data_detail_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> summernote"
                                name="data_detail_fr" value="<?php echo e(old('data_detail_fr')); ?>" required autocomplete="data_detail_fr"></textarea>

                        </div>
                        <?php $__errorArgs = ['data_detail_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <label for="calls_fr"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('messages.product.calls', [], 'fr')); ?></b></label>

                        <div class="col-sm-9">
                            <input id="calls_fr" type="text"
                                class="form-control <?php $__errorArgs = ['calls_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="calls_fr"
                                value="<?php echo e(old('calls_fr')); ?>" required autocomplete="calls_fr">

                        </div>
                        <?php $__errorArgs = ['calls_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group row">
                        <label for="calls_detail_fr"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('messages.product.calls_detail', [], 'fr')); ?></b></label>

                        <div class="col-sm-9">
                            <textarea id="calls_detail_fr" class="form-control <?php $__errorArgs = ['calls_detail_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> summernote"
                                name="calls_detail_fr" value="<?php echo e(old('calls_detail_fr')); ?>" required autocomplete="calls_detail_fr"></textarea>

                            <?php $__errorArgs = ['calls_detail_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="sms_fr"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('messages.product.sms', [], 'fr')); ?></b>
                        </label>

                        <div class="col-sm-9">
                            <input id="sms_fr" type="text"
                                class="form-control <?php $__errorArgs = ['sms_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="sms_fr"
                                value="<?php echo e(old('sms_fr')); ?>" required autocomplete="sms_fr">

                            <?php $__errorArgs = ['sms_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="sms_detail_fr"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('messages.product.sms_detail', [], 'fr')); ?></b></label>

                        <div class="col-sm-9">
                            <textarea id="sms_detail_fr" class="form-control <?php $__errorArgs = ['sms_detail_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> summernote"
                                name="sms_detail_fr" value="<?php echo e(old('sms_detail_fr')); ?>" required autocomplete="sms_detail_fr">
                            </textarea>

                            <?php $__errorArgs = ['sms_detail_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="credit_validity_fr"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('messages.product.credit_val', [], 'fr')); ?></b></label>

                        <div class="col-sm-9">
                            <input type="text" id="credit_validity_fr"
                                class="form-control <?php $__errorArgs = ['credit_validity_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="credit_validity_fr" value="<?php echo e(old('credit_validity_fr')); ?>" >

                                <?php $__errorArgs = ['credit_validity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="credit_validity_detail_fr"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('messages.product.credit_val_detail', [], 'fr')); ?></b></label>

                        <div class="col-sm-9">
                            <textarea id="credit_validity_detail_fr"
                                class="form-control <?php $__errorArgs = ['credit_validity_detail_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> summernote"
                                name="credit_validity_detail_fr" value="<?php echo e(old('credit_validity_detail_fr')); ?>" required
                                autocomplete="credit_validity_detail_fr"></textarea>

                                <?php $__errorArgs = ['credit_validity_detail_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="description_fr"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('messages.product.description', [], 'fr')); ?></b></label>

                        <div class="col-sm-9">
                            <textarea id="description_fr" class="form-control <?php $__errorArgs = ['description_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> summernote"
                                name="description_fr" value="" required autocomplete="description_fr"></textarea>

                                <?php $__errorArgs = ['description_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="addnewfeature"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('messages.product.additional', [], 'fr')); ?></b></label>

                        <div class="col-sm-9">
                            <button type="button" class="btn btn-primary" onclick="addrow()">
                                <?php echo e(__('messages.product.addnewfeature', [], 'fr')); ?>

                            </button>
                        </div>
                    </div>

                    <div class="features">
                        <!-- (click AddNew all title and description field are placed heare....) -->
                    </div>

                    <div class="form-group row">
                        <label
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('messages.product.status', [], 'fr')); ?></b></label>
                        <div class="col-md-9">
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation1"
                                    name="status"value="1" required />

                                <label class="form-check-label mb-0"
                                    for="customControlValidation1"><?php echo e(__('messages.product.active', [], 'fr')); ?></label>

                            </div>
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation2"
                                    name="status" value="0" required />
                                <label class="form-check-label mb-0"
                                    for="customControlValidation2"><?php echo e(__('messages.product.deactive', [], 'fr')); ?></label>
                            </div>
                        </div>
                    </div>

                    <div class="border-top">
                        <div class="card-body" style="float:center">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('messages.product.submit', [], 'fr')); ?>

                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('.summernote').summernote();
        });



        function addrow() {
            var html =
                '<div class="prod_feature">' +
                '<div class="form-group row">' +
                '<label for="title"  class="col-sm-3 text-end control-label col-form-label"><?php echo e(__('Title')); ?>' +
                '</label>' +

                '<div class="col-sm-8">' +
                '<input type="text" name="title[]" class="form-control title"  id="title" required>' +
                '</div>' +
                '<div class="col-sm-1">' +
                '<button type="button" class="btn btn-danger deleteRow">Delete</button>' +
                '</div>' +
                '</div>' +

                '<div class="form-group row">' +
                '<label for="add_description" class="col-sm-3 text-end control-label col-form-label"><?php echo e(__('Description')); ?>' +
                '</label>' +

                '<div class="col-sm-8">' +
                '<textarea class="form-control summernote" name="add_description[]" id="add_description"><?php echo e(old('add_description')); ?></textarea>' +
                '</div>' +
                '</div>' +
                '</div>';

            $('.features').append(html);

            $('.summernote').summernote();
        }

        $(document).on('click', '.deleteRow', function(e) {
            e.preventDefault();
            $(this).closest('.prod_feature').remove();
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/admin/product/createfrench.blade.php ENDPATH**/ ?>