<?php $__env->startSection('content'); ?>
    <main class="form-signin">
        <div class="card">
            <form method="POST" action="<?php echo e(route('admin.product.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="card-body">
                    <h4 class="card-title"><?php echo e(__('Create Product')); ?></h4>

                    <div class="form-group column" style="float:right">
                        <a href="<?php echo e(route('admin.product.index')); ?>" class="btn btn-dark"><b>Back</b></a>
                    </div>

                    <div class="form-group row">
                        <label for="name"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Category')); ?></b></label>
                        <div class="col-sm-9">
                            <select name="category_id" class="form-control">
                                <option value="" selected>Select Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>



                    <div class="form-group row">
                        <div class="form-group column" style="float:right">
                            <a href="#" class="btn btn-primary"
                                onclick="changeinput('sp');"><b>Spanish</b></a>

                            <a href="#" class="btn btn-primary"
                                onclick="changeinput('fr');"><b>French</b></a>

                            <a href="#" class="btn btn-primary"
                                onclick="changeinput('en');"><b>English</b></a>
                        </div>

                        <?php
                           $default = getDefaultLang();
                        //    dd($default);
                        ?>

                        <label for="name"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Name')); ?></b>
                        </label>

                        <div class="col-sm-9">
                            <div class="langdiv" id="inputdiv_en"
                                style="display: <?php echo e($default == 'en' ? 'block' : 'none'); ?>">
                                
                                <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="name" value="<?php echo e(old('name')); ?>" placeholder="en">

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="langdiv" id="inputdiv_fr"
                                style="display: <?php echo e($default == 'fr' ? 'block' : 'none'); ?>">
                                
                                <input type="text" class=" form-control <?php $__errorArgs = ['name_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="name_fr" value="<?php echo e(old('name_fr')); ?>" placeholder="fr">

                                <?php $__errorArgs = ['name_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="langdiv" id="inputdiv_sp"
                                style="display: <?php echo e($default == 'sp' ? 'block' : 'none'); ?>">
                                
                                <input type="text" class="form-control <?php $__errorArgs = ['name_sp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="name_sp" value="<?php echo e(old('name_sp')); ?>" placeholder="sp">

                                <?php $__errorArgs = ['name_sp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="cat_image"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Image')); ?></b></label>

                        <div class="col-sm-9">
                            <input id="prod_image" type="file"
                                class="form-control <?php $__errorArgs = ['prod_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="prod_image">


                            <?php $__errorArgs = ['prod_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="price"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Price')); ?></b></label>

                        <div class="col-sm-9">
                            <input id="price" type="number" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="price" value="<?php echo e(old('price')); ?>" required autocomplete="price">

                        </div>
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <label for="colour"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Colour')); ?></b></label>

                        <div class="col-sm-9">
                            <input type="color" id="colour" class="form-control <?php $__errorArgs = ['colour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="colour" value="<?php echo e(old('colour')); ?>" required autocomplete="colour">

                        </div>
                        <?php $__errorArgs = ['colour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <label for="data"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Data')); ?></b></label>

                        <div class="col-sm-9">
                            <input id="data" type="text" class="form-control <?php $__errorArgs = ['data'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="data" value="<?php echo e(old('data')); ?>" required autocomplete="data">

                        </div>
                        <?php $__errorArgs = ['data'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <label for="data_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Data detail')); ?></b></label>

                        <div class="col-sm-9">
                            <textarea id="data_detail" class="form-control <?php $__errorArgs = ['data_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> summernote"
                                name="data_detail" value="<?php echo e(old('data_detail')); ?>" required autocomplete="data_detail"></textarea>

                        </div>
                        <?php $__errorArgs = ['data_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <label for="calls"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Calls')); ?></b></label>

                        <div class="col-sm-9">
                            <input id="calls" type="text"
                                class="form-control <?php $__errorArgs = ['calls'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="calls"
                                value="<?php echo e(old('calls')); ?>" required autocomplete="calls">

                        </div>
                        <?php $__errorArgs = ['calls'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group row">
                        <label for="calls_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Calls detail')); ?></b></label>

                        <div class="col-sm-9">
                            <textarea id="calls_detail" class="form-control <?php $__errorArgs = ['calls_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> summernote"
                                name="calls_detail" value="<?php echo e(old('calls_detail')); ?>" required autocomplete="calls_detail"></textarea>

                        </div>
                        <?php $__errorArgs = ['calls_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <label for="sms"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('SMS')); ?></b></label>

                        <div class="col-sm-9">
                            <input id="sms" type="text" class="form-control <?php $__errorArgs = ['sms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="sms" value="<?php echo e(old('sms')); ?>" required autocomplete="sms">

                        </div>
                        <?php $__errorArgs = ['sms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group row">
                        <label for="sms_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('SMS detail')); ?></b></label>

                        <div class="col-sm-9">
                            <textarea id="sms_detail" class="form-control <?php $__errorArgs = ['sms_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> summernote"
                                name="sms_detail" value="<?php echo e(old('sms_detail')); ?>" required autocomplete="sms_detail"></textarea>

                        </div>
                        <?php $__errorArgs = ['sms_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <label for="credit_validity"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Credit validity')); ?></b></label>

                        <div class="col-sm-9">
                            <input id="credit_validity" type="text"
                                class="form-control <?php $__errorArgs = ['credit_validity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="credit_validity" value="<?php echo e(old('credit_validity')); ?>" required
                                autocomplete="credit_validity">

                        </div>
                        <?php $__errorArgs = ['credit_validity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group row">
                        <label for="credit_validity_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Credit validity detail')); ?></b></label>

                        <div class="col-sm-9">
                            <textarea id="credit_validity_detail"
                                class="form-control <?php $__errorArgs = ['credit_validity_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> summernote"
                                name="credit_validity_detail" value="<?php echo e(old('credit_validity_detail')); ?>" required
                                autocomplete="credit_validity_detail"></textarea>

                        </div>
                        <?php $__errorArgs = ['credit_validity_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <label for="description"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Description')); ?></b></label>

                        <div class="col-sm-9">
                            <textarea id="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> summernote"
                                name="description" value="" required autocomplete="description"></textarea>

                        </div>
                        <?php $__errorArgs = ['Description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <label for="description"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Additional Features')); ?></b></label>

                        <div class="col-sm-9">
                            <button type="button" class="btn btn-primary" onclick="addrow()">
                                <?php echo e(__('AddNewFeature')); ?>

                            </button>
                        </div>
                    </div>

                    <div class="features">
                        <!-- (click AddNew all title and description field are placed heare....) -->
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Status')); ?></b></label>
                        <div class="col-md-9">
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation1"
                                    name="status"value="1" required />

                                <label class="form-check-label mb-0"
                                    for="customControlValidation1"><?php echo e(__('Active')); ?></label>

                            </div>
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation2"
                                    name="status" value="0" required />
                                <label class="form-check-label mb-0"
                                    for="customControlValidation2"><?php echo e(__('Deactive')); ?></label>
                            </div>
                        </div>
                    </div>

                    <div class="border-top">
                        <div class="card-body" style="float:center">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('submit')); ?>

                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        function changeinput(language) {
            $(".langdiv").css('display', 'none');
            $("#inputdiv_" + language).css('display', 'block');
        }
    </script>

    <script>
        $(document).ready(function() {
            $('.summernote').summernote();
        });



        function addrow() {
            var html =
                '<div class="prod_feature">' +
                '<div class="form-group row">' +
                '<label for="title"  class="col-sm-3 text-end control-label col-form-label"><?php echo e(__('Title')); ?>' +
                '</label>' +

                '<div class="col-sm-8">' +
                '<input type="text" name="title[]" class="form-control title"  id="title" required>' +
                '</div>' +
                '<div class="col-sm-1">' +
                '<button type="button" class="btn btn-danger deleteRow">Delete</button>' +
                '</div>' +
                '</div>' +

                '<div class="form-group row">' +
                '<label for="add_description" class="col-sm-3 text-end control-label col-form-label"><?php echo e(__('Description')); ?>' +
                '</label>' +

                '<div class="col-sm-8">' +
                '<textarea class="form-control summernote" name="add_description[]" id="add_description"><?php echo e(old('add_description')); ?></textarea>' +
                '</div>' +
                '</div>' +
                '</div>';

            $('.features').append(html);

            $('.summernote').summernote();
        }

        $(document).on('click', '.deleteRow', function(e) {
            e.preventDefault();
            $(this).closest('.prod_feature').remove();
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/admin/product/create.blade.php ENDPATH**/ ?>