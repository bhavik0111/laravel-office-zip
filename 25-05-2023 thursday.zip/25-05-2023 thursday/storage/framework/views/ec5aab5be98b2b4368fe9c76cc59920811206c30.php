<?php
    $currency = getcurrency();
    //  dd($global);
?>

<header class="hedcontainer">
    <div class="hedbluebg">
        <div class="container">
            <div class="topsocialcont d-flex align-items-center  justify-content-between flex-wrap py-2">
                <div class="top-social">
                    <ul>
                        <li><a href=""><i class="fa fa-facebook"></i></a></li>
                        <li><a href=""><i class="fa fa-linkedin"></i></a></li>
                        <li><a href=""><i class="fa fa-instagram"></i></a></li>
                    </ul>
                </div>
                <div class="currency-language d-flex align-items-center justify-content-center flex-wrap">
                    <ul class="flex-center top-currency">

                        <?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currencys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                
                                <a href="<?php echo e(route('currency', ['currency' => $currencys->id])); ?>">
                                    <b><?php echo e($currencys->symbole); ?></b>

                                    
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    </ul>

                    <div class="languagesec">
                        <select class="tpusrinfo usertrgr changeLang">
                            <?php
                                $languages = getLang();
                            ?>

                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($language->code); ?>"
                                    <?php echo e(session()->get('locale') == $language->code ? 'selected' : ''); ?>>
                                    <?php echo e($language->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="head-sec navesticky sticky">
        <div class="container">
            <div class="headerdflex d-flex align-items-center justify-content-between py-2">
                <div class="hedlogo">
                    
                    <a href="<?php echo e(route('user.home')); ?>">
                        <img src="<?php echo e(asset('public/' . $global->logo)); ?>" height="200" width="200" alt="">
                    </a>
                </div>
                <div class="hedright">
                    <div id="cssmenu">
                        <ul>
                            <li class="active"><a href="<?php echo e(route('user.home')); ?>"><?php echo e(__('messages.header.eSIM')); ?></a></li> 
                            
                            <li><a href="<?php echo e(route('user.blog.blog')); ?>"><?php echo e(__('messages.header.blog')); ?></a></li> 
                            <li><a href="<?php echo e(route('user.faqs.faqs')); ?>"><?php echo e(__('messages.header.help')); ?></a></li>
                            <?php if(auth()->guard()->check()): ?>
                                <li><a href="<?php echo e(route('user.cart.index')); ?>"><?php echo e(__('messages.header.cart')); ?></a></li>
                                <li><a href="<?php echo e(route('user.profile.index')); ?>"><?php echo e(__('messages.header.profile')); ?></a></li>
                            <?php endif; ?>


                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                            <li>
                                <?php if(auth()->guard()->check()): ?>
                                    <!-- <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                                    onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();"><i
                                                        class="fa fa-power-off me-1 ms-1"></i> Logout</a> -->
                                <?php else: ?>
                                    <a href="<?php echo e(route('user.login')); ?>">Login</a>
                                <?php endif; ?>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/user/layout/header.blade.php ENDPATH**/ ?>