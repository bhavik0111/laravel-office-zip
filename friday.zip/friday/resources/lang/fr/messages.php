<?php
//france language
return [

    //<div class="homemanibanner">
        'home_container' => 'Trouvez eSIM pour plus de 130 destinations',
        'home1'          => 'Les meilleures offres dans le monde',
        'home2'          => 'Rechercher une destination...',
        'all_products'   => 'Tous les produits',

];
