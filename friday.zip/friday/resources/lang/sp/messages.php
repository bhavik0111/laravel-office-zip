<?php
//spanice language
return [

    //<div class="homemanibanner">
        'home_container' => 'Encuentra eSIM para más de 130 destinos',
        'home1'          => 'Las mejores ofertas en todo el mundo.',
        'home2'          => 'Buscar un destino...',
        'all_products'   => 'Todos los productos',

];
