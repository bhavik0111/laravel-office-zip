<?php
//English language
return [

    //<div class="homemanibanner">
        'home_container' => 'Find eSIMs for more than 130 destinations',
        'home1'          => 'The best offers around the world',
        'home2'          => 'Search for a destination...',
        'all_products'   => 'All product',

];
