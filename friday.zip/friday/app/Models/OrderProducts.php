<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderProducts extends Model
{
    use HasFactory;
    protected $table = 'order_products';
    protected $guarded = [];

    public function product()  // relation for orderview and all product display
    {
       return $this->belongsTo(Product::class); //return multiple (hasMany)
    }

    public function OrderCurrency()  // relation for curency code and code wise curency display
    {
        // dd()
       return $this->belongsTo(Currency::class,'currency_id'); //single return (belongsTo)
    }

}
