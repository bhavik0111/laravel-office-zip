<?php
//English language
return [

    //<div class="homemanibanner">
    'home_container' => 'Find eSIMs for more than 130 destinations',
    'home1'          => 'The best offers around the world',
    'home2'          => 'Search for a destination...',

    'product' => [
        'all_products' => 'All product',
    ],

    'header' => [
        'eSIM'    => 'eSIM',
        'blog'    => 'Blog',
        'help'    => 'Help & FAQs',
        'cart'    => 'Cart',
        'profile' => 'Profile',
    ],

    'master' => [
        'head'   => 'How it works',
        'heada'  => 'Check',
        'headb'  => 'Help & FAQs',
        'headc'  => 'to see if your device supports eSIM',
        'headd'  => 'Choose destination & package',
        'heade'  => 'MobiMatter offers eSIM packages for 130+ countries',
        'headf'  => 'Install eSIM',
        'headg'  => 'Instantly get your eSIM and configure it in your eSIM compatible device',
        'headh'  => 'Enjoy high speed connectivity',
        'headi'  => 'Once eSIM is configured, you can enjoy high speed roaming data connectivity',
        'headj'  => 'eSIM Activation Process',
        'headk'  => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard',
        'headl'  => 'Android',
        'headm'  => 'Apple',
    ],

    'footer' => [
        'Quick'   => 'Quick Links',
        'Quicka'  => 'New eSIM',
        'Quickb'  => 'Topup',
        'Quickc'  => 'Check Usage',
        'Quickd'  => 'Blog',
        'Quicke'  => 'Help & FAQs',
        'Quickf'  => 'Contact Details',
        'Quickg'  => 'Keep In Touch',
    ],

    'category' => [
        'add_category'  => 'Add category',
        'name'          => 'Name',
        'image'         => 'Image',
        'description'   => 'Description',
    ],

    'product' => [
        'add_product'  => 'Create Product',
        'category'     => 'Category',
        'name'         => 'Name',
        'image'        => 'Image',
        'price'        => 'Price',
        'colour'       => 'Colour',
        'data'         => 'Data',
        'data_detail'  => 'Data detail',
        'calls'        => 'Calls',
        'calls_detail' => 'Calls detail',
        'sms'          => 'SMS',
        'sms_detail'   => 'SMS detail',
        'credit_val'  => 'Credit validity',
        'credit_val_detail' => 'Credit validity detail',
        'description'  => 'Description',
        'additional'   => 'Additional Features',
        'addnewfeature'=> 'AddNewFeature',
        'status'       => 'Status',
        'active'       => 'Active',
        'deactive'     => 'Deactive',
        'submit'       => 'submit',
    ],


];
