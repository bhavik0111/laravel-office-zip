<?php
//spanish language
return [

    //<div class="homemanibanner">
    'home_container' => 'Encuentra eSIM para más de 130 destinos',
    'home1'          => 'Las mejores ofertas en todo el mundo.',
    'home2'          => 'Buscar un destino...',

    'product' => [
        'all_products'   => 'todo el producto',
    ],

    'header' => [
        'eSIM'    => 'é SIM',
        'blog'    => 'Blog',
        'help'    => 'Ayuda y preguntas frecuentes',
        'cart'    => 'Carro',
        'profile' => 'Perfil',
    ],

    'master' => [
        'head'   => 'Cómo funciona',
        'heada'  => 'Controlar',
        'headb'  => 'Ayuda y preguntas frecuentes',
        'headc'  => 'para ver si su dispositivo es compatible con eSIM',
        'headd'  => 'Elige destino y paquete',
        'heade'  => 'MobiMatter ofrece paquetes eSIM para más de 130 países',
        'headf'  => 'Instalar eSIM',
        'headg'  => 'Obtén tu eSIM al instante y configúralo en tu dispositivo compatible con eSIM',
        'headh'  => 'Disfruta de conectividad de alta velocidad',
        'headi'  => 'Una vez que se configura eSIM, puede disfrutar de conectividad de datos en roaming de alta velocidad',
        'headj'  => 'Proceso de activación de eSIM',
        'headk'  => 'Lorem Ipsum es simplemente un texto ficticio de la industria de la impresión y la composición tipográfica. Lorem Ipsum ha sido el estándar de la industria. Lorem Ipsum es simplemente un texto ficticio de la industria de la impresión y la composición tipográfica. Lorem Ipsum ha sido el estándar de la industria',
        'headl'  => 'Androide',
        'headm'  => 'Manzana',
    ],

    'footer' => [
        'Quick'   => 'enlaces rápidos',
        'Quicka'  => 'Nuevo eSIM',
        'Quickb'  => 'Recargar',
        'Quickc'  => 'Comprobar uso',
        'Quickd'  => 'Blog',
        'Quicke'  => 'Ayuda y preguntas frecuentes',
        'Quickf'  => 'Detalles de contacto',
        'Quickg'  => 'Mantenerse en contacto',
    ],

    'category' => [
        'add_category' => 'Añadir categoría',
        'name'         => 'Nombre',
        'image'        => 'Imagen',
        'description'  => 'Descripcion',
    ],

    'product' => [
        'add_product' => 'Crear producto',
        'category'    => 'Categoría',
        'name'        => 'Nombre',
        'image'       => 'Imagen',
        'price'       => 'Precio',
        'colour'      => 'Color',
        'data'        => 'Datos',
        'data_detail' => 'detalle de datos',
        'calls'       => 'Llamadas',
        'calls_detail'  => 'Detalle de llamadas',
        'sms'         => 'SMS',
        'sms_detail'  => 'SMS detalle',
        'credit_val'  => 'Validez del crédito',
        'credit_val_detail' => 'Detalle de la validez del crédito',
        'description' => 'Descripción',
        'additional'  => 'Características adicionales',
        'addnewfeature' => 'Agregar nuevas características',
        'status'      => 'Estado',
        'active'      => 'Activa',
        'deactive'    => 'Desactivado',
        'submit'      => 'entregar',

    ],


];
