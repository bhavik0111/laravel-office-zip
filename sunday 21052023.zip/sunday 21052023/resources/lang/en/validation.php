<?php
return [
    'required' => 'The :attribute field is required',
 ];
