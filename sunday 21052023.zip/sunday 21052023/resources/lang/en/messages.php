<?php
//English language
return [

    //<div class="homemanibanner">
        'home_container' => 'Find eSIMs for more than 130 destinations',
        'home1'          => 'The best offers around the world',
        'home2'          => 'Search for a destination...',

        'product' => [
            'all_products'   => 'All product',
            'product_insert' => 'Product Succesfully inserted',
            'product_update' => 'Product Succesfully updated',
        ],

];
