<?php
return ['required' => 'The :attribute frnch field is required',
        'numeric' => 'The :attribute fraqnsh is must be numeric'];
