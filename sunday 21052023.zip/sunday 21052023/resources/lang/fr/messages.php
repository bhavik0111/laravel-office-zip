<?php
//france language
return [

    //<div class="homemanibanner">
        'home_container' => 'Trouvez eSIM pour plus de 130 destinations',
        'home1'          => 'Les meilleures offres dans le monde',
        'home2'          => 'Rechercher une destination...',
        'product' => [
            'all_products'   => 'All product',
            'product_insert' => 'Product fransh Succesfully inserted',
            'product_update' => 'Product fransh Succesfully updated',
        ],
];
