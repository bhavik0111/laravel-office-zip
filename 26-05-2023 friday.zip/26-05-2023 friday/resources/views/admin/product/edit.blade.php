@extends('admin.layout.master')
@section('content')
    <main class="form-signin">

        <div class="card">
            <form action="{{ route('admin.product.update', ['id' => $product->id]) }}" method="POST"
                enctype="multipart/form-data">
                @csrf
                <div class="card-body">
                    <h4 class="card-title">{{ __('Update Product') }}</h4>

                    <div class="card-body">
                        <div class="form-group column" style="float:right">
                            <a href="{{ route('admin.product.index') }}" class="btn btn-dark"><b>{{ __('Back') }}</b></a>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="name"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Category') }}</b></label>
                        <div class="col-sm-9">
                            <select name="category_id" class="form-control  @error('category_id') is-invalid @enderror ">
                                <option value="" selected>Select Category</option>
                                @foreach ($categories as $category)
                                    <option value="{{ $category->id }}"
                                        {{ $category->id == $product->category_id ? 'selected' : '' }}>{{ $category->name }}
                                    </option>
                                @endforeach
                            </select>
                            @error('category_id')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">

                        <div class="col-sm-3">&nbsp;</div>
                        <div class="col-sm-9">
                            <a class="btn btn-primary" name="language" onclick="changeinput('sp');"><b>Spanish</b></a>

                            <a class="btn btn-primary" name="language" onclick="changeinput('fr');"><b>French</b></a>

                            <a class="btn btn-primary" name="language" onclick="changeinput('en');"><b>English</b></a>
                        </div>

                        <label for="name"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Name') }}</b>
                        </label>

                        <div class="col-sm-9">
                            <div class="langdiv" id="inputdiv_en"
                                @if ($product->name_en) style="display: block" @endif style="display: none">
                                <input type="text" class="form-control @error('name_en') is-invalid @enderror"
                                    value="{{ old('name', $product->name_en) }}" id="name_en" name="name_en"
                                    placeholder=" en">

                                @error('name_en')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdiv" id="inputdiv_fr"
                                @if ($product->name_fr) style="display: block" @endif style="display: none">
                                <input type="text" class="form-control @error('name_fr') is-invalid @enderror"
                                    value="{{ old('name_fr', $product->name_fr) }}" id="name_fr" name="name_fr"
                                    placeholder="fr">

                                @error('name_fr')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdiv" id="inputdiv_sp"
                                @if ($product->name_sp) style="display: block" @endif style="display: none">
                                <input type="text" class="form-control @error('name_sp') is-invalid @enderror"
                                    value="{{ old('name_sp', $product->name_sp) }}" id="name_sp" name="name_sp"
                                    placeholder="sp">

                                @error('name_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>


                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="prod_image"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Image') }}</b></label>

                        <div class="col-sm-9">
                            <input id="prod_image" type="file" class="form-control" name="prod_image">
                            <input type="hidden" name="id" value="{{ $product->id }}">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="price"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('price') }}</b></label>
                        <div class="col-sm-9">
                            <input type="number" class="form-control @error('price') is-invalid @enderror"
                                value="{{ old('price', $product->price) }}" id="price" name="price"
                                placeholder="your price">

                        </div>
                        @error('price')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div class="form-group row">
                        <label for="colour"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('colour') }}</b></label>
                        <div class="col-sm-9">
                            <input type="color" class="form-control @error('colour') is-invalid @enderror"
                                value="{{ old('colour', $product->colour) }}" id="colour" name="colour"
                                placeholder="your colour">

                        </div>
                        @error('colour')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3">&nbsp;</div>
                        <div class="col-sm-9">
                            <a class="btn btn-primary" name="language" onclick="changedata('sp');"><b>Spanish</b></a>

                            <a class="btn btn-primary" name="language" onclick="changedata('fr');"><b>French</b></a>

                            <a class="btn btn-primary" name="language" onclick="changedata('en');"><b>English</b></a>
                        </div>

                        <label for="data_en"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Data') }}</b>
                        </label>

                        <div class="col-sm-9">
                            <div class="langdivdata" id="inputdivdata_en"
                                @if ($product->data_en) style="display: block" @endif style="display: none">
                                <input type="text" class="form-control @error('data_en') is-invalid @enderror"
                                    value="{{ old('data_en', $product->data_en) }}" id="data_en" name="data_en"
                                    placeholder="en">

                                @error('data_en')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivdata" id="inputdivdata_fr"
                                @if ($product->data_fr) style="display: block" @endif style="display: none">
                                <input type="text" class="form-control @error('data_fr') is-invalid @enderror"
                                    value="{{ old('data_fr', $product->data_fr) }}" id="data_fr" name="data_fr"
                                    placeholder="fr">

                                @error('data_fr')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivdata" id="inputdivdata_sp"
                                @if ($product->data_sp) style="display: block" @endif style="display: none">
                                <input type="text" class="form-control @error('data_sp') is-invalid @enderror"
                                    value="{{ old('data_sp', $product->data_sp) }}" id="data_sp" name="data_sp"
                                    placeholder="sp">

                                @error('data_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>


                        </div>
                    </div>


                    <div class="form-group row">
                        <label for="data_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Data detail') }}</b></label>
                        <div class="col-sm-9">
                            <textarea class="form-control @error('data_detail') is-invalid @enderror summernote " value=""
                                id="data_detail" name="data_detail">{{ old('data_detail', $product->data_detail) }}</textarea>

                        </div>
                        @error('data_detail')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3">&nbsp;</div>
                        <div class="col-sm-9">
                            <a class="btn btn-primary" name="language" onclick="changecalls('sp');"><b>Spanish</b></a>

                            <a class="btn btn-primary" name="language" onclick="changecalls('fr');"><b>French</b></a>

                            <a class="btn btn-primary" name="language" onclick="changecalls('en');"><b>English</b></a>
                        </div>

                        <label for="calls"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Calls') }}</b>
                        </label>

                        <div class="col-sm-9">
                            <div class="langdivcalls" id="inputdivcalls_en"
                                @if ($product->calls_en) style="display: block" @endif style="display: none">
                                <input type="text" class="form-control @error('calls_en') is-invalid @enderror"
                                    value="{{ old('calls_en', $product->calls_en) }}" id="calls_en" name="calls_en"
                                    placeholder="en">

                                @error('calls_en')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivcalls" id="inputdivcalls_fr"
                                @if ($product->calls_fr) style="display: block" @endif style="display: none">
                                <input type="text" class="form-control @error('calls_fr') is-invalid @enderror"
                                    value="{{ old('calls_fr', $product->calls_fr) }}" id="calls_fr" name="calls_fr"
                                    placeholder="fr">

                                @error('calls_fr')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivcalls" id="inputdivcalls_sp"
                                @if ($product->calls_sp) style="display: block" @endif style="display: none">
                                <input type="text" class="form-control @error('calls_sp') is-invalid @enderror"
                                    value="{{ old('calls_sp', $product->calls_sp) }}" id="calls_sp" name="calls_sp"
                                    placeholder="sp">

                                @error('calls_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>


                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="calls_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Calls detail') }}</b></label>
                        <div class="col-sm-9">
                            <textarea class="form-control @error('calls_detail') is-invalid @enderror summernote" value=""
                                id="calls_detail" name="calls_detail">{{ old('calls_detail', $product->calls_detail) }}</textarea>

                        </div>
                        @error('calls_detail')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3">&nbsp;</div>
                        <div class="col-sm-9">
                            <a class="btn btn-primary" name="language" onclick="changesms('sp');"><b>Spanish</b></a>

                            <a class="btn btn-primary" name="language" onclick="changesms('fr');"><b>French</b></a>

                            <a class="btn btn-primary" name="language" onclick="changesms('en');"><b>English</b></a>
                        </div>


                        <label for="sms"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('SMS') }}</b>
                        </label>

                        <div class="col-sm-9">
                            <div class="langdivsms" id="inputdivsms_en"
                                @if ($product->sms_en) style="display: block" @endif style="display: none">
                                <input type="text" class="form-control @error('sms_en') is-invalid @enderror"
                                    value="{{ old('sms_en', $product->sms_en) }}" id="sms_en" name="sms_en"
                                    placeholder="en">

                                @error('sms_en')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivsms" id="inputdivsms_fr"
                                @if ($product->sms_fr) style="display: block" @endif style="display: none">
                                <input type="text" class="form-control @error('sms_fr') is-invalid @enderror"
                                    value="{{ old('sms_fr', $product->sms_fr) }}" id="sms_fr" name="sms_fr"
                                    placeholder="fr">

                                @error('sms_fr')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivsms" id="inputdivsms_sp"
                                @if ($product->sms_sp) style="display: block" @endif style="display: none">
                                <input type="text" class="form-control @error('sms_sp') is-invalid @enderror"
                                    value="{{ old('sms_sp', $product->sms_sp) }}" id="sms_sp" name="sms_sp"
                                    placeholder="sp">

                                @error('sms_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="sms_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('SMS detail') }}</b></label>
                        <div class="col-sm-9">
                            <textarea class="form-control @error('sms_detail') is-invalid @enderror summernote" value="" id="sms_detail"
                                name="sms_detail">{{ old('sms_detail', $product->sms_detail) }}</textarea>

                        </div>
                        @error('sms_detail')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3">&nbsp;</div>
                        <div class="col-sm-9">
                            <a class="btn btn-primary" name="language" onclick="changecrdt('sp');"><b>Spanish</b></a>

                            <a class="btn btn-primary" name="language" onclick="changecrdt('fr');"><b>French</b></a>

                            <a class="btn btn-primary" name="language" onclick="changecrdt('en');"><b>English</b></a>
                        </div>

                        <label for="credit_validity"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Credit validity') }}</b>
                        </label>

                        <div class="col-sm-9">
                            <div class="langdivcrdt" id="inputdivcrdt_en"
                                @if ($product->description_en) style="display: block" @endif style="display: none">
                                <input type="text" class="form-control @error('credit_validity_en') is-invalid @enderror"
                                    value="{{ old('credit_validity_en', $product->description_en) }}" id="credit_validity_en"
                                    name="credit_validity_en" placeholder="en">

                                @error('credit_validity_en')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivcrdt" id="inputdivcrdt_fr"
                                @if ($product->credit_validity_fr) style="display: block" @endif style="display: none">
                                <input type="text" class="form-control @error('credit_validity_fr') is-invalid @enderror"
                                    value="{{ old('credit_validity_fr', $product->credit_validity_fr) }}" id="credit_validity_fr"
                                    name="credit_validity_fr" placeholder="fr">

                                @error('credit_validity_fr')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivcrdt" id="inputdivcrdt_sp"
                                @if ($product->credit_validity_sp) style="display: block" @endif style="display: none">
                                <input type="text" class="form-control @error('credit_validity_sp') is-invalid @enderror"
                                    value="{{ old('credit_validity_sp', $product->credit_validity_sp) }}" id="credit_validity_sp"
                                    name="credit_validity_sp" placeholder="sp">

                                @error('credit_validity_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="credit_validity_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Credit validity detail') }}</b></label>
                        <div class="col-sm-9">
                            <textarea class="form-control @error('credit_validity_detail') is-invalid @enderror summernote" value=""
                                id="credit_validity_detail" name="credit_validity_detail">{{ old('credit_validity_detail', $product->credit_validity_detail) }}</textarea>

                        </div>
                        @error('credit_validity_detail')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3">&nbsp;</div>
                        <div class="col-sm-9">
                            <a class="btn btn-primary" name="language" onclick="changedesc('sp');"><b>Spanish</b></a>

                            <a class="btn btn-primary" name="language" onclick="changedesc('fr');"><b>French</b></a>

                            <a class="btn btn-primary" name="language" onclick="changedesc('en');"><b>English</b></a>
                        </div>

                        <label for="description"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Description') }}</b>
                        </label>

                        <div class="col-sm-9">
                            <div class="langdivdesc" id="inputdivdesc_en"
                                @if ($product->description_en) style="display: block" @endif style="display: none">
                                <input type="text" class="form-control @error('description_en') is-invalid @enderror"
                                    value="{{ old('description_en', $product->description_en) }}" id="description_en"
                                    name="description_en" placeholder="en">

                                @error('description_en')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivdesc" id="inputdivdesc_fr"
                                @if ($product->description_fr) style="display: block" @endif style="display: none">
                                <input type="text" class="form-control @error('description_fr') is-invalid @enderror"
                                    value="{{ old('description_fr', $product->description_fr) }}" id="description_fr"
                                    name="description_fr" placeholder="fr">

                                @error('description_fr')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivdesc" id="inputdivdesc_sp"
                                @if ($product->description_sp) style="display: block" @endif style="display: none">
                                <input type="text" class="form-control @error('description_sp') is-invalid @enderror"
                                    value="{{ old('description_sp', $product->description_sp) }}" id="description_sp"
                                    name="description_sp" placeholder="sp">

                                @error('description_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="description"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Additional Features') }}</b></label>

                        <div class="col-sm-9">
                            <button type="button" class="btn btn-primary" onclick="addrow()">
                                {{ __('AddNewFeature') }}
                            </button>
                        </div>
                    </div>

                    <div class="features">
                        <!-- (click AddNew all title and description field are placed hear....) -->
                    </div>

                    <!-- title and description -->
                    @foreach ($features as $feature)
                        <div class="prod_feature">
                            <div class="form-group row">
                                <label for="title" class="col-sm-3 text-end control-label col-form-label">
                                    {{ __('Title') }}
                                </label>

                                <div class="col-sm-8">
                                    <input type="text" name="title[]" class="form-control title" id="title"
                                        value="{{ old('title', $feature->title) }}" required>
                                </div>
                                <div class="col-sm-1">
                                    <button type="button" class="btn btn-danger deleteRow">Delete</button>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="add_description" class="col-sm-3 text-end control-label col-form-label">
                                    {{ __('Description') }}
                                </label>

                                <div class="col-sm-8">
                                    <textarea class="form-control summernote" name="add_description[]" id="add_description">{{ old('add_description', $feature->description) }}</textarea>
                                </div>
                            </div>
                        </div>
                    @endforeach

                    <div class="form-group row">
                        <label class="col-sm-3 text-end control-label col-form-label">
                            <b>{{ __('Status') }}</b>
                        </label>
                        <div class="col-md-9">
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation1"
                                    name="status" value="1"
                                    @if ($product->status == 1) {{ 'checked=checked' }} @endif required />
                                <label class="form-check-label mb-0"
                                    for="customControlValidation1">{{ __('Active') }}</label>

                            </div>
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation2"
                                    name="status" value="0"
                                    @if ($product->status == 0) {{ 'checked=checked' }} @endif required />
                                <label class="form-check-label mb-0"
                                    for="customControlValidation2">{{ __('Deactive') }}</label>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="border-top">
                    <div class="card-body">
                        <button type="submit" name="uedit" class="btn btn-primary">
                            Edit
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </main>
@endsection
@push('scripts')
    <script>
        function changeinput(language) {
            $(".langdiv").css('display', 'none');
            $("#inputdiv_" + language).css('display', 'block');
        }
    </script>
    <script>
        function changedata(language) {
            $(".langdivdata").css('display', 'none');
            $("#inputdivdata_" + language).css('display', 'block');
        }
    </script>
    <script>
        function changecalls(language) {
            $(".langdivcalls").css('display', 'none');
            $("#inputdivcalls_" + language).css('display', 'block');
        }
    </script>
    <script>
        function changesms(language) {
            $(".langdivsms").css('display', 'none');
            $("#inputdivsms_" + language).css('display', 'block');
        }
    </script>
    <script>
        function changedesc(language) {
            $(".langdivdesc").css('display', 'none');
            $("#inputdivdesc_" + language).css('display', 'block');
        }
    </script>
    <script>
        function changecrdt(language) {
            $(".langdivcrdt").css('display', 'none');
            $("#inputdivcrdt_" + language).css('display', 'block');
        }
    </script>



    <script type="text/javascript">
        $(document).ready(function() {
            $('.summernote').summernote({
                tabsize: 2,
                height: 120
            });
        });

        function addrow() {
            var html =
                '<div class="prod_feature">' +
                '<div class="form-group row">' +
                '<label for="title"  class="col-sm-3 text-end control-label col-form-label">{{ __('Title') }}' +
                '</label>' +

                '<div class="col-sm-8">' +
                '<input type="text" name="title[]" class="form-control title"  id="title" required>' +
                '</div>' +
                '<div class="col-sm-1">' +
                '<button type="button" class="btn btn-danger deleteRow">Delete</button>' +
                '</div>' +
                '</div>' +

                '<div class="form-group row">' +
                '<label for="add_description" class="col-sm-3 text-end control-label col-form-label">{{ __('Description') }}' +
                '</label>' +

                '<div class="col-sm-8">' +
                '<textarea class="form-control summernote" name="add_description[]" id="add_description">{{ old('add_description') }}</textarea>' +
                '</div>' +
                '</div>' +
                '</div>';

            $('.features').append(html);
            $('.summernote').summernote();

        }



        $(document).on('click', '.deleteRow', function(e) {
            e.preventDefault();
            $(this).closest('.prod_feature').remove();
        })
    </script>
@endpush
