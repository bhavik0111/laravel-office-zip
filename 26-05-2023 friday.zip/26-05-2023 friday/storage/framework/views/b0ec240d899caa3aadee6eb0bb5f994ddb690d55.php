<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/admin/assets/extra-libs/multicheck/multicheck.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css')); ?>" />
<?php $__env->startSection('content'); ?>
    <!-- (FOR MSG) -->
    <?php if(session()->has('msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('msg')); ?>

        </div>
    <?php endif; ?>
    <?php if(session()->has('error_msg')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('error_msg')); ?>

        </div>
    <?php endif; ?>
    <!-- (END MSG) -->
    <div class="card mb-3">
        <div class="card-body">
            <div class="card-header row">
                <h4 class="card-title mb-3"><b>All Products</b></h4>
                <div class="text-end">
                    <a href="<?php echo e(route('admin.product.create')); ?>" class="btn btn-dark"><b> <?php echo e(__('Add+')); ?></b></a>
                </div>
            </div>
            <div class="table-responsive">
                <table id="zero_config" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th><b>ID</b></th>
                            <th><b>Category</b></th>
                            <th><b>Name en</b></th>
                            <th><b>Name fr</b></th>
                            <th><b>Name sp</b></th>
                            <th><b>Image</b></th>
                            <th><b>Price</b></th>
                            <th><b>Colour</b></th>
                            <!-- <th><b>Data</b></th>
                            <th><b>Data detail</b></th>
                            <th><b>Calls</b></th>
                            <th><b>Calls detail</b></th>
                            <th><b>SMS</b></th>
                            <th><b>SMS detail</b></th>
                            <th><b>Credit validity</b></th>
                            <th><b>Credit validity detail</b></th> -->
                            <th><b>Description</b></th>
                            <th><b>Status</b></th>
                            <th><b>Action</b></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><strong><?php echo e($product->id); ?></strong></td>

                                    <td><?php echo e($product->category->name); ?></td>


                                    <td><?php echo e($product->name_en); ?></td>
                                    <td><?php echo e($product->name_fr); ?></td>
                                    <td><?php echo e($product->name_sp); ?></td>

                                    <td><img src="<?php echo e(asset('public/' . $product->image)); ?>" alt="image" height="100" width="100"></td>


                                    <td><?php echo e($product->price); ?></td>



                                    <td><div style="background-color:<?php echo e($product->colour); ?>;height:30px;width:30px"></div></td>



                                    <td><?php echo $product->description; ?></td>


                                <td>
                                    <?php if($product->status == 1): ?>
                                        <?php echo e('Active'); ?>

                                    <?php endif; ?>
                                    <?php if($product->status == 0): ?>
                                        <?php echo e('Deactive'); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.product.edit', $product->id)); ?>"
                                        class="btn btn-info"><b><?php echo e(__('Edit')); ?></b></a>

                                    <form action="<?php echo e(route('admin.product.destroy', $product->id)); ?>" method="POST"
                                        onsubmit="return confirm('Are you sure Delete User?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger text-white"><b><?php echo e(__('Delete')); ?></b></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- </div> -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

    <!--(for all pagination,asc-desc,search,shorting)-->
    <script src="<?php echo e(asset('public/admin/assets/extra-libs/multicheck/datatable-checkbox-init.js')); ?>"></script>
    <script src="<?php echo e(asset('public/admin/assets/extra-libs/multicheck/jquery.multicheck.js')); ?>"></script>
    <script src="<?php echo e(asset('public/admin/assets/extra-libs/DataTables/datatables.min.js')); ?>"></script>
    <script>
        /****************************************
         *       Basic Table                   *
         ****************************************/
        $("#zero_config").DataTable({
            order: [[0, 'desc']],
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/admin/product/index.blade.php ENDPATH**/ ?>