<?php $__env->startSection('content'); ?>
    <main class="form-signin">

        <div class="card">
            <form action="<?php echo e(route('admin.product.update', ['id' => $product->id])); ?>" method="POST"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <h4 class="card-title"><?php echo e(__('Update Product')); ?></h4>

                    <div class="card-body">
                        <div class="form-group column" style="float:right">
                            <a href="<?php echo e(route('admin.product.index')); ?>" class="btn btn-dark"><b><?php echo e(__('Back')); ?></b></a>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="name"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Category')); ?></b></label>
                        <div class="col-sm-9">
                            <select name="category_id" class="form-control  <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> ">
                                <option value="" selected>Select Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"
                                        <?php echo e($category->id == $product->category_id ? 'selected' : ''); ?>><?php echo e($category->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">

                        <div class="col-sm-3">&nbsp;</div>
                        <div class="col-sm-9">
                            <a class="btn btn-primary" name="language" onclick="changeinput('sp');"><b>Spanish</b></a>

                            <a class="btn btn-primary" name="language" onclick="changeinput('fr');"><b>French</b></a>

                            <a class="btn btn-primary" name="language" onclick="changeinput('en');"><b>English</b></a>
                        </div>

                        <label for="name"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Name')); ?></b>
                        </label>

                        <div class="col-sm-9">
                            <div class="langdiv" id="inputdiv_en"
                                <?php if($product->name_en): ?> style="display: block" <?php endif; ?> style="display: none">
                                <input type="text" class="form-control <?php $__errorArgs = ['name_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('name', $product->name_en)); ?>" id="name_en" name="name_en"
                                    placeholder=" en">

                                <?php $__errorArgs = ['name_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="langdiv" id="inputdiv_fr"
                                <?php if($product->name_fr): ?> style="display: block" <?php endif; ?> style="display: none">
                                <input type="text" class="form-control <?php $__errorArgs = ['name_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('name_fr', $product->name_fr)); ?>" id="name_fr" name="name_fr"
                                    placeholder="fr">

                                <?php $__errorArgs = ['name_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="langdiv" id="inputdiv_sp"
                                <?php if($product->name_sp): ?> style="display: block" <?php endif; ?> style="display: none">
                                <input type="text" class="form-control <?php $__errorArgs = ['name_sp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('name_sp', $product->name_sp)); ?>" id="name_sp" name="name_sp"
                                    placeholder="sp">

                                <?php $__errorArgs = ['name_sp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="prod_image"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Image')); ?></b></label>

                        <div class="col-sm-9">
                            <input id="prod_image" type="file" class="form-control" name="prod_image">
                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="price"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('price')); ?></b></label>
                        <div class="col-sm-9">
                            <input type="number" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(old('price', $product->price)); ?>" id="price" name="price"
                                placeholder="your price">

                        </div>
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <label for="colour"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('colour')); ?></b></label>
                        <div class="col-sm-9">
                            <input type="color" class="form-control <?php $__errorArgs = ['colour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(old('colour', $product->colour)); ?>" id="colour" name="colour"
                                placeholder="your colour">

                        </div>
                        <?php $__errorArgs = ['colour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3">&nbsp;</div>
                        <div class="col-sm-9">
                            <a class="btn btn-primary" name="language" onclick="changedata('sp');"><b>Spanish</b></a>

                            <a class="btn btn-primary" name="language" onclick="changedata('fr');"><b>French</b></a>

                            <a class="btn btn-primary" name="language" onclick="changedata('en');"><b>English</b></a>
                        </div>

                        <label for="data_en"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Data')); ?></b>
                        </label>

                        <div class="col-sm-9">
                            <div class="langdivdata" id="inputdivdata_en"
                                <?php if($product->data_en): ?> style="display: block" <?php endif; ?> style="display: none">
                                <input type="text" class="form-control <?php $__errorArgs = ['data_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('data_en', $product->data_en)); ?>" id="data_en" name="data_en"
                                    placeholder="en">

                                <?php $__errorArgs = ['data_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="langdivdata" id="inputdivdata_fr"
                                <?php if($product->data_fr): ?> style="display: block" <?php endif; ?> style="display: none">
                                <input type="text" class="form-control <?php $__errorArgs = ['data_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('data_fr', $product->data_fr)); ?>" id="data_fr" name="data_fr"
                                    placeholder="fr">

                                <?php $__errorArgs = ['data_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="langdivdata" id="inputdivdata_sp"
                                <?php if($product->data_sp): ?> style="display: block" <?php endif; ?> style="display: none">
                                <input type="text" class="form-control <?php $__errorArgs = ['data_sp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('data_sp', $product->data_sp)); ?>" id="data_sp" name="data_sp"
                                    placeholder="sp">

                                <?php $__errorArgs = ['data_sp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                        </div>
                    </div>


                    <div class="form-group row">
                        <label for="data_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Data detail')); ?></b></label>
                        <div class="col-sm-9">
                            <textarea class="form-control <?php $__errorArgs = ['data_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> summernote " value=""
                                id="data_detail" name="data_detail"><?php echo e(old('data_detail', $product->data_detail)); ?></textarea>

                        </div>
                        <?php $__errorArgs = ['data_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3">&nbsp;</div>
                        <div class="col-sm-9">
                            <a class="btn btn-primary" name="language" onclick="changecalls('sp');"><b>Spanish</b></a>

                            <a class="btn btn-primary" name="language" onclick="changecalls('fr');"><b>French</b></a>

                            <a class="btn btn-primary" name="language" onclick="changecalls('en');"><b>English</b></a>
                        </div>

                        <label for="calls"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Calls')); ?></b>
                        </label>

                        <div class="col-sm-9">
                            <div class="langdivcalls" id="inputdivcalls_en"
                                <?php if($product->calls_en): ?> style="display: block" <?php endif; ?> style="display: none">
                                <input type="text" class="form-control <?php $__errorArgs = ['calls_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('calls_en', $product->calls_en)); ?>" id="calls_en" name="calls_en"
                                    placeholder="en">

                                <?php $__errorArgs = ['calls_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="langdivcalls" id="inputdivcalls_fr"
                                <?php if($product->calls_fr): ?> style="display: block" <?php endif; ?> style="display: none">
                                <input type="text" class="form-control <?php $__errorArgs = ['calls_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('calls_fr', $product->calls_fr)); ?>" id="calls_fr" name="calls_fr"
                                    placeholder="fr">

                                <?php $__errorArgs = ['calls_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="langdivcalls" id="inputdivcalls_sp"
                                <?php if($product->calls_sp): ?> style="display: block" <?php endif; ?> style="display: none">
                                <input type="text" class="form-control <?php $__errorArgs = ['calls_sp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('calls_sp', $product->calls_sp)); ?>" id="calls_sp" name="calls_sp"
                                    placeholder="sp">

                                <?php $__errorArgs = ['calls_sp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="calls_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Calls detail')); ?></b></label>
                        <div class="col-sm-9">
                            <textarea class="form-control <?php $__errorArgs = ['calls_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> summernote" value=""
                                id="calls_detail" name="calls_detail"><?php echo e(old('calls_detail', $product->calls_detail)); ?></textarea>

                        </div>
                        <?php $__errorArgs = ['calls_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3">&nbsp;</div>
                        <div class="col-sm-9">
                            <a class="btn btn-primary" name="language" onclick="changesms('sp');"><b>Spanish</b></a>

                            <a class="btn btn-primary" name="language" onclick="changesms('fr');"><b>French</b></a>

                            <a class="btn btn-primary" name="language" onclick="changesms('en');"><b>English</b></a>
                        </div>


                        <label for="sms"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('SMS')); ?></b>
                        </label>

                        <div class="col-sm-9">
                            <div class="langdivsms" id="inputdivsms_en"
                                <?php if($product->sms_en): ?> style="display: block" <?php endif; ?> style="display: none">
                                <input type="text" class="form-control <?php $__errorArgs = ['sms_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('sms_en', $product->sms_en)); ?>" id="sms_en" name="sms_en"
                                    placeholder="en">

                                <?php $__errorArgs = ['sms_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="langdivsms" id="inputdivsms_fr"
                                <?php if($product->sms_fr): ?> style="display: block" <?php endif; ?> style="display: none">
                                <input type="text" class="form-control <?php $__errorArgs = ['sms_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('sms_fr', $product->sms_fr)); ?>" id="sms_fr" name="sms_fr"
                                    placeholder="fr">

                                <?php $__errorArgs = ['sms_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="langdivsms" id="inputdivsms_sp"
                                <?php if($product->sms_sp): ?> style="display: block" <?php endif; ?> style="display: none">
                                <input type="text" class="form-control <?php $__errorArgs = ['sms_sp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('sms_sp', $product->sms_sp)); ?>" id="sms_sp" name="sms_sp"
                                    placeholder="sp">

                                <?php $__errorArgs = ['sms_sp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="sms_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('SMS detail')); ?></b></label>
                        <div class="col-sm-9">
                            <textarea class="form-control <?php $__errorArgs = ['sms_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> summernote" value="" id="sms_detail"
                                name="sms_detail"><?php echo e(old('sms_detail', $product->sms_detail)); ?></textarea>

                        </div>
                        <?php $__errorArgs = ['sms_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3">&nbsp;</div>
                        <div class="col-sm-9">
                            <a class="btn btn-primary" name="language" onclick="changecrdt('sp');"><b>Spanish</b></a>

                            <a class="btn btn-primary" name="language" onclick="changecrdt('fr');"><b>French</b></a>

                            <a class="btn btn-primary" name="language" onclick="changecrdt('en');"><b>English</b></a>
                        </div>

                        <label for="credit_validity"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Credit validity')); ?></b>
                        </label>

                        <div class="col-sm-9">
                            <div class="langdivcrdt" id="inputdivcrdt_en"
                                <?php if($product->description_en): ?> style="display: block" <?php endif; ?> style="display: none">
                                <input type="text" class="form-control <?php $__errorArgs = ['credit_validity_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('credit_validity_en', $product->description_en)); ?>" id="credit_validity_en"
                                    name="credit_validity_en" placeholder="en">

                                <?php $__errorArgs = ['credit_validity_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="langdivcrdt" id="inputdivcrdt_fr"
                                <?php if($product->credit_validity_fr): ?> style="display: block" <?php endif; ?> style="display: none">
                                <input type="text" class="form-control <?php $__errorArgs = ['credit_validity_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('credit_validity_fr', $product->credit_validity_fr)); ?>" id="credit_validity_fr"
                                    name="credit_validity_fr" placeholder="fr">

                                <?php $__errorArgs = ['credit_validity_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="langdivcrdt" id="inputdivcrdt_sp"
                                <?php if($product->credit_validity_sp): ?> style="display: block" <?php endif; ?> style="display: none">
                                <input type="text" class="form-control <?php $__errorArgs = ['credit_validity_sp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('credit_validity_sp', $product->credit_validity_sp)); ?>" id="credit_validity_sp"
                                    name="credit_validity_sp" placeholder="sp">

                                <?php $__errorArgs = ['credit_validity_sp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="credit_validity_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Credit validity detail')); ?></b></label>
                        <div class="col-sm-9">
                            <textarea class="form-control <?php $__errorArgs = ['credit_validity_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> summernote" value=""
                                id="credit_validity_detail" name="credit_validity_detail"><?php echo e(old('credit_validity_detail', $product->credit_validity_detail)); ?></textarea>

                        </div>
                        <?php $__errorArgs = ['credit_validity_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3">&nbsp;</div>
                        <div class="col-sm-9">
                            <a class="btn btn-primary" name="language" onclick="changedesc('sp');"><b>Spanish</b></a>

                            <a class="btn btn-primary" name="language" onclick="changedesc('fr');"><b>French</b></a>

                            <a class="btn btn-primary" name="language" onclick="changedesc('en');"><b>English</b></a>
                        </div>

                        <label for="description"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Description')); ?></b>
                        </label>

                        <div class="col-sm-9">
                            <div class="langdivdesc" id="inputdivdesc_en"
                                <?php if($product->description_en): ?> style="display: block" <?php endif; ?> style="display: none">
                                <input type="text" class="form-control <?php $__errorArgs = ['description_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('description_en', $product->description_en)); ?>" id="description_en"
                                    name="description_en" placeholder="en">

                                <?php $__errorArgs = ['description_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="langdivdesc" id="inputdivdesc_fr"
                                <?php if($product->description_fr): ?> style="display: block" <?php endif; ?> style="display: none">
                                <input type="text" class="form-control <?php $__errorArgs = ['description_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('description_fr', $product->description_fr)); ?>" id="description_fr"
                                    name="description_fr" placeholder="fr">

                                <?php $__errorArgs = ['description_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="langdivdesc" id="inputdivdesc_sp"
                                <?php if($product->description_sp): ?> style="display: block" <?php endif; ?> style="display: none">
                                <input type="text" class="form-control <?php $__errorArgs = ['description_sp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('description_sp', $product->description_sp)); ?>" id="description_sp"
                                    name="description_sp" placeholder="sp">

                                <?php $__errorArgs = ['description_sp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="description"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Additional Features')); ?></b></label>

                        <div class="col-sm-9">
                            <button type="button" class="btn btn-primary" onclick="addrow()">
                                <?php echo e(__('AddNewFeature')); ?>

                            </button>
                        </div>
                    </div>

                    <div class="features">
                        <!-- (click AddNew all title and description field are placed hear....) -->
                    </div>

                    <!-- title and description -->
                    <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="prod_feature">
                            <div class="form-group row">
                                <label for="title" class="col-sm-3 text-end control-label col-form-label">
                                    <?php echo e(__('Title')); ?>

                                </label>

                                <div class="col-sm-8">
                                    <input type="text" name="title[]" class="form-control title" id="title"
                                        value="<?php echo e(old('title', $feature->title)); ?>" required>
                                </div>
                                <div class="col-sm-1">
                                    <button type="button" class="btn btn-danger deleteRow">Delete</button>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="add_description" class="col-sm-3 text-end control-label col-form-label">
                                    <?php echo e(__('Description')); ?>

                                </label>

                                <div class="col-sm-8">
                                    <textarea class="form-control summernote" name="add_description[]" id="add_description"><?php echo e(old('add_description', $feature->description)); ?></textarea>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="form-group row">
                        <label class="col-sm-3 text-end control-label col-form-label">
                            <b><?php echo e(__('Status')); ?></b>
                        </label>
                        <div class="col-md-9">
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation1"
                                    name="status" value="1"
                                    <?php if($product->status == 1): ?> <?php echo e('checked=checked'); ?> <?php endif; ?> required />
                                <label class="form-check-label mb-0"
                                    for="customControlValidation1"><?php echo e(__('Active')); ?></label>

                            </div>
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation2"
                                    name="status" value="0"
                                    <?php if($product->status == 0): ?> <?php echo e('checked=checked'); ?> <?php endif; ?> required />
                                <label class="form-check-label mb-0"
                                    for="customControlValidation2"><?php echo e(__('Deactive')); ?></label>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="border-top">
                    <div class="card-body">
                        <button type="submit" name="uedit" class="btn btn-primary">
                            Edit
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        function changeinput(language) {
            $(".langdiv").css('display', 'none');
            $("#inputdiv_" + language).css('display', 'block');
        }
    </script>
    <script>
        function changedata(language) {
            $(".langdivdata").css('display', 'none');
            $("#inputdivdata_" + language).css('display', 'block');
        }
    </script>
    <script>
        function changecalls(language) {
            $(".langdivcalls").css('display', 'none');
            $("#inputdivcalls_" + language).css('display', 'block');
        }
    </script>
    <script>
        function changesms(language) {
            $(".langdivsms").css('display', 'none');
            $("#inputdivsms_" + language).css('display', 'block');
        }
    </script>
    <script>
        function changedesc(language) {
            $(".langdivdesc").css('display', 'none');
            $("#inputdivdesc_" + language).css('display', 'block');
        }
    </script>
    <script>
        function changecrdt(language) {
            $(".langdivcrdt").css('display', 'none');
            $("#inputdivcrdt_" + language).css('display', 'block');
        }
    </script>



    <script type="text/javascript">
        $(document).ready(function() {
            $('.summernote').summernote({
                tabsize: 2,
                height: 120
            });
        });

        function addrow() {
            var html =
                '<div class="prod_feature">' +
                '<div class="form-group row">' +
                '<label for="title"  class="col-sm-3 text-end control-label col-form-label"><?php echo e(__('Title')); ?>' +
                '</label>' +

                '<div class="col-sm-8">' +
                '<input type="text" name="title[]" class="form-control title"  id="title" required>' +
                '</div>' +
                '<div class="col-sm-1">' +
                '<button type="button" class="btn btn-danger deleteRow">Delete</button>' +
                '</div>' +
                '</div>' +

                '<div class="form-group row">' +
                '<label for="add_description" class="col-sm-3 text-end control-label col-form-label"><?php echo e(__('Description')); ?>' +
                '</label>' +

                '<div class="col-sm-8">' +
                '<textarea class="form-control summernote" name="add_description[]" id="add_description"><?php echo e(old('add_description')); ?></textarea>' +
                '</div>' +
                '</div>' +
                '</div>';

            $('.features').append(html);
            $('.summernote').summernote();

        }



        $(document).on('click', '.deleteRow', function(e) {
            e.preventDefault();
            $(this).closest('.prod_feature').remove();
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>