<?php $__env->startSection('content'); ?>
    <div class="innerpage-banner">
        <div class="container">
            <div class="innerpage-title flex-center" data-aos="fade-up" data-aos-delay="100">
                <h3>Blog</h3>
            </div>
        </div>
    </div>

    <div class="blog-list comm-PTB-half">
        <div class="container mt-5">
            <div class="row">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6 col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="100">
                        <div class="blog-box">

                            <?php if($blog->image): ?>
                                <div class="blog-img">
                                    <a href="<?php echo e(route('user.blog.blog_detail', ['id' => $blog->id])); ?>">
                                        <img src="<?php echo e(asset('public/' . $blog->image)); ?>"
                                        alt="">
                                    </a>
                                </div>
                            <?php endif; ?>

                            <div class="blog-cont-box">
                                <div class="blog-date"><?php echo e(date('F d, Y', strtotime($blog->date))); ?></div>
                                
                                <h4><a href="blog-detail.html"><?php echo e($blog->title); ?></a></h4>
                                <div class="blog-cont-det">
                                    <?php echo e($blog->description); ?>

                                </div>
                                <div class="readmorelink">

                                    <a href="<?php echo e(route('user.blog.blog_detail', ['id' => $blog->id])); ?>"
                                        class="text-link">Read More
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="d-flex justify-content-center">
                <?php echo $blogs->links(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('user.cart.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/user/blog/blog.blade.php ENDPATH**/ ?>