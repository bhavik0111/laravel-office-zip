<?php $__env->startSection('content'); ?>
    <div class="innerpage-banner">
        <div class="container">
            <div class="innerpage-title flex-center" data-aos="fade-up" data-aos-delay="100">
                <h3>Help & FAQs</h3>
            </div>
        </div>
    </div>
    <div class="faq-page content comm-PTB">
        <div class="container">
            <div class="faq-listing" data-aos="fade-up" data-aos-delay="200">
                <div class="accordion" id="accordionExample">
                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $faqs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h4><?php echo e($faqs->category->name); ?></h4>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="acc-7">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#col-<?php echo e($key); ?>" aria-expanded="false" aria-controls="col-7">
                                    <?php echo e($faqs->title); ?>

                                </button>
                            </h2>
                            <div id="col-<?php echo e($key); ?>"
                                class="accordion-collapse collapse <?php echo e($key == 0 ? 'show' : ''); ?>" aria-labelledby="acc-7"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <p>
                                        <?php echo e($faqs->description); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.cart.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/user/faqs/faqs.blade.php ENDPATH**/ ?>