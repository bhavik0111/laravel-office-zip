<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/admin/assets/extra-libs/multicheck/multicheck.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css')); ?>" />
<?php $__env->startSection('content'); ?>
    <!-- (FOR MSG) -->
    <?php if(session()->has('msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('msg')); ?>

        </div>
    <?php endif; ?>
    <?php if(session()->has('error_msg')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('error_msg')); ?>

        </div>
    <?php endif; ?>
    <!-- (END MSG) -->
    <div class="card mb-3">
        <div class="card-body">
            <div class="card-header row">
                <h4 class="card-title mb-3"><b>All Blogs</b></h4>
                <div class="text-end">
                    <a href="<?php echo e(route('admin.blogs.create')); ?>" class="btn btn-dark"><b>Add+</b></a>
                </div>
            </div>
            <div class="table-responsive">
                <table id="zero_config" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th><b>ID</b></th>
                            <th><b>Name</b></th>
                            <th><b>Image</b></th>
                            <th><b>Title</b></th>
                            <th><b>Description</b></th>
                            <th><b>Status</b></th>
                            <th><b>Action</b></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><strong><?php echo e($blog->id); ?></strong></td>
                                <td><?php echo e($blog->category->name); ?></td>
                                <?php if($blog->image): ?>
                                    <td>
                                        <img src="<?php echo e(asset('public/' . $blog->image)); ?>" height="100" width="100">
                                    </td>
                                    <?php else: ?> <td> </td>
                                <?php endif; ?>
                                <td><?php echo e($blog->title); ?></td>
                                <td><?php echo e($blog->description); ?></td>
                                <td>
                                    <?php if($blog->status == 1): ?>
                                        <?php echo e('Active'); ?>

                                    <?php endif; ?>
                                    <?php if($blog->status == 0): ?>
                                        <?php echo e('Deactive'); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.blogs.edit', $blog->id)); ?>"
                                        class="btn btn-info"><b>Edit</b></a>

                                    <form action="<?php echo e(route('admin.blogs.destroy', $blog->id)); ?>" method="POST"
                                        onsubmit="return confirm('Are you sure Delete User?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger text-white"><b>Delete</b></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <!-- for all pagination,asc-desc,search,shorting  -->
    <script src="<?php echo e(asset('public/admin/assets/extra-libs/multicheck/datatable-checkbox-init.js')); ?>"></script>
    <script src="<?php echo e(asset('public/admin/assets/extra-libs/multicheck/jquery.multicheck.js')); ?>"></script>
    <script src="<?php echo e(asset('public/admin/assets/extra-libs/DataTables/datatables.min.js')); ?>"></script>
    <script>
        /****************************************
         *       Basic Table                   *
         ****************************************/
        $("#zero_config").DataTable();
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/admin/blogs/index.blade.php ENDPATH**/ ?>