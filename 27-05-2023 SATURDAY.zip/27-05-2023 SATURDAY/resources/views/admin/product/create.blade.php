@extends('admin.layout.master')

@section('content')
    <main class="form-signin">
        <div class="card">
            <form method="POST" action="{{ route('admin.product.store') }}" enctype="multipart/form-data">
                @csrf
                <div class="card-body">
                    <h4 class="card-title">{{ __('Create Product') }}</h4>

                    <div class="form-group column" style="float:right">
                        <a href="{{ route('admin.product.index') }}" class="btn btn-dark"><b>Back</b></a>
                    </div>

                    <div class="form-group row">
                        <label for="name"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Category') }}</b></label>
                        <div class="col-sm-9">
                            <select name="category_id" class="form-control @error('category_id') is-invalid @enderror">
                                <option value="0">Select Category</option>
                                @foreach ($categories as $category)
                                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                                @endforeach
                            </select>

                            @error('category_id')
                                <div class="invalid-feedback" role="alert">
                                    {{ $message }}
                                </div>
                            @enderror

                        </div>
                    </div>

                    @php
                        $languages = getLang();
                        $default = getDefaultLang();
                    @endphp

                    <div class="form-group row">
                        <div class="col-sm-3">&nbsp;</div>
                        <div class="col-sm-9">
                            {{-- <a class="btn btn-primary" onclick="changeinput('sp');"><b>Spanish</b></a>

                                <a class="btn btn-primary" onclick="changeinput('fr');"><b>French</b></a>

                                <a class="btn btn-primary" onclick="changeinput('en');"><b>English</b></a> --}}

                            @foreach ($languages as $language)
                                <a class="btn btn-primary" onclick="changeinput('{{ $language->code }}');">
                                    {{-- {{ session()->get('locale') == $language->code ? 'selected' : '' }} --}}
                                    {{ $language->name }}
                                </a>
                            @endforeach
                        </div>

                        <label for="name_en"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Name') }}</b>
                        </label>

                        <div class="col-sm-9">

                            <div class="langdiv" id="inputdiv_en" style="display: {{ $default }} == '{{$language->code}}'? 'block' : 'none' ">

                                <input type="text" class="form-control "
                                    name="name_ {{ $language->code }}"  placeholder="en">

                            </div>





                            <div class="langdiv" id="inputdiv_en" style="display: {{ $default == 'en' ? 'block' : 'none' }}">
                                {{-- <div class="langdiv" id="inputdiv_en"> --}}
                                <input type="text" class="form-control @error('name_en') is-invalid @enderror"
                                    name="name_en" value="{{ old('name_en') }}" placeholder="en">

                                @error('name_en')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdiv" id="inputdiv_fr" style="display: {{ $default == 'fr' ? 'block' : 'none' }}">

                                <input type="text" class=" form-control @error('name_fr') is-invalid @enderror"
                                    name="name_fr" value="{{ old('name_fr') }}" placeholder="fr">

                                @error('name_fr')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdiv" id="inputdiv_sp" style="display: {{ $default == 'sp' ? 'block' : 'none' }}">
                                {{-- <div class="langdiv" id="inputdiv_sp" style="display: none"> --}}
                                <input type="text" class="form-control @error('name_sp') is-invalid @enderror"
                                    name="name_sp" value="{{ old('name_sp') }}" placeholder="sp">

                                @error('name_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdiv" id="inputdiv_br" style="display: {{ $default == 'br' ? 'block' : 'none' }}">
                                {{-- <div class="langdiv" id="inputdiv_sp" style="display: none"> --}}
                                <input type="text" class="form-control @error('name_br') is-invalid @enderror"
                                    name="name_br" value="{{ old('name_br') }}" placeholder="br">

                                @error('name_br')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="cat_image"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Image') }}</b>
                        </label>
                        <div class="col-sm-9">
                            <input id="prod_image" type="file"
                                class="form-control @error('prod_image') is-invalid @enderror" name="prod_image">

                            @error('prod_image')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="price"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Price') }}</b>
                        </label>
                        <div class="col-sm-9">
                            <input id="price" type="number" class="form-control @error('price') is-invalid @enderror"
                                name="price" value="{{ old('price') }}" required autocomplete="price">

                            @error('price')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="colour"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Colour') }}</b>
                        </label>
                        <div class="col-sm-9">
                            <input type="color" id="colour" class="form-control @error('colour') is-invalid @enderror"
                                name="colour" value="{{ old('colour') }}" required autocomplete="colour">

                            @error('colour')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-9">
                            {{-- <a class="btn btn-primary" onclick="changedata('sp');"><b>Spanish</b></a>

                            <a class="btn btn-primary" onclick="changedata('fr');"><b>French</b></a>

                            <a class="btn btn-primary" onclick="changedata('en');"><b>English</b></a> --}}
                            @foreach ($languages as $language)
                                <a class="btn btn-primary" onclick="changedata('{{ $language->code }}');">
                                    {{ session()->get('locale') == $language->code ? 'selected' : '' }}
                                    {{ $language->name }}
                                </a>
                            @endforeach
                        </div>

                        <label for="data_en"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Data') }}</b>
                        </label>

                        <div class="col-sm-9">
                            <div class="langdivdata" id="inputdivdata_en"
                                style="display: {{ $default == 'en' ? 'block' : 'none' }}">

                                <input type="text" class="form-control @error('data_en') is-invalid @enderror"
                                    name="data_en" value="{{ old('data_en') }}" placeholder="en">

                                @error('data_en')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivdata" id="inputdivdata_fr"
                                style="display: {{ $default == 'fr' ? 'block' : 'none' }}">

                                <input type="text" class=" form-control @error('data_fr') is-invalid @enderror"
                                    name="data_fr" value="{{ old('data_fr') }}" placeholder="fr">

                                @error('data_fr')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivdata" id="inputdivdata_sp"
                                style="display: {{ $default == 'sp' ? 'block' : 'none' }}">

                                <input type="text" class="form-control @error('data_sp') is-invalid @enderror"
                                    name="data_sp" value="{{ old('data_sp') }}" placeholder="sp">

                                @error('data_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivdata" id="inputdivdata_br"
                                style="display: {{ $default == 'br' ? 'block' : 'none' }}">

                                <input type="text" class="form-control @error('data_br') is-invalid @enderror"
                                    name="data_br" value="{{ old('data_br') }}" placeholder="br">

                                @error('data_br')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="data_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Data detail') }}</b>
                        </label>
                        <div class="col-sm-9">
                            <textarea id="data_detail" class="form-control @error('data_detail') is-invalid @enderror summernote"
                                name="data_detail" value="{{ old('data_detail') }}" required autocomplete="data_detail"></textarea>
                        </div>

                        @error('data_detail')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3">&nbsp;</div>
                        <div class="col-sm-9">
                            {{-- <a class="btn btn-primary" onclick="changecalls('sp');"><b>Spanish</b></a>

                                <a class="btn btn-primary" onclick="changecalls('fr');"><b>French</b></a>

                                <a class="btn btn-primary" onclick="changecalls('en');"><b>English</b></a> --}}
                            @foreach ($languages as $language)
                                <a class="btn btn-primary" onclick="changecalls('{{ $language->code }}');">
                                    {{ session()->get('locale') == $language->code ? 'selected' : '' }}
                                    {{ $language->name }}
                                </a>
                            @endforeach
                        </div>

                        <label for="calls_en"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Calls') }}</b>
                        </label>

                        <div class="col-sm-9">

                            <div class="langdivcalls" id="inputdivcalls_en"
                                style="display: {{ $default == 'en' ? 'block' : 'none' }}">

                                <input type="text" class="form-control @error('calls_en') is-invalid @enderror"
                                    name="calls_en" value="{{ old('calls_en') }}" placeholder="en">

                                @error('calls_en')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivcalls" id="inputdivcalls_fr"
                                style="display: {{ $default == 'fr' ? 'block' : 'none' }}">

                                <input type="text" class=" form-control @error('calls_fr') is-invalid @enderror"
                                    name="calls_fr" value="{{ old('calls_fr') }}" placeholder="fr">

                                @error('calls_fr')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivcalls" id="inputdivcalls_sp"
                                style="display: {{ $default == 'sp' ? 'block' : 'none' }}">

                                <input type="text" class="form-control @error('calls_sp') is-invalid @enderror"
                                    name="calls_sp" value="{{ old('calls_sp') }}" placeholder="sp">

                                @error('calls_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivcalls" id="inputdivcalls_br"
                                style="display: {{ $default == 'br' ? 'block' : 'none' }}">

                                <input type="text" class="form-control @error('calls_br') is-invalid @enderror"
                                    name="calls_br" value="{{ old('calls_br') }}" placeholder="br">

                                @error('calls_br')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="calls_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Calls detail') }}</b>
                        </label>
                        <div class="col-sm-9">
                            <textarea id="calls_detail" class="form-control @error('calls_detail') is-invalid @enderror summernote"
                                name="calls_detail" value="{{ old('calls_detail') }}" required autocomplete="calls_detail"></textarea>

                            @error('calls_detail')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>

                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-9">
                            {{-- <a class="btn btn-primary" onclick="changesms('sp');"><b>Spanish</b></a>

                                <a class="btn btn-primary" onclick="changesms('fr');"><b>French</b></a>

                                <a class="btn btn-primary" onclick="changesms('en');"><b>English</b></a> --}}
                            @foreach ($languages as $language)
                                <a class="btn btn-primary" onclick="changesms('{{ $language->code }}');">
                                    {{ session()->get('locale') == $language->code ? 'selected' : '' }}
                                    {{ $language->name }}
                                </a>
                            @endforeach

                        </div>

                        <label for="sms_en"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('SMS') }}</b>
                        </label>

                        <div class="col-sm-9">
                            <div class="langdivsms" id="inputdivsms_en"
                                style="display: {{ $default == 'en' ? 'block' : 'none' }}">

                                <input type="text" class="form-control @error('calls_en') is-invalid @enderror"
                                    name="calls_en" value="{{ old('calls_en') }}" placeholder="en">

                                @error('calls_en')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivsms" id="inputdivsms_fr"
                                style="display: {{ $default == 'fr' ? 'block' : 'none' }}">

                                <input type="text" class=" form-control @error('sms_fr') is-invalid @enderror"
                                    name="sms_fr" value="{{ old('sms_fr') }}" placeholder="fr">

                                @error('sms_fr')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivsms" id="inputdivsms_sp"
                                style="display: {{ $default == 'sp' ? 'block' : 'none' }}">

                                <input type="text" class="form-control @error('sms_sp') is-invalid @enderror"
                                    name="sms_sp" value="{{ old('sms_sp') }}" placeholder="sp">

                                @error('sms_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivsms" id="inputdivsms_br"
                                style="display: {{ $default == 'br' ? 'block' : 'none' }}">

                                <input type="text" class="form-control @error('sms_br') is-invalid @enderror"
                                    name="sms_br" value="{{ old('sms_br') }}" placeholder="br">

                                @error('sms_br')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="sms_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('SMS detail') }}</b></label>

                        <div class="col-sm-9">
                            <textarea id="sms_detail" class="form-control @error('sms_detail') is-invalid @enderror summernote"
                                name="sms_detail" value="{{ old('sms_detail') }}" required autocomplete="sms_detail">
                            </textarea>

                            @error('sms_detail')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-9">
                            {{-- <a class="btn btn-primary" onclick="changecrdt('sp');"><b>Spanish</b></a>

                                <a class="btn btn-primary" onclick="changecrdt('fr');"><b>French</b></a>

                                <a class="btn btn-primary" onclick="changecrdt('en');"><b>English</b></a> --}}
                            @foreach ($languages as $language)
                                <a class="btn btn-primary" onclick="changecrdt('{{ $language->code }}');">
                                    {{ session()->get('locale') == $language->code ? 'selected' : '' }}
                                    {{ $language->name }}
                                </a>
                            @endforeach
                        </div>

                        <label for="credit_validity"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Credit validity') }}</b>
                        </label>

                        <div class="col-sm-9">
                            <div class="langdivcrdt" id="inputdivcrdt_en"
                                style="display: {{ $default == 'en' ? 'block' : 'none' }}">

                                <input type="text"
                                    class="form-control @error('credit_validity_en') is-invalid @enderror"
                                    name="credit_validity_en" value="{{ old('credit_validity_en') }}" placeholder="en">

                                @error('credit_validity_en')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivcrdt" id="inputdivcrdt_fr"
                                style="display: {{ $default == 'fr' ? 'block' : 'none' }}">

                                <input type="text"
                                    class=" form-control @error('credit_validity_fr') is-invalid @enderror"
                                    name="credit_validity_fr" value="{{ old('credit_validity_fr') }}" placeholder="fr">

                                @error('credit_validity_fr')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivcrdt" id="inputdivcrdt_sp"
                                style="display: {{ $default == 'sp' ? 'block' : 'none' }}">

                                <input type="text"
                                    class="form-control @error('credit_validity_sp') is-invalid @enderror"
                                    name="credit_validity_sp" value="{{ old('credit_validity_sp') }}" placeholder="sp">

                                @error('credit_validity_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivcrdt" id="inputdivcrdt_br"
                                style="display: {{ $default == 'br' ? 'block' : 'none' }}">

                                <input type="text"
                                    class="form-control @error('credit_validity_br') is-invalid @enderror"
                                    name="credit_validity_br" value="{{ old('credit_validity_br') }}" placeholder="br">

                                @error('credit_validity_br')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="credit_validity_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Credit validity detail') }}</b></label>

                        <div class="col-sm-9">
                            <textarea id="credit_validity_detail"
                                class="form-control @error('credit_validity_detail') is-invalid @enderror summernote"
                                name="credit_validity_detail" value="{{ old('credit_validity_detail') }}" required
                                autocomplete="credit_validity_detail">
                            </textarea>

                            @error('credit_validity_detail')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-9">
                            {{-- <a class="btn btn-primary" onclick="changedesc('sp');"><b>Spanish</b></a>

                                <a class="btn btn-primary" onclick="changedesc('fr');"><b>French</b></a>

                                <a class="btn btn-primary" onclick="changedesc('en');"><b>English</b></a> --}}
                            @foreach ($languages as $language)
                                <a class="btn btn-primary" onclick="changedesc('{{ $language->code }}');">
                                    {{ session()->get('locale') == $language->code ? 'selected' : '' }}
                                    {{ $language->name }}
                                </a>
                            @endforeach
                        </div>

                        <label for="description_en"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Description') }}</b>
                        </label>

                        <div class="col-sm-9">
                            <div class="langdivdesc" id="inputdivdesc_en"
                                style="display: {{ $default == 'en' ? 'block' : 'none' }}">

                                <input type="text" class="form-control @error('description_en') is-invalid @enderror"
                                    name="description_en" value="{{ old('description_en') }}" placeholder="en">

                                @error('description_en')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivdesc" id="inputdivdesc_fr"
                                style="display: {{ $default == 'fr' ? 'block' : 'none' }}">

                                <input type="text" class=" form-control @error('description_fr') is-invalid @enderror"
                                    name="description_fr" value="{{ old('description_fr') }}" placeholder="fr">

                                @error('description_fr')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivdesc" id="inputdivdesc_sp"
                                style="display: {{ $default == 'sp' ? 'block' : 'none' }}">

                                <input type="text" class="form-control @error('description_sp') is-invalid @enderror"
                                    name="description_sp" value="{{ old('description_sp') }}" placeholder="sp">

                                @error('description_sp')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="langdivdesc" id="inputdivdesc_br"
                                style="display: {{ $default == 'br' ? 'block' : 'none' }}">

                                <input type="text" class="form-control @error('description_br') is-invalid @enderror"
                                    name="description_br" value="{{ old('description_br') }}" placeholder="br">

                                @error('description_br')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="description"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Additional Features') }}</b>
                        </label>

                        <div class="col-sm-9">
                            <button type="button" class="btn btn-primary" onclick="addrow()">
                                {{ __('AddNewFeature') }}
                            </button>
                        </div>
                    </div>

                    <div class="features">
                        <!-- (click AddNew all title and description field are placed heare....) -->
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Status') }}</b></label>
                        <div class="col-md-9">
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation1"
                                    name="status"value="1" required />

                                <label class="form-check-label mb-0"
                                    for="customControlValidation1">{{ __('Active') }}</label>

                            </div>
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation2"
                                    name="status" value="0" required />
                                <label class="form-check-label mb-0"
                                    for="customControlValidation2">{{ __('Deactive') }}</label>
                            </div>
                        </div>
                    </div>

                    <div class="border-top">
                        <div class="card-body" style="float:center">
                            <button type="submit" class="btn btn-primary">
                                {{ __('submit') }}
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </main>
@endsection
@push('scripts')
    <script>
        function changeinput(language) {
            $(".langdiv").css('display', 'none');
            $("#inputdiv_" + language).css('display', 'block');
        }
    </script>
    <script>
        function changedata(language) {
            $(".langdivdata").css('display', 'none');
            $("#inputdivdata_" + language).css('display', 'block');
        }
    </script>
    <script>
        function changecalls(language) {
            $(".langdivcalls").css('display', 'none');
            $("#inputdivcalls_" + language).css('display', 'block');
        }
    </script>
    <script>
        function changesms(language) {
            $(".langdivsms").css('display', 'none');
            $("#inputdivsms_" + language).css('display', 'block');
        }
    </script>
    <script>
        function changedesc(language) {
            $(".langdivdesc").css('display', 'none');
            $("#inputdivdesc_" + language).css('display', 'block');
        }
    </script>
    <script>
        function changecrdt(language) {
            $(".langdivcrdt").css('display', 'none');
            $("#inputdivcrdt_" + language).css('display', 'block');
        }
    </script>



    <script>
        $(document).ready(function() {
            $('.summernote').summernote();
        });



        function addrow() {
            var html =
                '<div class="prod_feature">' +
                '<div class="form-group row">' +
                '<label for="title"  class="col-sm-3 text-end control-label col-form-label">{{ __('Title') }}' +
                '</label>' +

                '<div class="col-sm-8">' +
                '<input type="text" name="title[]" class="form-control title"  id="title" required>' +
                '</div>' +
                '<div class="col-sm-1">' +
                '<button type="button" class="btn btn-danger deleteRow">Delete</button>' +
                '</div>' +
                '</div>' +

                '<div class="form-group row">' +
                '<label for="add_description" class="col-sm-3 text-end control-label col-form-label">{{ __('Description') }}' +
                '</label>' +

                '<div class="col-sm-8">' +
                '<textarea class="form-control summernote" name="add_description[]" id="add_description">{{ old('add_description') }}</textarea>' +
                '</div>' +
                '</div>' +
                '</div>';

            $('.features').append(html);

            $('.summernote').summernote();
        }

        $(document).on('click', '.deleteRow', function(e) {
            e.preventDefault();
            $(this).closest('.prod_feature').remove();
        })
    </script>
@endpush
