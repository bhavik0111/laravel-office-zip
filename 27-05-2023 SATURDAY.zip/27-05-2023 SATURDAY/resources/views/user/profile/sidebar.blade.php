<div class="mt-5">
    <div>
        <ul>
            @auth
                <li class="p-2 text-white"><a class="text-white" href="{{ route('user.profile.profile') }}">Edit profile</a></li>
                <li class="p-2 text-white"><a class="text-white" href="{{ route('user.order.index') }}">All Order</a></li>
                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                    @csrf
                </form>
                    @auth
                    <li class="p-2 text-white"><a class="text-white" href="{{ route('logout') }}"
                            onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"><i
                                class="fa fa-power-off me-1 ms-1"></i> Logout</a>
                            </li>
                    @endauth
            @endauth
        </ul>
    </div>
</div>