<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Product;
use App\Models\Category;
use Illuminate\Http\Request;
use App\Models\ProductFeature;
use Illuminate\Support\Facades\Session;



class UserController extends Controller
{
    public function show($id)
    {
        $category = Category::where('id', $id)->get()->first();
        $products = Product::where('category_id', $id)->get()->all();
        return view('user.category.show', compact('products', 'category'));
    }


    public function home(Request $request)     //<--(FOR USER MAIN HOME PAGE CATEGORY,PRODUCT LISTING)-->
    {
        $language = Session::get('locale');
        $allcategory = Category::get()->all();

        // $products = Product::with('category', 'features')->get()->all();
        // $products = Product::with('category', 'features')->paginate(6);
        // where([ ['status', 1],['language',$language] ])->get();

        //whereNotNull('name_'.$default)->


        // $products = Product::whereNotNull('name_' . $language)->with('category')->paginate(6);

        $products = Product::with('category')->paginate(6);

        $default = getDefaultLang();

        if (!$products->total()>0) {
            $products = Product::whereNotNull('name_' . $default)->with('category')->paginate(6);
        }

        $features = ProductFeature::get()->all();
        return view('home', compact('products', 'features', 'allcategory', 'language'));
    }

    public function login()      //<--(FOR USER LOGIN)-->
    {
        return view('user.auth.login');
    }

    function profile_view()     //<--(FOR LOGIN USER PROFILE VIEW...)-->
    {
        return view('user.profile.index');
    }

    public function profile(Request $request)  //<--(USER PROFILE)-->
    {
        $user = User::where('id', auth()->user()->id)->first();
        return view('user.profile.profile', compact('user'));
    }

    public function profileupdate(Request $req)    //<--(PROFILE UPDATE INSERT IN DB)-->
    {

        $user = User::where('id', $req->id)->get()->first();
        // dd($req);
        $user->name = $req->name;
        $user->last_name = $req->last_name;
        $user->email = $req->email;
        $user->password = bcrypt($req->password);

        $req->verify_acc ? $req->verify_acc : $user->verify_acc;
        $req->is_admin ? $req->is_admin : $user->is_admin;
        // $user->verify_acc = $req->verify_acc;
        // $user->is_admin = $req->is_admin;

        $user->save();

        return redirect()->route('user.profile.profile')->with('msg', 'profile Updated');
    }

    public function dashboard(Request $request)
    {
        return view('user.dashbord');
    }

    public function adduser(Request $request)
    {
        // user form
        return view('user.adduser');
    }

    public function store(Request $req)    //<--(INSERT IN DB)-->
    {

        $req->validate([
            'password' => ['required', 'string', 'min:6']
        ]);

        $user = new user;
        $user->name = $req->name;
        $user->last_name = $req->last_name;
        $user->email = $req->email;
        $user->password = bcrypt($req->password);
        $user->is_admin = $req->is_admin;
        $user->save();
        // $student::create($req->all());
        return redirect()->route('user.index')->with('msg', 'Record Successfully Inserted');
    }


    public function index(Request $request)      // FOR USER LISTING...
    {
        $users = User::get()->all();
        return view('user.uindex', compact('users'));
    }

    public function edit($id)       //<--(USER EDIT FORM)-->
    {

        $user = User::where('id', $id)->get()->first();
        return view('user.uedit', compact('user'));
    }


    function update(Request $req)   //<--(USER UPDATE IN DB)-->
    {

        $user = User::where('id', $req->id)->get()->first();
        // dd($req);
        $user->name = $req->name;
        $user->last_name = $req->last_name;
        $user->email = $req->email;
        $user->password = bcrypt($req->password);
        $user->verify_acc = $req->verify_acc;
        $user->is_admin = $req->is_admin;

        $user->save();

        return redirect()->route('user.index')->with('msg', 'Record Updated');
    }


    function destroy($id)           //FOR USER DELETE...
    {
        $user = User::where('id', $id)
            ->get()
            ->first();
        $user->delete();

        return redirect()->route('user.index')->with('msg', 'Record Deleted');
    }

    //<--(LISTING FILE BUTTONS VERIFY AND UNVERIFY)-->

    function verify($id)            //FOR USER VERIFY...
    {
        $user = user::where('id', $id)->get()->first();
        $user->verify_acc = 1;
        $user->save();
        return redirect()->route('user.index')->with('msg', 'user account is verifyed');
    }

    function unverify($id)          //FOR USER UN-VERIFY...
    {

        $user = user::where('id', $id)->get()->first();
        $user->verify_acc = 0;
        $user->save();
        return redirect()->route('user.index')->with('msg', 'user account is unverifyed');
    }
}
