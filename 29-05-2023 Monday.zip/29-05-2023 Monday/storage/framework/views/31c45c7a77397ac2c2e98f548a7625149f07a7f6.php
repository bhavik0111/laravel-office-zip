<?php $__env->startSection('content'); ?>

<?php
    $languages = getLang();
    $default = getDefaultLang();
?>

    <main class="form-signin">
        <div class="card">
            <form method="POST" action="<?php echo e(route('admin.product.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <h4 class="card-title"><?php echo e(__('Create Product')); ?></h4>

                    <div class="form-group column" style="float:right">
                        <a href="<?php echo e(route('admin.product.index')); ?>" class="btn btn-dark"><b>Back</b></a>
                    </div>

                    <div class="form-group row">
                        <label for="name"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Category')); ?></b>
                        </label>
                        <div class="col-sm-9">
                            <select name="category_id" class="form-control <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="0">Select Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback" role="alert">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3">&nbsp;</div>
                        <div class="col-sm-9">    
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="btn btn-primary" onclick="changeinput('<?php echo e($language->code); ?>','name');">
                                    <?php echo e($language->name); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <label for="name_en"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Name')); ?></b>
                        </label>
                        <div class="col-sm-9">
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="langdivname" id="inputdivname_<?php echo e($language->code); ?>"
                                    style="display: <?php echo e($default == $language->code ? 'block' : 'none'); ?>">

                                    <input type="text" class="form-control <?php $__errorArgs = ['name_'.$language->code];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="name_<?php echo e($language->code); ?>" value="<?php echo e(old('name_'.$language->code)); ?>" placeholder="<?php echo e($language->code); ?>">

                                    <?php $__errorArgs = ['name_'.$language->code];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="cat_image"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Image')); ?></b>
                        </label>
                        <div class="col-sm-9">
                            <input id="prod_image" type="file"
                                class="form-control <?php $__errorArgs = ['prod_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="prod_image">

                            <?php $__errorArgs = ['prod_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="price"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Price')); ?></b>
                        </label>
                        <div class="col-sm-9">
                            <input id="price" type="number" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="price" value="<?php echo e(old('price')); ?>" required autocomplete="price">

                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="colour"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Colour')); ?></b>
                        </label>
                        <div class="col-sm-9">
                            <input type="color" id="colour" class="form-control <?php $__errorArgs = ['colour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="colour" value="<?php echo e(old('colour')); ?>" required autocomplete="colour">

                            <?php $__errorArgs = ['colour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-9">   

                            

                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="btn btn-primary" onclick="changeinput('<?php echo e($language->code); ?>','data');">
                                    <?php echo e($language->name); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <label for="data_en"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Data')); ?></b>
                        </label>
                        <div class="col-sm-9">
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="langdivdata" id="inputdivdata_<?php echo e($language->code); ?>"
                                    style="display: <?php echo e($default == $language->code ? 'block' : 'none'); ?>">

                                    <input type="text" class="form-control <?php $__errorArgs = ['data_'.$language->code];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="data_<?php echo e($language->code); ?>" value="<?php echo e(old('data_'.$language->code)); ?>" placeholder="<?php echo e($language->code); ?>">

                                    <?php $__errorArgs = ['data_'.$language->code];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="data_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Data detail')); ?></b>
                        </label>
                        <div class="col-sm-9">
                            <textarea id="data_detail" class="form-control <?php $__errorArgs = ['data_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> summernote"
                                name="data_detail" value="<?php echo e(old('data_detail')); ?>" required autocomplete="data_detail"></textarea>
                        </div>

                        <?php $__errorArgs = ['data_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3">&nbsp;</div>
                        <div class="col-sm-9">  
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="btn btn-primary" onclick="changeinput('<?php echo e($language->code); ?>','calls');">
                                    <?php echo e($language->name); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <label for="calls_en"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Calls')); ?></b>
                        </label>

                        <div class="col-sm-9">

                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="langdivcalls" id="inputdivcalls_<?php echo e($language->code); ?>"
                                    style="display: <?php echo e($default == $language->code ? 'block' : 'none'); ?>">

                                    <input type="text" class="form-control <?php $__errorArgs = ['calls_'.$language->code];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="calls_<?php echo e($language->code); ?>" value="<?php echo e(old('calls_'.$language->code)); ?>" placeholder="<?php echo e($language->code); ?>">

                                    <?php $__errorArgs = ['calls_'.$language->code];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="calls_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Calls detail')); ?></b>
                        </label>
                        <div class="col-sm-9">
                            <textarea id="calls_detail" class="form-control <?php $__errorArgs = ['calls_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> summernote"
                                name="calls_detail" value="<?php echo e(old('calls_detail')); ?>" required autocomplete="calls_detail"></textarea>

                            <?php $__errorArgs = ['calls_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-9">    
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="btn btn-primary" onclick="changeinput('<?php echo e($language->code); ?>','sms');">
                                    <?php echo e($language->name); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                        <label for="sms_en"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('SMS')); ?></b>
                        </label>

                        <div class="col-sm-9">
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="langdivsms" id="inputdivsms_<?php echo e($language->code); ?>"
                                    style="display: <?php echo e($default == $language->code ? 'block' : 'none'); ?>">

                                    <input type="text" class="form-control <?php $__errorArgs = ['sms_'.$language->code];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="sms_<?php echo e($language->code); ?>" value="<?php echo e(old('sms_'.$language->code)); ?>" placeholder="<?php echo e($language->code); ?>">

                                    <?php $__errorArgs = ['sms_'.$language->code];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="sms_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('SMS detail')); ?></b></label>

                        <div class="col-sm-9">
                            <textarea id="sms_detail" class="form-control <?php $__errorArgs = ['sms_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> summernote"
                                name="sms_detail" value="<?php echo e(old('sms_detail')); ?>" required autocomplete="sms_detail">
                            </textarea>

                            <?php $__errorArgs = ['sms_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-9">  
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="btn btn-primary" onclick="changeinput('<?php echo e($language->code); ?>','crdt');">
                                    <?php echo e($language->name); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <label for="credit_validity"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Credit validity')); ?></b>
                        </label>

                        <div class="col-sm-9">

                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="langdivcrdt" id="inputdivcrdt_<?php echo e($language->code); ?>"
                                    style="display: <?php echo e($default == $language->code ? 'block' : 'none'); ?>">

                                    <input type="text" class="form-control <?php $__errorArgs = ['credit_validity_'.$language->code];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="credit_validity_<?php echo e($language->code); ?>" value="<?php echo e(old('credit_validity_'.$language->code)); ?>" placeholder="<?php echo e($language->code); ?>">

                                    <?php $__errorArgs = ['credit_validity_'.$language->code];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="credit_validity_detail"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Credit validity detail')); ?></b></label>

                        <div class="col-sm-9">
                            <textarea id="credit_validity_detail"
                                class="form-control <?php $__errorArgs = ['credit_validity_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> summernote"
                                name="credit_validity_detail" value="<?php echo e(old('credit_validity_detail')); ?>" required
                                autocomplete="credit_validity_detail">
                            </textarea>

                            <?php $__errorArgs = ['credit_validity_detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-9">  
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="btn btn-primary" onclick="changeinput('<?php echo e($language->code); ?>','desc');">
                                    <?php echo e($language->name); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <label for="description_en"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Description')); ?></b>
                        </label>

                        <div class="col-sm-9">

                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="langdivdesc" id="inputdivdesc_<?php echo e($language->code); ?>"
                                    style="display: <?php echo e($default == $language->code ? 'block' : 'none'); ?>">

                                    <input type="text" class="form-control <?php $__errorArgs = ['description_'.$language->code];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="description_<?php echo e($language->code); ?>" value="<?php echo e(old('description_'.$language->code)); ?>" placeholder="<?php echo e($language->code); ?>">

                                    <?php $__errorArgs = ['description_'.$language->code];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="description"
                            class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Additional Features')); ?></b>
                        </label>

                        <div class="col-sm-9">
                            <button type="button" class="btn btn-primary" onclick="addrow()">
                                <?php echo e(__('AddNewFeature')); ?>

                            </button>
                        </div>
                    </div>

                    <div class="features">
                        <!-- (click AddNew all title and description field are placed heare....) -->
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 text-end control-label col-form-label"><b><?php echo e(__('Status')); ?></b></label>
                        <div class="col-md-9">
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation1"
                                    name="status"value="1" required />

                                <label class="form-check-label mb-0"
                                    for="customControlValidation1"><?php echo e(__('Active')); ?>

                                </label>

                            </div>
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation2"
                                    name="status" value="0" required />
                                <label class="form-check-label mb-0"
                                    for="customControlValidation2"><?php echo e(__('Deactive')); ?></label>
                            </div>
                        </div>
                    </div>

                    <div class="border-top">
                        <div class="card-body" style="float:center">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('submit')); ?>

                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        function changeinput(language,field) {
            $(".langdiv"+ field).css('display', 'none');
            $("#inputdiv" + field +"_"+ language).css('display', 'block');
        }
    </script>



    <script>
        $(document).ready(function() {
            $('.summernote').summernote();
        });



        function addrow() {
            var html =
                '<div class="prod_feature">' +
                '<div class="form-group row">' +
                '<label for="title"  class="col-sm-3 text-end control-label col-form-label"><?php echo e(__('Title')); ?>' +
                '</label>' +

                '<div class="col-sm-8">' +
                '<input type="text" name="title[]" class="form-control title"  id="title" required>' +
                '</div>' +
                '<div class="col-sm-1">' +
                '<button type="button" class="btn btn-danger deleteRow">Delete</button>' +
                '</div>' +
                '</div>' +

                '<div class="form-group row">' +
                '<label for="add_description" class="col-sm-3 text-end control-label col-form-label"><?php echo e(__('Description')); ?>' +
                '</label>' +

                '<div class="col-sm-8">' +
                '<textarea class="form-control summernote" name="add_description[]" id="add_description"><?php echo e(old('add_description')); ?></textarea>' +
                '</div>' +
                '</div>' +
                '</div>';

            $('.features').append(html);

            $('.summernote').summernote();
        }

        $(document).on('click', '.deleteRow', function(e) {
            e.preventDefault();
            $(this).closest('.prod_feature').remove();
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/admin/product/create.blade.php ENDPATH**/ ?>