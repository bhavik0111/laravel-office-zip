<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/admin/assets/extra-libs/multicheck/multicheck.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css')); ?>" />

<?php $__env->startSection('content'); ?>
    <div class="innerpage-banner">
        <div class="container">
            <div class="innerpage-title flex-center" data-aos="fade-up" data-aos-delay="100">
                <h3>Cart</h3>
            </div>
        </div>
    </div>
    <div class="innerpage-common comm-PTB">

        <!-- (FOR MSG) -->
        <?php if(session()->has('msg')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('msg')); ?>

            </div>
        <?php endif; ?>
        <?php if(session()->has('error_msg')): ?>
            <div class="alert alert-danger">
                <?php echo e(session()->get('error_msg')); ?>

            </div>
        <?php endif; ?>
        <!-- (END MSG) -->
        <div class="card mb-3">
            <div class="card-body">
                <!-- <div class="card-header row">
                            <h4 class="card-title mb-3"><b>cart</b></h4>
                        </div> -->

                <div class="form-group column" style="float:right">
                    <a href="<?php echo e(route('user.home')); ?>" class="btn btn-dark"><b>Back</b></a>
                </div>

                <div class="table-responsive">
                    <table id="zero_config" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th><b>ID</b></th>
                                <th><b>product name</b></th> <!-- product_id as product name -->
                                <th><b>qty</b></th>
                                <th><b>Price</b></th>

                                <th><b>Action</b></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $total = 0; ?>
                            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $total = $total + $cart->product->price;
                                ?>
                                <tr>
                                    <td><strong><?php echo e($cart->id); ?></strong></td>
                                    <td><?php echo e($cart->product->name); ?></td>

                                    <td>
                                        <input type="number" value="<?php echo e($cart->qty); ?>" class="form-control"
                                            style="display:none;" id="qty_<?php echo e($key); ?>"
                                            onfocusout="saveqty('<?php echo e($key); ?>',this.value)">
                                        <input type="hidden" value="<?php echo e($cart->product_id); ?>"
                                            id="product_id_<?php echo e($key); ?>">
                                        <div id="display_qty_<?php echo e($key); ?>"><?php echo e($cart->qty); ?></div>
                                    </td>

                                    <td><?php echo e($cart->product->price); ?></td>

                                    <td>
                                        <!-- <a onclick="changeqty('<?php echo e($key); ?>')"
                                                class="btn btn-info"><b><?php echo e(__('Edit')); ?></b></a> -->

                                        <form action="#" method="POST"
                                            onsubmit="return confirm('Are you sure Delete User?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit"
                                                class="btn btn-danger text-white"><b><?php echo e(__('Delete')); ?></b></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="3" align="right"><b>Total:</b></td>
                                <td colspan="2" class="text-right"><?php echo e($total); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="text-end">
                        <a href="<?php echo e(route('user.order.create')); ?>" class="btn btn-dark"><b>
                                <?php echo e(__('Process to Checkout')); ?></b></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!--(for all pagination,asc-desc,search,shorting)-->
    <script src="<?php echo e(asset('public/admin/assets/extra-libs/multicheck/datatable-checkbox-init.js')); ?>"></script>
    <script src="<?php echo e(asset('public/admin/assets/extra-libs/multicheck/jquery.multicheck.js')); ?>"></script>
    <script src="<?php echo e(asset('public/admin/assets/extra-libs/DataTables/datatables.min.js')); ?>"></script>

    <script>
        // $("#zero_config").DataTable();
        function changeqty(index) {
            $('#qty_' + index).css('display', 'block');
            $('#display_qty_' + index).css('display', 'none');
        }

        function saveqty(index, qty) {
            $('#qty_' + index).css('display', 'none');
            var product_id = $('#product_id_' + index).val();
            $('#display_qty_' + index).css('display', 'block');
            $.ajax({
                type: 'POST',
                url: '<?php echo e(route('user.cart.qtyupdate')); ?>',
                data: {
                    'product_id': product_id,
                    'qty': qty,
                    '_token': '<?php echo e(csrf_token()); ?>'
                },
                dataType: 'json',
                success: function(data) {
                    $('#display_qty_' + index).html(qty);
                },
                error: function(data) {
                    console.log(data);
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('user.cart.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/user/cart/cart.blade.php ENDPATH**/ ?>