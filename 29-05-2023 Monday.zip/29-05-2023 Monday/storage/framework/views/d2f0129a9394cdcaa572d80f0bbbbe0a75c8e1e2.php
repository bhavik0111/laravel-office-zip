<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/admin/assets/extra-libs/multicheck/multicheck.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css')); ?>" />
<?php $__env->startSection('content'); ?>
    <!-- (FOR MSG) -->
    <?php if(session()->has('msg')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('msg')); ?>

        </div>
    <?php endif; ?>
    <?php if(session()->has('error_msg')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('error_msg')); ?>

        </div>
    <?php endif; ?>
    <!-- (END MSG) -->
    <div class="card mb-3">
        <div class="card-body">
            <div class="card-header row">
                <h4 class="card-title mb-3"><b>All Categories</b></h4>
                <div class="text-end">
                    <a href="<?php echo e(route('admin.category.create')); ?>" class="btn btn-dark"><b>Add+</b></a>
                </div>
            </div>
            <div class="table-responsive">
                <table id="zero_config" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th><b>ID</b></th>
                            <th><b>Name</b></th>
                            <th><b>Image</b></th>
                            
                            <th><b>Description</b></th>
                            <th><b>Status</b></th>
                            <th><b>Action</b></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><strong><?php echo e($category->id); ?></strong></td>

                                <?php if($category->name): ?>
                                    <td><?php echo e($category->name); ?></td>
                                <?php endif; ?>
                                <?php if($category->name_fr): ?>
                                    <td><?php echo e($category->name_fr); ?></td>
                                <?php endif; ?>
                                <?php if($category->name_sp): ?>
                                    <td><?php echo e($category->name_sp); ?></td>
                                <?php endif; ?>

                                <?php if($category->image): ?>
                                    <td>
                                        <img src="<?php echo e(asset('public/' . $category->image)); ?>" height="100" width="100">
                                    </td>
                                <?php endif; ?>
                                <?php if($category->image_fr): ?>
                                    <td>
                                        <img src="<?php echo e(asset('public/' . $category->image_fr)); ?>" height="100"
                                            width="100">
                                    </td>
                                <?php endif; ?>
                                <?php if($category->image_sp): ?>
                                    <td>
                                        <img src="<?php echo e(asset('public/' . $category->image_sp)); ?>" height="100"
                                            width="100">
                                    </td>
                                <?php endif; ?>

                                <?php if($category->description): ?>
                                    <td><?php echo e($category->description); ?></td>
                                <?php endif; ?>
                                <?php if($category->description_fr): ?>
                                    <td><?php echo e($category->description_fr); ?></td>
                                <?php endif; ?>
                                <?php if($category->description_sp): ?>
                                    <td><?php echo e($category->description_sp); ?></td>
                                <?php endif; ?>

                                <td>
                                    <?php if($category->status == 1): ?>
                                        <?php echo e('Active'); ?>

                                    <?php endif; ?>
                                    <?php if($category->status == 0): ?>
                                        <?php echo e('Deactive'); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.category.edit', $category->id)); ?>"
                                        class="btn btn-info"><b>Edit</b></a>

                                    <form action="<?php echo e(route('admin.category.destroy', $category->id)); ?>" method="POST"
                                        onsubmit="return confirm('Are you sure Delete User?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger text-white"><b>Delete</b></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <!-- for all pagination,asc-desc,search,shorting  -->
    <script src="<?php echo e(asset('public/admin/assets/extra-libs/multicheck/datatable-checkbox-init.js')); ?>"></script>
    <script src="<?php echo e(asset('public/admin/assets/extra-libs/multicheck/jquery.multicheck.js')); ?>"></script>
    <script src="<?php echo e(asset('public/admin/assets/extra-libs/DataTables/datatables.min.js')); ?>"></script>
    <script>
        /****************************************
         *       Basic Table                   *
         ****************************************/
        $("#zero_config").DataTable({
            order: [[0, 'desc']],
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larabootstrap\resources\views/admin/category/index.blade.php ENDPATH**/ ?>