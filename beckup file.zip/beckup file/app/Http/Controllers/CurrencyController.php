<?php

namespace App\Http\Controllers;

use App\Models\Currency;
use App\Models\GlobalSetting;
use Illuminate\Http\Request;

class CurrencyController extends Controller
{
    public function create(Request $req)   // Currency form open
    {
        return view('admin.currency.create');
    }

    public function index(Request $req)   //Currency LISTING...
    {
        $currency = Currency::get();
        return view('admin.currency.index', compact('currency'));
    }

    public function store(Request $req)     //INSERT IN DB...
    {
        $req->validate([
            'name' => ['required'],
            'code' => ['required'],
            'symbole' => ['required'],
            'status' => 'required'
        ]);

        $currency = new Currency();
        $currency->name = $req->name;
        $currency->code = $req->code;
        $currency->symbole = $req->symbole;
        $currency->status = $req->status;

        $currency->save();

        return redirect()->route('admin.currency.index')->with('msg', 'new currency added');
    }

    public function edit($id)
    {
        // user EDIT form display...
        $currency = Currency::where('id', $id)->first();

        if (empty($currency)) {
            return redirect()->route('admin.currency.index');
        }

        return view('admin.currency.edit', compact('currency'));
    }

    function update(Request $req)
    {
        //user UPDATE IN DB...
        $currency = Currency::where('id', $req->id)->first();

            if($req->status == 0){

                $global = GlobalSetting::get()->first();

                    if($global->currency == $currency->code){
                        $global->currency = 'INR';
                        $global->save();
                    }
            }

        $currency->name = $req->name;
        $currency->code = $req->code;
        $currency->symbole = $req->symbole;
        $currency->status = $req->status;



        $currency->save();

        return redirect()->route('admin.currency.index')->with('msg', 'currency Updated');
    }

    function destroy($id)    //FOR currency DELETE...
    {
        $currency = Currency::where('id', $id)->get()->first();

        $currency->delete();
        return redirect()->route('admin.currency.index')->with('msg', 'Record Deleted');
    }
}
