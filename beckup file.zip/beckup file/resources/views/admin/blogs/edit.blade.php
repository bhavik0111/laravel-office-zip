@extends('admin.layout.master')
@section('content')
    <main class="form-signin">

        <div class="card">
            <form action="{{ route('admin.blogs.update', $blog->id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="card-body">
                    <h4 class="card-title">Update Blog</h4>

                    <div class="card-body">
                        <div class="form-group column" style="float:right">
                            <a href="{{ route('admin.blogs.index') }}" class="btn btn-dark"><b>Back</b></a>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label for="category_id"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Name') }}</b></label>
                        <div class="col-sm-9">

                            <select name="category_id" class="form-control  @error('category_id') is-invalid @enderror ">
                                <option value="" selected>Select Category</option>

                                @foreach ($categories as $category)
                                    <option value="{{ $category->id }}"
                                        {{ $category->id == $blog->category_id ? 'selected' : '' }}>{{ $category->name }}
                                    </option>
                                @endforeach
                            </select>

                            @error('category_id')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="image"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Image') }}</b></label>

                        <div class="col-sm-9">
                            <input id="image" type="file" class="form-control" name="image" autocomplete="image"
                                autofocus>

                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="title"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Title') }}</b></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control @error('title') is-invalid @enderror"
                                value="{{ old('title', $blog->title) }}" id="title" name="title" placeholder=" title">

                            <input type="hidden" name="id" value="{{ $blog->id }}">

                        </div>
                        @error('name')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div class="form-group row">
                        <label for="description"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Description') }}</b></label>
                        <div class="col-sm-9">
                            <textarea class="form-control @error('description')is-invalid @enderror"
                                value="" id="description" name="description"
                                placeholder="name@example.com">{{ old('description', $blog->description) }}
                            </textarea>
                        </div>
                        @error('description')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div class="form-group row">
                        <label for="date"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Date') }}</b></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control @error('date')is-invalid @enderror"
                                value="{{ old('date', $blog->date) }}" id="datepicker" name="date"
                                placeholder="name@example.com">
                        </div>
                        @error('date')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 text-end control-label col-form-label"><b>Status</b></label>
                        <div class="col-md-9">
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation1" name="status"
                                    value="1" @if ($blog->status == 1) {{ 'checked=checked' }} @endif
                                    required />
                                <label class="form-check-label mb-0"
                                    for="customControlValidation1">{{ __('Active') }}</label>

                            </div>
                            <div class="form-check">

                                <input type="radio" class="form-check-input" id="customControlValidation2" name="status"
                                    value="0" @if ($blog->status == 0) {{ 'checked=checked' }} @endif
                                    required />
                                <label class="form-check-label mb-0"
                                    for="customControlValidation2">{{ __('Deactive') }}</label>
                            </div>
                        </div>
                    </div>



                </div>
                <div class="border-top">
                    <div class="card-body">
                        <button type="submit" name="uedit" class="btn btn-primary">
                            Edit
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </main>
@endsection
@push('scripts')

<link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>

<script>
$( function() {
  $( "#datepicker" ).datepicker();
} );
</script>

@endpush
