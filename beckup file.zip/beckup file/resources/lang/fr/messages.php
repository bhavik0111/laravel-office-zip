<?php
//french language
return [
    //admin side
        'category' => [
            'add_category'  => 'ajouter une catégorie',
        ],

    //<div class="homemanibanner">
        'home_container' => 'Trouvez eSIM pour plus de 130 destinations',
        'home1'          => 'Les meilleures offres dans le monde',
        'home2'          => 'Rechercher une destination...',

        'product' => [
            'all_products'  => 'Tous les produits',
        ],

        'header' => [
            'eSIM'    => 'eSIM',
            'blog'    => 'Blog',
            'help'    => 'Aide et FAQ',
            'cart'    => 'Chariot',
            'profile' => 'Profil',
        ],

        'master' => [
            'head'   => 'Comment ça fonctionne',
            'heada'  => 'Vérifier',
            'headb'  => 'Aide et FAQ',
            'headc'  => 'pour voir si votre appareil prend en charge eSIM',
            'headd'  => 'Choisissez la destination et le forfait',
            'heade'  => 'MobiMatter propose des forfaits eSIM pour plus de 130 pays',
            'headf'  => 'Installer eSIM',
            'headg'  => 'Obtenez instantanément votre eSIM et configurez-la dans votre appareil compatible eSIM',
            'headh'  => 'Profitez d une connectivité haut débit',
            'headi'  => 'Une fois l eSIM configuré, vous pouvez profiter d une connectivité de données en itinérance à haut débit',
            'headj'  => 'Processus d activation eSIM',
            'headk'  => 'Lorem Ipsum est simplement un faux texte de l industrie de l impression et de la composition. Lorem Ipsum a été la norme de l industrie Lorem Ipsum est simplement un texte factice de l industrie de l impression et de la composition. Lorem Ipsum a été la norme de l industrie',
            'headl'  => 'Android',
            'headm'  => 'Pomme',
        ],

        'footer' => [
            'Quick'   => 'Liens rapides',
            'Quicka'  => 'Nouvelle eSIM',
            'Quickb'  => 'Recharge',
            'Quickc'  => 'Vérifier l utilisation',
            'Quickd'  => 'Blog',
            'Quicke'  => 'Aide et FAQ',
            'Quickf'  => 'Détails du contact',
            'Quickg'  => 'Rester en contact',
        ],

        'category' => [
            'add_category'  => 'Ajouter une catégorie',
            'name' => 'Nom',
            'image' => 'Image',
            'description' => 'Description',
        ],


];
