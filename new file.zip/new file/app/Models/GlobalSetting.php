<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GlobalSetting extends Model
{
    use HasFactory;
    protected $table = 'globalsetting';
    protected $fillable = [
        'logo',
        'faceicon',
        'site_title',
        'address',
        'phone',
        'email',
        'facebook_url',
        'linkdin_url',
        'insta_url',
        'payment_logo',
        'footer_logo',
        'about_us',
        'copyright_msg',
        'currency',
        'currency_id',

    ];

    public function currency()  // relation
    {
       return $this->belongsTo(Currency::class); //single return (belongsTo)
    }

}
