<?php

namespace App\Http\Controllers;
use App\Models\FaqsCategory;
use Illuminate\Http\Request;

class FaqsCategoryController extends Controller
{
    public function create(Request $request)  //<--(faqs category FORM CREATE)-->
    {
        return view('admin.faqs.category.create');
    }

    public function store(Request $request)   //<--(INSERT IN DB...)-->
    {
        $request->validate([

            'name' => ['required'],
            'description' => ['required'],
            'status' => 'required'
        ]);


        $category = new FaqsCategory();
        $category->name = $request->name;
        $category->description = $request->description;
        $category->status = $request->status;


        $category->save();

        return redirect()->route('admin.faqs.index')->with('msg', 'Category Successfully Inserted');
    }

}
