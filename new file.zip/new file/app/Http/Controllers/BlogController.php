<?php

namespace App\Http\Controllers;
use App\Models\Blog;
use App\Models\BlogCategory;
use Illuminate\Http\Request;

class BlogController extends Controller
{
    protected $dirPath = 'images/blog_images/';

    public function index()    //<--(BLOG LISTING...)-->
    {
        $blog = Blog::with('category')->get()->all();
        return view('admin.blogs.index', compact('blog'));
    }


    public function create(Request $request)  //<--(BLOG FORM CREATE)-->
    {
        $data['categories'] = BlogCategory::where('status', 1)->get();  // for category dropdown list at relationshp
        return view('admin.blogs.create',$data);
    }


    public function store(Request $request)   //<--(INSERT IN DB...)-->
    {
        $request->validate([
            'category_id'  => ['required'],
            'image' => ['required'],
            'title' => ['required'],
            'description' => ['required'],
            'status' => ['required'],
            'date' => 'required'
        ]);

        $blog = new Blog();
        $blog->category_id = $request->category_id;
        $blog->title = $request->title;
        $blog->description = $request->description;
        $blog->status = $request->status;
        $blog->date = $request->date;


        if ($request->has('image')) {
            // folder name where you wan to upload
            $image = $request->file('image'); // name of your input field

            $image_name = rand() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path($this->dirPath), $image_name); // for store in folder

            $blog->image = $this->dirPath . $image_name; // for store in database
        }
        $blog->save();

        return redirect()->route('admin.blogs.index')->with('msg', 'Record Successfully Inserted');
    }

    public function edit($id)    //<--(BLOG EDIT FORM DISPLAY...)-->
    {

        $blog = Blog::where('id', $id)->first();
        $categories = BlogCategory::where('status', 1)->get();
            // if(empty($blog))
            // {
            //     return redirect()->route('admin.blogs.index');
            // }
        return view('admin.blogs.edit', compact('blog', 'categories'));
    }

    function update(Request $req)
    {
        //user UPDATE IN DB...
        $blog = Blog::where('id', $req->id)->first();
        // dd($req);
        $blog->category_id = $req->category_id;
        $blog->title = $req->title;
        $blog->description = $req->description;
        $blog->status = $req->status;
        $blog->date = $req->date;

        if ($req->has('image')) {
            //=>this condition use if edit form and not upload
            //image then consider old image
            if (file_exists(public_path($blog->image))) {
                @unlink(public_path($blog->image));
            }
            $image = $req->file('image'); // name of your input field

            $image_name = rand() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path($this->dirPath), $image_name); // for store in folder

            $blog->image = $this->dirPath . $image_name; // for store in database
        }

        $blog->save();

        return redirect()
            ->route('admin.blogs.index')
            ->with('msg', 'Record Updated');
    }

    function destroy($id)     //FOR Category DELETE...
    {
        $blog = Blog::where('id', $id)
            ->get()
            ->first();
        if (file_exists(public_path($blog->image))) {
            @unlink(public_path($blog->image));
        }
        $blog->delete();
        return redirect()
            ->route('admin.blogs.index')
            ->with('msg', 'Record Deleted');
    }



    //<----(user side view blog)---->

    public function usercreate(Request $request)  //<--(USER SIDE BLOGS DISPLAY)-->
    {
        // $blogs = Blog::get()->all();
        $blogs = Blog::paginate(3);
        return view('user.blog.blog',compact('blogs'));
    }

    public function blogdetails(Request $req)  //<--(bloge_detail PAGE)-->
    {

        $blog = Blog::where('id',$req->id)->first();
        return view('user.blog.blog_detail',compact('blog'));
    }



}
