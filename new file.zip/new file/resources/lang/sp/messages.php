<?php

return [

    'title' => "Il s'agit du titre en langue espagnole.",

];
