<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CartController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\FaqsController;
use App\Http\Controllers\BlogCategoryController;
use App\Http\Controllers\FaqsCategoryController;
use App\Http\Controllers\GlobalSettingController;


Route::get('/',[UserController::class,'home'])->name('user.home');

Route::get('/user/login',[UserController::class,'login'])->name('user.login'); //<--(USER LOGIN)-->
// Route::get('/admin/login',[AdminController::class,'login'])->name('auth.login'); //<--(admin  LOGIN)-->


Route::group(['prefix' => 'admin'], function (){
    Auth::routes();
});

Route::middleware(['auth','isAdmin'])->group(function(){

    Route::get('/admin',[AdminController::class,'dashboard'])->name('admin.dashboard');
    //<--USER-->
    Route::get('admin/users',[UserController::class,'index'])->name('user.index');        //<--(listing)-->
    Route::get('admin/addusers',[UserController::class,'adduser'])->name('user.adduser'); //<--(view user form)-->
    Route::post('admin/store',[UserController::class,'store'])->name('store');            //<--(Insert in db)-->
    Route::get('admin/user/{id}/edit',[UserController::class,'edit'])->name('user.edit'); //<--(edit)-->
    Route::post('admin/user/update',[UserController::class,'update'])->name('user.update');
    Route::delete('admin/user/delete/{id}',[UserController::class,'destroy'])->name('user.destroy');
    Route::get('/admin/verify/{id}', [UserController::class, 'verify'])->name('verify');
    Route::get('/admin/unverify/{id}', [UserController::class, 'unverify'])->name('unverify');

    //<--CATEGORY-->
    Route::get('admin/addcategory',[CategoryController::class,'create'])->name('admin.category.create');  //<--(view Category form...)-->
    Route::post('admin/storecategory',[CategoryController::class,'store'])->name('admin.category.store'); //<--(Insert in db)-->
    Route::get('admin/allcategory',[CategoryController::class,'index'])->name('admin.category.index');    //<--(listing)-->
    Route::get('admin/category/{id}/edit',[CategoryController::class,'edit'])->name('admin.category.edit');  //<--(edit)-->
    Route::post('admin/category/update',[CategoryController::class,'update'])->name('admin.category.update');
    Route::delete('admin/category/delete/{id}',[CategoryController::class,'destroy'])->name('admin.category.destroy');//<--(delete)-->
    //<--END CATEGORY-->

    //Route::resource('products',ProductController::class);

    //<--PRODUCT-->
    Route::get('admin/addproduct',[ProductController::class,'create'])->name('admin.product.create');  //<--(view Product form...)-->
    Route::post('admin/storeproduct',[ProductController::class,'store'])->name('admin.product.store'); //<--(Insert in db)-->
    Route::get('admin/allproduct',[ProductController::class,'index'])->name('admin.product.index');    //<--(listing)-->
    Route::get('admin/product/{id}/edit',[ProductController::class,'edit'])->name('admin.product.edit');  //<--(edit)-->
    Route::post('admin/product/update/{id}',[ProductController::class,'update'])->name('admin.product.update');
    Route::delete('admin/product/delete/{id}',[ProductController::class,'destroy'])->name('admin.product.destroy');//<--(delete)-->
    //<--END PRODUCT-->

    //<--ALLORDER(admin side)-->
    Route::get('admin/allorders',[OrderController::class,'adminindex'])->name('admin.allorder.index');    //<--(listing)-->
    Route::get('admin/orderview/{id}',[OrderController::class,'adminview'])->name('admin.allorder.view'); //<--(Order view)-->

    //<--BLOGS-->
    Route::get('admin/blogs',[BlogController::class,'create'])->name('admin.blogs.create');    //<--(view blog form...)-->
    Route::post('admin/storeblog',[BlogController::class,'store'])->name('admin.blogs.store'); //<--(Insert in db)-->
    Route::get('admin/allblogs',[BlogController::class,'index'])->name('admin.blogs.index');   //<--(listing)-->
    Route::get('admin/blog/{id}/edit',[BlogController::class,'edit'])->name('admin.blogs.edit');  //<--(edit)-->
    Route::post('admin/blog/update/{id}',[BlogController::class,'update'])->name('admin.blogs.update');
    Route::delete('admin/blog/delete/{id}',[BlogController::class,'destroy'])->name('admin.blogs.destroy');//<--(delete)-->

    //<--BLOGS category-->
    Route::get('admin/blogcategory',[BlogCategoryController::class,'categorycreate'])->name('admin.blogs.category.create'); //<--(view blog form...)-->
    Route::post('admin/blogstorecategory',[BlogCategoryController::class,'categorystore'])->name('admin.blogs.category.store'); //<--(Insert in db)-->

    //<--Help & FAQs-->
    Route::get('admin/faqs',[FaqsController::class,'create'])->name('admin.faqs.create');     //<--(view blog form...)-->
    Route::post('admin/storefaqs',[FaqsController::class,'store'])->name('admin.faqs.store'); //<--(Insert in db)-->
    Route::get('admin/allfaqs',[FaqsController::class,'index'])->name('admin.faqs.index');    //<--(listing)-->
    Route::get('admin/faqs/{id}/edit',[FaqsController::class,'edit'])->name('admin.faqs.edit');  //<--(edit)-->
    Route::post('admin/faqs/update/{id}',[FaqsController::class,'update'])->name('admin.faqs.update');
    Route::delete('admin/faqs/delete/{id}',[FaqsController::class,'destroy'])->name('admin.faqs.destroy');//<--(delete)-->

    //<--FAQs category-->
    Route::get('admin/faqcategory',[FaqsCategoryController::class,'create'])->name('admin.faqs.category.create');     //<--(view faqs form...)-->
    Route::post('admin/faqstorecategory',[FaqsCategoryController::class,'store'])->name('admin.faqs.category.store'); //<--(Insert in db)-->

    //<--Global Setting-->
    Route::get('admin/globalsetting',[GlobalSettingController::class,'create'])->name('admin.globalsetting.create'); //<--(view global setting form...)-->
    Route::post('admin/settingstore',[GlobalSettingController::class,'store'])->name('admin.globalsetting.store');   //<--(Insert in db)-->
        //CURRENCY
    Route::get('currency/{id}', [GlobalSettingController::class, 'currency'])->name('currency');
    // Route::get('IND/{id}', [GlobalSettingController::class, 'ind'])->name('ind');

});


Route::middleware(['Userlogin'])->group(function(){     //IF LOGIN

    //<--Cart-->
    Route::get('user/addtocart/{id}',[CartController::class,'create'])->name('user.cart.cart');
    Route::get('user/cart',[CartController::class,'index'])->name('user.cart.index');
    Route::post('user/cart/qtyupdate',[CartController::class,'update'])->name('user.cart.qtyupdate');

    //<--ORDER-->
    Route::get('user/order/create',[OrderController::class,'create'])->name('user.order.create'); //<--(checkout form)-->
    Route::post('user/storeorder',[OrderController::class,'store'])->name('user.order.store');    //<--(Insert in db)-->
    Route::get('user/allorders',[OrderController::class,'index'])->name('user.order.index');      //<--(listing)-->
    Route::get('user/orderview/{id}',[OrderController::class,'view'])->name('user.order.view');        //<--(Order view)-->

    //<--PROFILE-->
    Route::get('user/profile/view',[UserController::class,'profile_view'])->name('user.profile.index');
    Route::get('user/profile',[UserController::class,'profile'])->name('user.profile.profile');   //edit profile form
    Route::post('user/profileupdate',[UserController::class,'profileupdate'])->name('user.profile.update'); //<--(Insert in db)-->

});

//<--(CATEGORY SHOW HOME PAGE)-->
Route::get('category/show/{id}',[UserController::class,'show'])->name('user.category.show'); //<--(listing)-->

//<--BLOGS (view user side)-->
Route::get('user/blog',[BlogController::class,'usercreate'])->name('user.blog.blog');
Route::get('user/blogdetails',[BlogController::class,'blogdetails'])->name('user.blog.blog_detail');

//<--HELP & FAQs (view user side)-->
Route::get('user/faqs',[FaqsController::class,'usercreate'])->name('user.faqs.faqs');
