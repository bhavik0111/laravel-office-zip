<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class Userlogin
{
    // public function handle(Request $request, Closure $next)
    // {
    //     return $next($request);
    // }

    public function handle(Request $request, Closure $next)   //then change in (kernel.php) file
    {
        if (!Auth::check()) {
            return redirect()->route('user.login');
        }else{
            return $next($request);
        }
    }
}
