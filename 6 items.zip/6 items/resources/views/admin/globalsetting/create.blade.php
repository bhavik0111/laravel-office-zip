@extends('admin.layout.master')

@section('content')
    <!-- (FOR MSG) -->
    @if (session()->has('msg'))
        <div class="alert alert-success">
            {{ session()->get('msg') }}
        </div>
    @endif
    @if (session()->has('error_msg'))
        <div class="alert alert-danger">
            {{ session()->get('error_msg') }}
        </div>
    @endif
    <!-- (END MSG) -->

    <main class="form-signin">
        <div class="card">
            <form method="POST" action="{{ route('admin.globalsetting.store') }}" enctype="multipart/form-data">
                @csrf
                <div class="card-body">
                    <h4 class="card-title"><b>{{ __('Global Field') }}</b></h4>

                    <div class="form-group row">
                        <label for="logo"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Logo') }}</b></label>

                        <div class="col-sm-9">
                            <input type="file" id="logo" class="form-control @error('logo') is-invalid @enderror"
                                name="logo">
                            @error('logo')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="faceicon"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Faceicon') }}</b></label>

                        <div class="col-sm-9">
                            <input type="file" id="faceicon"
                                class="form-control @error('faceicon') is-invalid @enderror" name="faceicon">
                            @error('faceicon')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="site_title"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Site title') }}</b></label>
                        <div class="col-sm-9">
                            <input id="site_title" type="text"
                                class="form-control @error('site_title') is-invalid @enderror" name="site_title"
                                value="{{ old('site_title',(isset( $global->site_title) ? $global->site_title : '')) }}"
                                required autocomplete="site_title" autofocus>
                            {{-- value="{{ old('name',$category->name) }}" --}}
                            @error('site_title')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <h4 class="card-title"><b>{{ __('Contact Details') }}</b></h4>

                    <div class="form-group row">
                        <label for="address"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Address') }}</b></label>
                        <div class="col-sm-9">
                            <textarea id="address" class="form-control @error('address') is-invalid @enderror" name="address"
                                required autocomplete="address" autofocus>
                                {{ old('address',(isset( $global->address) ? $global->address : '')) }}
                            </textarea>
                        </div>
                        @error('address')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div class="form-group row">
                        <label for="phone"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Phone') }}</b></label>

                        <div class="col-sm-9">
                            <input type="number" id="phone" class="form-control @error('phone') is-invalid @enderror"
                                value="{{ old('phone',(isset( $global->phone) ? $global->phone : '')) }}" name="phone">
                            @error('phone')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="email"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Email') }}</b></label>
                        <div class="col-sm-9">
                            <input id="email" type="text" class="form-control @error('email') is-invalid @enderror"
                                name="email" value="{{ old('email',(isset($global->email) ? $global->email : '')) }}" required autocomplete="email" autofocus>
                        </div>
                        @error('email')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                </div>

                <div class="card-body">
                    <h4 class="card-title"><b>{{ __('Social Links') }}</b></h4>

                    <div class="form-group row">
                        <label for="facebook_url"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Facebook URL') }}</b></label>
                        <div class="col-sm-9">
                            <input type="text" id="facebook_url"
                                class="form-control @error('facebook_url') is-invalid @enderror" name="facebook_url"
                                value="{{ old('facebook_url',(isset($global->facebook_url) ? $global->facebook_url : '' )) }}" required autocomplete="facebook_url" autofocus>

                            @error('facebook_url')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="linkdin_url"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('LinkdIn URL') }}</b></label>

                        <div class="col-sm-9">
                            <input type="text" id="linkdin_url"
                                class="form-control @error('linkdin_url') is-invalid @enderror"
                                value="{{ old('linkdin_url',(isset($global->linkdin_url) ? $global->linkdin_url : '' )) }}" name="linkdin_url">

                            @error('linkdin_url')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="insta_url"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Insta URL') }}</b></label>
                        <div class="col-sm-9">
                            <input id="insta_url" type="text"
                                class="form-control @error('insta_url') is-invalid @enderror" name="insta_url"
                                value="{{ old('insta_url',(isset($global->insta_url) ? $global->insta_url : '' )) }}" required autocomplete="insta_url" autofocus>

                            @error('insta_url')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="payment_logo"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Payment logo') }}</b></label>

                        <div class="col-sm-9">
                            <input type="file" id="payment_logo"
                                class="form-control @error('payment_logo') is-invalid @enderror" name="payment_logo">
                            @error('payment_logo')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <h4 class="card-title"><b>{{ __('Footer Section') }}</b></h4>

                    <div class="form-group row">
                        <label for="footer_logo"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Footer Logo') }}</b></label>

                        <div class="col-sm-9">
                            <input id="footer_logo" type="file"
                                class="form-control @error('footer_logo') is-invalid @enderror" name="footer_logo">
                            @error('footer_logo')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="about_us"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('About us') }}</b></label>
                        <div class="col-sm-9">
                            <textarea id="about_us" class="form-control @error('about_us') is-invalid @enderror"
                             name="about_us"> {{ old('about_us',(isset($global->about_us) ? $global->about_us : '' )) }}
                            </textarea>
                            @error('about_us')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <h4 class="card-title"><b>{{ __('Copyright Massage') }}</b></h4>

                    <div class="form-group row">
                        <label for="copyright_msg"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Massage') }}</b>
                        </label>
                        <div class="col-sm-9">
                            <textarea id="copyright_msg" class="form-control @error('copyright_msg') is-invalid @enderror"
                                name="copyright_msg"> {{ old('copyright_msg',(isset($global->copyright_msg) ? $global->copyright_msg : '' )) }}
                            </textarea>
                        </div>
                        @error('copyright_msg')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                </div>

                <div class="card-body">
                    <h4 class="card-title"><b>{{ __('Currency') }}</b></h4>

                    <div class="form-group row">
                        <label for="currency"
                            class="col-sm-3 text-end control-label col-form-label"><b>{{ __('Currency') }}</b>
                        </label>
                        <div class="col-sm-9">
                            <select name="currency" class="form-control  @error('currency') is-invalid @enderror ">
                                <option value="0" selected>Select Currency</option>
                                <option value="IND" {{ $global->currency == 'IND' ? 'selected' : '' }}>IND</option>
                                <option value="USD" {{ $global->currency == 'USD' ? 'selected' : '' }}>USD</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="border-top">
                    <div class="card-body" style="float:center">
                        <button type="submit" class="btn btn-primary">
                            {{ __('submit') }}
                        </button>
                    </div>
                </div>

            </form>
        </div>
    </main>
@endsection
