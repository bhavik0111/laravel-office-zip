<div class="bg-dark pt-5" style="min-height: calc(300vh - 50px);">
    <ul>
        @auth
            <!-- <li class="p-2 text-white"><a class="text-white" href="{{ route('user.home') }}">Home</a></li> -->
            <li class="p-2 text-white"><a class="text-white" href="{{ route('user.profile.eprofile') }}">Home</a></li>
            <li class="p-2 text-white"><a class="text-white" href="{{ route('user.profile.profile') }}">Edit Profile</a></li>
            <li class="p-2 text-white"><a class="text-white" href="{{ route('user.order.index') }}">All Order</a></li>
            <li class="p-2 text-white"><a class="text-white" href="{{ route('user.cart.index') }}">Cart</a></li>
        @endauth

        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
            @csrf
        </form>
    </ul>
</div>
