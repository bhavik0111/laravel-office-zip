{{-- <div class="homemanibanner">  //home filema lidheli chhe
    <div class="container">
        <div class="home-searchtitle">
            <h2 data-aos="fade-up" data-aos-delay="100">Find eSIMs for more than 130 destinations</h2>
            <h6 data-aos="fade-up" data-aos-delay="200">The best offers around the world</h6>
            <div class="homesearch" data-aos="fade-up" data-aos-delay="300">
                <input class="form-control" type="text" name="search" placeholder="Search for a destination...">
                <input class="input-search-icon" type="submit" name="submit" value="">
            </div>
        </div>
        <div class="swiper mySwiper homemainslider" data-aos="fade-up" data-aos-delay="400">
            <div class="swiper-wrapper">

                @foreach ($allcategory as $categorys)
                    <div class="swiper-slide">
                        <div class="flagbg">
                            <a href="{{ route('user.category.show',['id' => $categorys->id]) }}">
                                <img src="{{ asset('public/' . $categorys->image) }}" alt="">
                                <h6>{{ $categorys->name}}</h6>
                            </a>
                        </div>
                    </div>
                @endforeach

            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-pagination"></div>
        </div>
    </div>
</div>
 --}}
